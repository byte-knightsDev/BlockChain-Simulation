# Blockchain Simulation Web Interface

This project now has a web architecture matching:

```text
React + Vite + CSS + Framer Motion
              |
          REST/WebSocket
              |
            FastAPI
              |
     +--------+--------+
     |        |        |
 Blockchain Signalling IPFS
     |
   PoW / PoS / PoA
```

## Features added

- Animated React/Vite dashboard
- Framer Motion transitions and live activity effects
- FastAPI REST gateway
- FastAPI WebSocket event channel
- Node start/stop controls
- Live chain/block/transaction/wallet APIs
- P2P topology visualization
- Consensus telemetry for PoW, PoS and PoA
- Security event stream
- Network and blockchain metrics
- Fault-tolerance/recovery readiness telemetry
- Responsive desktop/tablet/mobile layout
- Explorer-style latest block table
- Live event stream
- Architecture separated from the blockchain core

## Run

### Backend

From `Blockchain-Simulation/`:

```bash
python -m pip install -r requirements.txt
python run_web.py
```

FastAPI documentation is available at `http://127.0.0.1:8000/docs`.

### Frontend

From `Blockchain-Simulation/frontend/`:

```bash
npm install
npm run dev
```

Open the Vite URL shown by the terminal, normally `http://127.0.0.1:5173`.

## Starting a node

The dashboard can start a PoW/PoS/PoA node through `POST /api/node/start`. The node startup was extended with `web_mode=True` so the terminal input loop does not block FastAPI's event loop.

For production, authentication, TLS, strict CORS, rate limiting, and a proper process supervisor should be enabled before exposing the API outside localhost.

## Engineering notes

The original consensus implementations remain the source of truth. The web layer reads their state rather than maintaining a second blockchain. This prevents the dashboard from drifting away from the terminal node.
