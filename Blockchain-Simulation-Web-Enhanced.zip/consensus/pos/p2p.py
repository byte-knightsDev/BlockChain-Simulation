import asyncio
import websockets
import traceback
import hashlib
import argparse
import json
import uuid
import base64
import threading
import socket
import os
import subprocess
import tempfile
import ast

from datetime import datetime, timedelta
from typing import Set, Dict, List, Tuple, Any
from pathlib import Path

from consensus.pos.blockchain_structures import (
    Transaction,
    Stake,
    Block,
    Wallet,
    Chain,
    isvalidChain,
    weight_of_chain
)

from ipfs.ipfs import (
    addToIpfs,
    download_ipfs_file_subprocess
)

from smart_contract.contracts_db import SmartContractDatabase
from smart_contract.secure_executor import SecureContractExecutor

from storage.storage_manager import (
    save_key,
    load_key,
    save_chain,
    load_chain,
    save_peers,
    load_peers
)

from ecdsa import VerifyingKey, BadSignatureError


# ============================================================
# CONSTANTS
# ============================================================

MAX_CONNECTIONS = 8
MAX_OUTPUT = 2 ** 256

EPOCH_TIME = 60
GAS_PRICE = 0.001
BASE_DEPLOY_COST = 5

CONSENSUS = "pos"

# datetime.timestamp() returns SECONDS.
# Therefore timestamps in this project are treated as seconds.
CLOCK_SKEW = 10

MIN_BLOCK_INTERVAL = EPOCH_TIME * 5 / 6
MAX_BLOCK_AGE = EPOCH_TIME * 2


# ============================================================
# EXCEPTIONS
# ============================================================

class VrfThresholdException(Exception):
    pass


# ============================================================
# HELPER FUNCTIONS
# ============================================================

def get_random_element(s):
    """
    Return a random element from a set.
    """
    import random

    return random.choice(list(s)) if s else None


def normalize_endpoint(ep):
    """
    Resolve host into IPv4 address and normalize port to int.
    """

    host, port = ep

    try:
        resolved_host = socket.gethostbyname(host)
    except socket.gaierror:
        resolved_host = host

    return (resolved_host, int(port))


def timestamp_to_datetime(ts):
    """
    Convert supported timestamp formats to datetime.

    IMPORTANT:
    datetime.timestamp() uses seconds, not milliseconds.
    """

    if isinstance(ts, (int, float)):
        return datetime.fromtimestamp(ts)

    if isinstance(ts, str):
        return datetime.fromisoformat(ts)

    if isinstance(ts, datetime):
        return ts

    raise ValueError("Invalid timestamp format")


def transaction_amount(transaction):
    """
    Return the amount spent by a transaction.
    """

    if transaction.receiver in ("deploy", "invoke"):
        if not isinstance(transaction.payload, list):
            raise ValueError("Invalid contract transaction payload")

        if len(transaction.payload) == 0:
            raise ValueError("Empty contract transaction payload")

        return transaction.payload[-1]

    return transaction.payload


def safe_b64decode(value):
    """
    Safely decode a base64 string.
    """

    if not isinstance(value, str):
        raise ValueError("Expected base64 string")

    return base64.b64decode(value, validate=True)


# ============================================================
# SMART CONTRACT INPUT
# ============================================================

def get_contract_code_from_notepad():

    temp_filename = None

    try:

        with tempfile.NamedTemporaryFile(
            suffix=".py",
            delete=False,
            mode="w+",
            encoding="utf-8"
        ) as tmp_file:

            temp_filename = tmp_file.name

            tmp_file.write(
                "# Write your smart contract function here.\n"
            )

            tmp_file.write(
                "def contract_logic(parameter1, parameter2, "
                "parameter3, state):\n"
            )

            tmp_file.write(
                "    # your code here\n"
            )

            tmp_file.write(
                "    return state, 'some message'\n"
            )

        subprocess.call(
            ["notepad.exe", temp_filename]
        )

        with open(
            temp_filename,
            "r",
            encoding="utf-8"
        ) as f:

            contract_code = f.read()

        return contract_code

    finally:

        if temp_filename and os.path.exists(temp_filename):

            try:
                os.remove(temp_filename)
            except OSError:
                pass


# ============================================================
# PEER
# ============================================================

class Peer:

    def __init__(
        self,
        host,
        port,
        name,
        staker: bool,
        activate_disk_load,
        activate_disk_save
    ):

        self.host = host
        self.name = name
        self.staker = staker

        self.activate_disk_save = activate_disk_save

        self.port = int(port)

        self.ipfs_port = self.port + 50
        self.gateway_port = self.port + 81
        self.swarm_tcp = self.port + 2
        self.swarm_udp = self.port + 3

        self.repo_path = (
            Path.home() / f".ipfs_{self.port}"
        )

        self.env = os.environ.copy()
        self.env["IPFS_PATH"] = str(self.repo_path)

        # ----------------------------------------------------
        # Connections
        # ----------------------------------------------------

        self.server_connections: Set[
            websockets.WebSocketServerProtocol
        ] = set()

        self.client_connections: Set[
            websockets.WebSocketServerProtocol
        ] = set()

        self.outbound_peers: Set[tuple] = set()

        # ----------------------------------------------------
        # Message tracking
        # ----------------------------------------------------

        self.seen_message_ids: Set[str] = set()

        # ----------------------------------------------------
        # Peer state
        # ----------------------------------------------------

        self.known_peers: Dict[
            Tuple[str, int],
            Tuple[str, str]
        ] = {}

        self.name_to_public_key_dict: Dict[
            str, str
        ] = {}

        if activate_disk_load == "y":

            self.load_known_peers_from_disk()

        # ----------------------------------------------------
        # Consensus state
        # ----------------------------------------------------

        self.staked_amt: int = 0

        self.current_stakes: set = set()

        self.current_stakers: Dict[str, int] = {}

        self.curr_stakers_condition = (
            asyncio.Condition()
        )

        # ----------------------------------------------------
        # Connection heartbeat
        # ----------------------------------------------------

        self.got_pong: Dict[
            websockets.WebSocketServerProtocol,
            bool
        ] = {}

        self.have_sent_peer_info: Dict[
            websockets.WebSocketServerProtocol,
            bool
        ] = {}

        # ----------------------------------------------------
        # Epoch
        # ----------------------------------------------------

        self.last_epoch_end_ts = datetime.now()

        # ----------------------------------------------------
        # Transaction pool
        # ----------------------------------------------------

        self.mem_pool: List[Transaction] = []

        self.mem_pool_lock = asyncio.Lock()

        # ----------------------------------------------------
        # Files
        # ----------------------------------------------------

        self.file_hashes: Dict[str, str] = {}

        self.file_hashes_lock = asyncio.Lock()

        self.daemon_process = None

        # ----------------------------------------------------
        # Wallet
        # ----------------------------------------------------

        self.wallet = None

        if activate_disk_load == "y":
            self.load_key_from_disk()

        if not self.wallet:

            self.wallet = Wallet()

            if self.activate_disk_save == "y":
                self.save_key_to_disk()

        # ----------------------------------------------------
        # Blockchain
        # ----------------------------------------------------

        self.chain = None

        if activate_disk_load == "y":
            self.load_chain_from_disk()

        # ----------------------------------------------------
        # Smart contracts
        # ----------------------------------------------------

        self.contractsDB = SmartContractDatabase()

        # ----------------------------------------------------
        # Block creation
        # ----------------------------------------------------

        self.create_block_condition = (
            asyncio.Condition()
        )

        self.mine_task = None

    # ========================================================
    # STORAGE
    # ========================================================

    def save_key_to_disk(self):

        key = self.wallet.private_key_pem

        save_key(
            key,
            CONSENSUS
        )

    def load_key_from_disk(self):

        key = load_key(CONSENSUS)

        if not key:
            self.wallet = None
            return

        try:
            self.wallet = Wallet(key)
        except Exception as e:
            print(
                f"Could not load wallet: {e}"
            )

            self.wallet = None

    def load_chain_from_disk(self):

        block_dict_list = load_chain(CONSENSUS)

        if not block_dict_list:
            self.chain = None
            return

        block_list = []

        try:

            for block_dict in block_dict_list:

                block = self.block_dict_to_block(
                    block_dict
                )

                if block is None:
                    print(
                        "Invalid block found in saved chain"
                    )
                    self.chain = None
                    return

                block_list.append(block)

            if not isvalidChain(block_list):

                print(
                    "Saved chain failed validation"
                )

                self.chain = None
                return

            self.chain = Chain(
                blockList=block_list
            )

        except Exception as e:

            print(
                f"Error loading chain: {e}"
            )

            self.chain = None

    def save_chain_to_disk(self):

        if Chain.instance is None:
            return

        chain = Chain.instance.to_block_dict_list()

        save_chain(
            chain,
            CONSENSUS
        )

    def save_known_peers_to_disk(self):

        content = {}

        for key, value in self.known_peers.items():

            content[
                json.dumps(key)
            ] = list(value)

        save_peers(
            content,
            CONSENSUS
        )

    def load_known_peers_from_disk(self):

        content = load_peers(CONSENSUS)

        if not content:
            return

        self.known_peers = {}

        for key, value in content.items():

            try:

                endpoint = tuple(
                    ast.literal_eval(key)
                )

                self.known_peers[
                    endpoint
                ] = tuple(value)

            except Exception:
                continue

        # FIX:
        # Old code incorrectly did:
        #
        # for key, value in self.known_peers:
        #
        # which iterates dictionary keys instead of
        # key/value pairs.

        for endpoint, value in self.known_peers.items():

            if len(value) >= 2:

                name = value[0]
                public_key = value[1]

                self.name_to_public_key_dict[
                    name.lower()
                ] = public_key

    # ========================================================
    # PEER INFORMATION
    # ========================================================

    async def send_peer_info(self, websocket):

        pkt = {
            "type": "peer_info",
            "id": str(uuid.uuid4()),
            "data": {
                "host": self.host,
                "port": self.port,
                "name": self.name,
                "public_key":
                    self.wallet.public_key_pem
            }
        }

        self.seen_message_ids.add(
            pkt["id"]
        )

        await websocket.send(
            json.dumps(pkt)
        )

    async def send_known_peers(self, websocket):

        peers = [
            {
                "host": h,
                "port": p,
                "name": n,
                "public_key": s
            }
            for (h, p), (n, s)
            in self.known_peers.items()
        ]

        peers.append({
            "host": self.host,
            "port": self.port,
            "name": self.name,
            "public_key":
                self.wallet.public_key_pem
        })

        pkt = {
            "type": "known_peers",
            "id": str(uuid.uuid4()),
            "peers": peers
        }

        self.seen_message_ids.add(
            pkt["id"]
        )

        await websocket.send(
            json.dumps(pkt)
        )

    # ========================================================
    # BLOCK DESERIALIZATION
    # ========================================================

    def block_dict_to_block(
        self,
        block_dict: Dict[str, Any]
    ):

        if not isinstance(block_dict, dict):
            return None

        try:

            new_block_id = block_dict.get("id")
            new_block_prevHash = block_dict.get(
                "prevHash"
            )
            new_block_ts = block_dict.get("ts")

            transactions_data = (
                block_dict.get("transactions")
            )

            if (
                new_block_id is None
                or new_block_ts is None
                or transactions_data is None
            ):
                return None

            transactions = []

            for transaction_dict in transactions_data:

                if not isinstance(
                    transaction_dict,
                    dict
                ):
                    return None

                required = [
                    "payload",
                    "sender",
                    "receiver",
                    "id",
                    "ts"
                ]

                if not all(
                    key in transaction_dict
                    for key in required
                ):
                    return None

                transaction = Transaction(
                    transaction_dict["payload"],
                    transaction_dict["sender"],
                    transaction_dict["receiver"],
                    transaction_dict["id"],
                    transaction_dict["ts"]
                )

                # Genesis transaction doesn't normally
                # contain a signature in your format.
                if transaction.sender != "Genesis":

                    sign_string = (
                        transaction_dict.get("sign")
                    )

                    if not sign_string:
                        return None

                    transaction.sign = (
                        safe_b64decode(sign_string)
                    )

                transactions.append(
                    transaction
                )

            newBlock = Block(
                new_block_prevHash,
                transactions,
                new_block_ts,
                new_block_id
            )

            # ------------------------------------------------
            # Block fields
            # ------------------------------------------------

            staked_amt = block_dict.get(
                "staked_amt",
                0
            )

            if staked_amt is not None:
                newBlock.staked_amt = staked_amt

            files = block_dict.get("files")

            if files is not None:
                newBlock.files = files

            creator = block_dict.get(
                "creator",
                ""
            )

            newBlock.creator = creator

            sign_b64 = block_dict.get(
                "sign"
            )

            if sign_b64:

                newBlock.sign = (
                    safe_b64decode(sign_b64)
                )

            # ------------------------------------------------
            # Stakers
            # ------------------------------------------------

            stakers_data = block_dict.get(
                "stakers",
                []
            )

            stakers_list = []

            for staker_dict in stakers_data:

                stake = self.stake_dict_to_stake(
                    staker_dict
                )

                if stake is None:
                    return None

                stakers_list.append(
                    stake
                )

            newBlock.stakers = stakers_list

            # ------------------------------------------------
            # VRF
            # ------------------------------------------------

            vrf_proof = block_dict.get(
                "vrf_proof_b64"
            )

            seed = block_dict.get(
                "seed"
            )

            if vrf_proof is not None:

                newBlock.vrf_proof = (
                    safe_b64decode(vrf_proof)
                )

            if seed is not None:

                newBlock.seed = seed

            return newBlock

        except Exception as e:

            print(
                f"Error converting block: {e}"
            )

            return None

    # ========================================================
    # STAKE DESERIALIZATION
    # ========================================================

    def stake_dict_to_stake(
        self,
        stake_dict: Dict[str, Any]
    ):

        if not isinstance(
            stake_dict,
            dict
        ):
            return None

        try:

            stake_id = stake_dict.get("id")
            staker = stake_dict.get("staker")
            amt = stake_dict.get("amt")
            ts = stake_dict.get("ts")
            sign = stake_dict.get("sign")

            if (
                stake_id is None
                or staker is None
                or amt is None
                or ts is None
                or sign is None
            ):
                return None

            if float(amt) <= 0:
                return None

            stake = Stake(
                staker,
                amt,
                ts
            )

            stake.id = stake_id

            stake.sign = safe_b64decode(
                sign
            )

            return stake

        except Exception:
            return None

    # ========================================================
    # SMART CONTRACT VALIDATION
    # ========================================================

    def valid_deploy_transaction(
        self,
        payload
    ):

        try:

            if (
                not isinstance(payload, list)
                or len(payload) < 2
            ):
                return False

            contract_code = payload[0]
            amount = payload[-1]

            if not isinstance(
                contract_code,
                str
            ):
                return False

            gas_used = (
                len(contract_code) // 10
                + BASE_DEPLOY_COST
            )

            expected_amount = (
                gas_used * GAS_PRICE
            )

            return amount == expected_amount

        except Exception:
            return False

    def valid_invoke_transaction(
        self,
        payload
    ):

        try:

            if (
                not isinstance(payload, list)
                or len(payload) < 5
            ):
                return False

            contract_id = payload[0]
            func_name = payload[1]
            args = payload[2]
            expected_state = payload[3]
            amount = payload[-1]

            response = self.run_contract([
                contract_id,
                func_name,
                args
            ])

            if response.get("error") is not None:
                return False

            state = response["state"]
            gas_used = response["gas_used"]

            expected_amount = (
                gas_used * GAS_PRICE
            )

            if state != expected_state:
                return False

            if amount != expected_amount:
                return False

            return True

        except Exception:
            return False

    # ========================================================
    # UNIQUE NAME
    # ========================================================

    def get_unique_name(
        self,
        base_name
    ):

        existing_names = []

        for key, value in self.known_peers.items():

            if value:
                existing_names.append(
                    value[0].lower()
                )

        existing_names.append(
            self.name.lower()
        )

        base_name = base_name.lower()

        if base_name not in existing_names:
            return base_name

        counter = 1

        while True:

            new_name = (
                f"{base_name}{counter}"
            )

            if new_name not in existing_names:
                return new_name

            counter += 1

    # ========================================================
    # MESSAGE HANDLING
    # ========================================================

    async def handle_messages(
        self,
        websocket,
        msg
    ):

        if not isinstance(msg, dict):
            return

        message_type = msg.get("type")
        message_id = msg.get("id")

        if not message_type or not message_id:
            return

        if message_id in self.seen_message_ids:
            return

        self.seen_message_ids.add(
            message_id
        )

        # ====================================================
        # PING
        # ====================================================

        if message_type == "ping":

            pkt = {
                "type": "pong",
                "id": str(uuid.uuid4())
            }

            self.seen_message_ids.add(
                pkt["id"]
            )

            await websocket.send(
                json.dumps(pkt)
            )

        # ====================================================
        # PONG
        # ====================================================

        elif message_type == "pong":

            self.got_pong[
                websocket
            ] = True

            if not self.have_sent_peer_info.get(
                websocket,
                True
            ):

                await self.send_peer_info(
                    websocket
                )

                self.have_sent_peer_info[
                    websocket
                ] = True

        # ====================================================
        # PEER INFO
        # ====================================================

        elif message_type == "peer_info":

            data = msg.get("data")

            if not isinstance(data, dict):
                return

            required = [
                "host",
                "port",
                "name",
                "public_key"
            ]

            if not all(
                key in data
                for key in required
            ):
                return

            try:

                normalized_self = normalize_endpoint(
                    (self.host, self.port)
                )

                normalized_endpoint = (
                    normalize_endpoint(
                        (
                            data["host"],
                            data["port"]
                        )
                    )
                )

            except Exception:
                return

            if (
                normalized_endpoint
                not in self.known_peers
                and normalized_endpoint
                != normalized_self
            ):

                self.known_peers[
                    normalized_endpoint
                ] = (
                    data["name"],
                    data["public_key"]
                )

                self.name_to_public_key_dict[
                    data["name"].lower()
                ] = data["public_key"]

                if self.activate_disk_save == "y":
                    self.save_known_peers_to_disk()

                print(
                    f"Registered peer "
                    f"{data['name']} "
                    f"{data['host']}:{data['port']}"
                )

                await self.send_known_peers(
                    websocket
                )

        # ====================================================
        # ADD PEER
        # ====================================================

        elif message_type == "add_peer":

            data = msg.get("data")

            if not isinstance(data, dict):
                return

            required = [
                "host",
                "port",
                "name",
                "public_key"
            ]

            if not all(
                key in data
                for key in required
            ):
                return

            try:

                normalized_self = normalize_endpoint(
                    (self.host, self.port)
                )

                normalized_endpoint = (
                    normalize_endpoint(
                        (
                            data["host"],
                            data["port"]
                        )
                    )
                )

            except Exception:
                return

            new_peer_msg_id = str(
                uuid.uuid4()
            )

            if (
                normalized_endpoint
                not in self.known_peers
                and normalized_endpoint
                != normalized_self
            ):

                proposed_name = (
                    self.get_unique_name(
                        data["name"]
                    )
                )

                if proposed_name != data["name"]:

                    pkt = {
                        "type": "change_name",
                        "id": str(uuid.uuid4()),
                        "new_peer_msg_id":
                            new_peer_msg_id,
                        "new_name":
                            proposed_name
                    }

                    await websocket.send(
                        json.dumps(pkt)
                    )

                    data["name"] = proposed_name

                self.known_peers[
                    normalized_endpoint
                ] = (
                    data["name"],
                    data["public_key"]
                )

                self.name_to_public_key_dict[
                    data["name"].lower()
                ] = data["public_key"]

                if self.activate_disk_save == "y":
                    self.save_known_peers_to_disk()

                print(
                    f"Registered peer "
                    f"{data['name']} "
                    f"{data['host']}:{data['port']}"
                )

                await self.send_known_peers(
                    websocket
                )

                pkt = {
                    "type": "new_peer",
                    "id": new_peer_msg_id,
                    "data": {
                        "host": data["host"],
                        "port": data["port"],
                        "name": data["name"],
                        "public_key":
                            data["public_key"]
                    }
                }

                self.seen_message_ids.add(
                    pkt["id"]
                )

                await self.broadcast_message(
                    pkt
                )

        # ====================================================
        # NEW PEER
        # ====================================================

        elif message_type == "new_peer":

            data = msg.get("data")

            if not isinstance(data, dict):
                return

            required = [
                "host",
                "port",
                "name",
                "public_key"
            ]

            if not all(
                key in data
                for key in required
            ):
                return

            try:

                normalized_self = normalize_endpoint(
                    (self.host, self.port)
                )

                normalized_endpoint = (
                    normalize_endpoint(
                        (
                            data["host"],
                            data["port"]
                        )
                    )
                )

            except Exception:
                return

            if (
                normalized_endpoint
                not in self.known_peers
                and normalized_endpoint
                != normalized_self
            ):

                self.known_peers[
                    normalized_endpoint
                ] = (
                    data["name"],
                    data["public_key"]
                )

                self.name_to_public_key_dict[
                    data["name"].lower()
                ] = data["public_key"]

                if self.activate_disk_save == "y":
                    self.save_known_peers_to_disk()

                print(
                    f"Registered peer "
                    f"{data['name']} "
                    f"{data['host']}:{data['port']}"
                )

                await self.broadcast_message(
                    msg
                )

        # ====================================================
        # CHANGE NAME
        # ====================================================

        elif message_type == "change_name":

            new_name = msg.get(
                "new_name"
            )

            new_peer_msg_id = msg.get(
                "new_peer_msg_id"
            )

            if not new_name or not new_peer_msg_id:
                return

            self.name = new_name

            self.seen_message_ids.add(
                new_peer_msg_id
            )

        # ====================================================
        # KNOWN PEERS
        # ====================================================

        elif message_type == "known_peers":

            peers = msg.get("peers")

            if not isinstance(peers, list):
                return

            new_peer_found = False

            normalized_self = normalize_endpoint(
                (self.host, self.port)
            )

            for peer in peers:

                if not isinstance(peer, dict):
                    continue

                required = [
                    "host",
                    "port",
                    "name",
                    "public_key"
                ]

                if not all(
                    key in peer
                    for key in required
                ):
                    continue

                try:

                    normalized_endpoint = (
                        normalize_endpoint(
                            (
                                peer["host"],
                                peer["port"]
                            )
                        )
                    )

                except Exception:
                    continue

                if (
                    normalized_endpoint
                    not in self.known_peers
                    and normalized_endpoint
                    != normalized_self
                ):

                    print(
                        f"Discovered peer "
                        f"{peer['name']} at "
                        f"{peer['host']}:{peer['port']}"
                    )

                    new_peer_found = True

                    self.known_peers[
                        normalized_endpoint
                    ] = (
                        peer["name"],
                        peer["public_key"]
                    )

                    self.name_to_public_key_dict[
                        peer["name"].lower()
                    ] = peer["public_key"]

            if (
                new_peer_found
                and self.activate_disk_save == "y"
            ):
                self.save_known_peers_to_disk()

            pkt = {
                "type": "chain_request",
                "id": str(uuid.uuid4())
            }

            self.seen_message_ids.add(
                pkt["id"]
            )

            await websocket.send(
                json.dumps(pkt)
            )

        # ====================================================
        # FILE
        # ====================================================

        elif message_type == "file":

            cid = msg.get("cid")
            desc = msg.get("desc")

            if not cid or not desc:
                return

            async with self.file_hashes_lock:

                self.file_hashes[cid] = desc

            await self.broadcast_message(
                msg
            )

        # ====================================================
        # NEW TRANSACTION
        # ====================================================

        elif message_type == "new_tx":

            tx_str = msg.get(
                "transaction"
            )

            sender_pem = msg.get(
                "sender_pem"
            )

            sign_str = msg.get(
                "sign"
            )

            if not tx_str or not sender_pem or not sign_str:
                return

            try:

                tx = json.loads(tx_str)

            except json.JSONDecodeError:
                return

            if not isinstance(tx, dict):
                return

            required = [
                "payload",
                "sender",
                "receiver",
                "id",
                "ts"
            ]

            if not all(
                key in tx
                for key in required
            ):
                return

            # IMPORTANT FIX:
            # sender_pem must actually be the same key
            # contained in the transaction.

            if tx["sender"] != sender_pem:
                print(
                    "Transaction sender mismatch"
                )
                return

            try:

                amount = transaction_amount(
                    Transaction(
                        tx["payload"],
                        tx["sender"],
                        tx["receiver"],
                        tx["id"],
                        tx["ts"]
                    )
                )

            except Exception:
                return

            if not isinstance(
                amount,
                (int, float)
            ):
                return

            if amount <= 0:
                print(
                    "\nInvalid Transaction, amount<=0\n"
                )
                return

            transaction = Transaction(
                tx["payload"],
                tx["sender"],
                tx["receiver"],
                tx["id"],
                tx["ts"]
            )

            if Chain.instance is None:
                return

            # Check chain duplicate
            if Chain.instance.transaction_exists_in_chain(
                transaction
            ):

                print(
                    f"{self.name} "
                    f"Transaction already exists in chain"
                )

                return

            try:

                sign_bytes = safe_b64decode(
                    sign_str
                )

            except Exception:

                print(
                    "Invalid signature encoding"
                )

                return

            # Contract validation
            if transaction.receiver == "deploy":

                if not self.valid_deploy_transaction(
                    transaction.payload
                ):
                    return

            elif transaction.receiver == "invoke":

                if not self.valid_invoke_transaction(
                    transaction.payload
                ):
                    return

            # Signature validation
            try:

                public_key = (
                    VerifyingKey.from_pem(
                        sender_pem.encode()
                    )
                )

                public_key.verify(
                    sign_bytes,
                    tx_str.encode()
                )

            except (
                BadSignatureError,
                ValueError,
                TypeError
            ):

                print(
                    "Invalid Signature"
                )

                return

            # Balance check
            async with self.mem_pool_lock:

                current_pending = list(
                    self.mem_pool
                )

                current_stakes = list(
                    self.current_stakes
                )

                balance = (
                    Chain.instance.calc_balance(
                        transaction.sender,
                        current_pending,
                        current_stakes
                    )
                )

                if amount > balance:

                    print(
                        "\nAttempt to spend "
                        "more than available\n"
                    )

                    return

                transaction.sign = sign_bytes

                self.mem_pool.append(
                    transaction
                )

            print(
                "\nValid Transaction"
            )

            await self.broadcast_message(
                msg
            )

        # ====================================================
        # STAKE ANNOUNCEMENT
        # ====================================================

        elif message_type == "stake_announcement":

            stake_dict = msg.get(
                "stake"
            )

            if not isinstance(
                stake_dict,
                dict
            ):
                return

            required = [
                "staker",
                "amt",
                "ts",
                "id",
                "sign"
            ]

            if not all(
                key in stake_dict
                for key in required
            ):
                return

            try:

                stake = Stake(
                    stake_dict["staker"],
                    stake_dict["amt"],
                    stake_dict["ts"]
                )

                stake.id = stake_dict["id"]

                pid = stake.staker
                amt = stake.amt

                if not pid or amt <= 0:
                    return

                sign = safe_b64decode(
                    stake_dict["sign"]
                )

                vk = VerifyingKey.from_pem(
                    pid
                )

                vk.verify(
                    sign,
                    str(stake).encode()
                )

                stake.sign = sign

            except (
                BadSignatureError,
                ValueError,
                TypeError
            ):

                print(
                    "\nInvalid stake signature\n"
                )

                return

            if Chain.instance is None:
                return

            async with self.curr_stakers_condition:

                # Prevent duplicate stake from same key
                if pid in self.current_stakers:

                    print(
                        "\nDuplicate stake announcement\n"
                    )

                    return

                balance = (
                    Chain.instance.calc_balance(
                        pid,
                        self.mem_pool,
                        list(self.current_stakes)
                    )
                )

                if amt > balance:

                    print(
                        "\nInvalid stake: "
                        "insufficient balance\n"
                    )

                    return

                self.current_stakes.add(
                    stake
                )

                self.current_stakers[
                    pid
                ] = int(amt)

                print(
                    f"New stake : {pid}:{amt}"
                )

            await self.broadcast_message(
                msg
            )

        # ====================================================
        # NEW BLOCK
        # ====================================================

        elif message_type == "new_block":

            new_block_dict = msg.get(
                "block"
            )

            vrf_proof_str = msg.get(
                "vrf_proof"
            )

            sign_str = msg.get(
                "sign"
            )

            if (
                not isinstance(new_block_dict, dict)
                or not vrf_proof_str
                or not sign_str
            ):
                return

            newBlock = (
                self.block_dict_to_block(
                    new_block_dict
                )
            )

            if newBlock is None:
                print(
                    "\nInvalid block format\n"
                )
                return

            # ------------------------------------------------
            # Decode signatures
            # ------------------------------------------------

            try:

                vrf_proof = safe_b64decode(
                    vrf_proof_str
                )

                sign = safe_b64decode(
                    sign_str
                )

            except Exception as e:

                print(
                    f"\nInvalid block encoding: {e}\n"
                )

                return

            # ------------------------------------------------
            # Ensure transmitted VRF and block VRF agree
            # ------------------------------------------------

            if (
                newBlock.vrf_proof is not None
                and newBlock.vrf_proof != vrf_proof
            ):

                print(
                    "\nVRF proof mismatch\n"
                )

                return

            if (
                newBlock.sign is not None
                and newBlock.sign != sign
            ):

                print(
                    "\nBlock signature mismatch\n"
                )

                return

            newBlock.vrf_proof = vrf_proof
            newBlock.sign = sign

            # ------------------------------------------------
            # Creator
            # ------------------------------------------------

            creator = new_block_dict.get(
                "creator"
            )

            if not creator:
                return

            newBlock.creator = creator

            # ------------------------------------------------
            # Verify creator signature
            # ------------------------------------------------

            try:

                vk = VerifyingKey.from_pem(
                    creator
                )

                vk.verify(
                    sign,
                    str(newBlock).encode()
                )

            except (
                BadSignatureError,
                ValueError,
                TypeError
            ):

                print(
                    "\nInvalid block signature\n"
                )

                return

            # ------------------------------------------------
            # Check timestamp
            # ------------------------------------------------

            try:

                block_time = (
                    timestamp_to_datetime(
                        newBlock.ts
                    )
                )

                current_time = datetime.now()

                if (
                    block_time
                    > current_time
                    + timedelta(
                        seconds=CLOCK_SKEW
                    )
                ):

                    print(
                        "\nInvalid Block "
                        "(timestamp in future)\n"
                    )

                    return

                if (
                    block_time
                    < current_time
                    - timedelta(
                        seconds=MAX_BLOCK_AGE
                    )
                ):

                    print(
                        "\nInvalid Block "
                        "(timestamp too old)\n"
                    )

                    return

                if Chain.instance is None:
                    return

                if len(Chain.instance.chain) > 0:

                    last_block_time = (
                        timestamp_to_datetime(
                            Chain.instance.lastBlock.ts
                        )
                    )

                    time_diff = (
                        block_time
                        - last_block_time
                    ).total_seconds()

                    if (
                        time_diff
                        < MIN_BLOCK_INTERVAL
                    ):

                        print(
                            "\nInvalid Block "
                            f"(created too quickly: "
                            f"{time_diff}s < "
                            f"{MIN_BLOCK_INTERVAL}s)\n"
                        )

                        return

            except (
                ValueError,
                AttributeError,
                TypeError,
                OSError
            ) as e:

                print(
                    f"\nInvalid Block timestamp: {e}\n"
                )

                return

            # ------------------------------------------------
            # Previous hash
            # ------------------------------------------------

            if (
                Chain.instance.lastBlock.hash
                != newBlock.prevHash
            ):

                print(
                    "\nInvalid Block: "
                    "previous hash mismatch\n"
                )

                return

            # ------------------------------------------------
            # Seed
            # ------------------------------------------------

            expected_seed = (
                Chain.instance.epoch_seed()
            )

            if newBlock.seed != expected_seed:

                print(
                    "\nInvalid Block: "
                    "seed mismatch\n"
                )

                return

            # ------------------------------------------------
            # VRF signature
            # ------------------------------------------------

            try:

                vk.verify(
                    vrf_proof,
                    expected_seed.encode()
                )

            except (
                BadSignatureError,
                ValueError,
                TypeError
            ):

                print(
                    "\nInvalid VRF proof\n"
                )

                return

            # ------------------------------------------------
            # Verify stakes
            # ------------------------------------------------

            if not newBlock.stakers:

                print(
                    "\nInvalid Block: "
                    "no stakers\n"
                )

                return

            total_amt_staked_in_block = 0
            seen_stakers = set()

            for stake in newBlock.stakers:

                if stake.staker in seen_stakers:

                    print(
                        "\nDuplicate staker in block\n"
                    )

                    return

                seen_stakers.add(
                    stake.staker
                )

                if stake.amt <= 0:
                    return

                try:

                    stake_vk = (
                        VerifyingKey.from_pem(
                            stake.staker
                        )
                    )

                    stake_vk.verify(
                        stake.sign,
                        str(stake).encode()
                    )

                except (
                    BadSignatureError,
                    ValueError,
                    TypeError
                ):

                    print(
                        "\nInvalid stake signature\n"
                    )

                    return

                total_amt_staked_in_block += (
                    stake.amt
                )

            if total_amt_staked_in_block <= 0:
                return

            # ------------------------------------------------
            # Current epoch stake set
            # ------------------------------------------------

            async with self.curr_stakers_condition:

                current_stakers_snapshot = dict(
                    self.current_stakers
                )

            total_amt_staked = sum(
                current_stakers_snapshot.values()
            )

            if total_amt_staked <= 0:
                return

            # Every stake represented in the block must
            # correspond to the current epoch stake.
            for stake in newBlock.stakers:

                if stake.staker not in (
                    current_stakers_snapshot
                ):

                    print(
                        "\nBlock contains an "
                        "unknown staker\n"
                    )

                    return

                if (
                    current_stakers_snapshot[
                        stake.staker
                    ]
                    != stake.amt
                ):

                    print(
                        "\nStake amount mismatch\n"
                    )

                    return

            if (
                total_amt_staked_in_block
                != total_amt_staked
            ):

                print(
                    "\nBlock stake set does not "
                    "match current stake set\n"
                )

                return

            # ------------------------------------------------
            # Creator must be a staker
            # ------------------------------------------------

            if creator not in current_stakers_snapshot:

                print(
                    "\nInvalid Block: "
                    "creator is not a current staker\n"
                )

                return

            staked_amt = (
                current_stakers_snapshot[
                    creator
                ]
            )

            # ------------------------------------------------
            # staked_amt consistency
            # ------------------------------------------------

            if newBlock.staked_amt != staked_amt:

                print(
                    "\nInvalid Block: "
                    "staked amount mismatch\n"
                )

                return

            # ------------------------------------------------
            # VRF threshold
            # ------------------------------------------------

            vrf_output = hashlib.sha256(
                vrf_proof
            ).hexdigest()

            vrf_output_int = int(
                vrf_output,
                16
            )

            threshold = (
                staked_amt
                / total_amt_staked_in_block
            ) * MAX_OUTPUT

            # IMPORTANT FIX:
            #
            # Original code:
            #
            # if vrf_output_int <= threshold:
            #     raise VrfThresholdException
            #
            # That rejects the WINNING VRF.
            #
            # A VRF output <= threshold means the
            # validator is selected.

            if vrf_output_int > threshold:

                print(
                    "\nInvalid Block: "
                    "VRF output exceeds threshold\n"
                )

                return

            # ------------------------------------------------
            # Transaction validation
            # ------------------------------------------------

            mem_pool_for_block = []

            for transaction in newBlock.transactions:

                if Chain.instance.transaction_exists_in_chain(
                    transaction
                ):

                    print(
                        "\nDuplicate transaction\n"
                    )

                    return

                if transaction.sign is None:
                    return

                try:

                    tx_vk = (
                        VerifyingKey.from_pem(
                            transaction.sender
                        )
                    )

                    tx_vk.verify(
                        transaction.sign,
                        str(transaction).encode()
                    )

                    amount = transaction_amount(
                        transaction
                    )

                except (
                    BadSignatureError,
                    ValueError,
                    TypeError
                ):

                    print(
                        "\nInvalid transaction\n"
                    )

                    return

                if amount <= 0:
                    return

                balance = (
                    Chain.instance.calc_balance(
                        transaction.sender,
                        mem_pool_for_block,
                        newBlock.stakers
                    )
                )

                if amount > balance:

                    print(
                        "\nTransaction exceeds "
                        "available balance\n"
                    )

                    return

                if transaction.receiver == "deploy":

                    if not self.valid_deploy_transaction(
                        transaction.payload
                    ):
                        return

                elif transaction.receiver == "invoke":

                    if not self.valid_invoke_transaction(
                        transaction.payload
                    ):
                        return

                mem_pool_for_block.append(
                    transaction
                )

            # ------------------------------------------------
            # Validate complete block
            # ------------------------------------------------

            if not Chain.instance.isValidBlock(
                newBlock
            ):

                print(
                    "\nInvalid Block\n"
                )

                return

            # ------------------------------------------------
            # Append
            # ------------------------------------------------

            Chain.instance.chain.append(
                newBlock
            )

            print(
                "\n\nBlock Appended\n"
            )

            self.last_epoch_end_ts = (
                datetime.now()
            )

            # ------------------------------------------------
            # Deploy contracts
            # ------------------------------------------------

            for transaction in newBlock.transactions:

                if transaction.receiver == "deploy":

                    self.deploy_contract(
                        transaction
                    )

            # ------------------------------------------------
            # Remove included transactions
            # ------------------------------------------------

            async with self.mem_pool_lock:

                included_ids = {
                    transaction.id
                    for transaction
                    in newBlock.transactions
                }

                self.mem_pool = [
                    transaction
                    for transaction
                    in self.mem_pool
                    if transaction.id
                    not in included_ids
                ]

            # ------------------------------------------------
            # Remove included files
            # ------------------------------------------------

            async with self.file_hashes_lock:

                for cid in list(
                    self.file_hashes.keys()
                ):

                    if newBlock.cid_exists_in_block(
                        cid
                    ):

                        self.file_hashes.pop(
                            cid,
                            None
                        )

            # ------------------------------------------------
            # Reset epoch
            # ------------------------------------------------

            async with self.curr_stakers_condition:

                self.staked_amt = 0
                self.current_stakers.clear()
                self.current_stakes.clear()

            if self.activate_disk_save == "y":
                self.save_chain_to_disk()

            await self.broadcast_message(
                msg
            )

        # ====================================================
        # SLASH ANNOUNCEMENT
        # ====================================================

        elif message_type == "slash_announcement":

            block1_dict = msg.get(
                "evidence1"
            )

            block1_sign = msg.get(
                "block1_sign"
            )

            block2_dict = msg.get(
                "evidence2"
            )

            block2_sign = msg.get(
                "block2_sign"
            )

            pos = msg.get(
                "pos"
            )

            if not all([
                block1_dict,
                block1_sign,
                block2_dict,
                block2_sign,
                pos is not None
            ]):

                return

            try:

                pos = int(pos)

            except (
                ValueError,
                TypeError
            ):
                return

            block1 = (
                self.block_dict_to_block(
                    block1_dict
                )
            )

            block2 = (
                self.block_dict_to_block(
                    block2_dict
                )
            )

            if block1 is None or block2 is None:
                return

            try:

                block1.sign = safe_b64decode(
                    block1_sign
                )

                block2.sign = safe_b64decode(
                    block2_sign
                )

            except Exception:
                return

            if not block1.creator:
                return

            if block1.creator != block2.creator:
                return

            if pos < 0 or pos >= len(
                Chain.instance.chain
            ):
                return

            # ------------------------------------------------
            # Verify signatures
            # ------------------------------------------------

            try:

                vk = VerifyingKey.from_pem(
                    block1.creator
                )

            except Exception:
                return

            valid1 = False
            valid2 = False

            try:

                vk.verify(
                    block1.sign,
                    str(block1).encode()
                )

                valid1 = True

            except BadSignatureError:
                pass

            try:

                vk.verify(
                    block2.sign,
                    str(block2).encode()
                )

                valid2 = True

            except BadSignatureError:
                pass

            if not valid1 or not valid2:

                print(
                    "\nInvalid slashing evidence\n"
                )

                return

            # ------------------------------------------------
            # Blocks must actually conflict
            # ------------------------------------------------

            if block1.is_equal(block2):

                print(
                    "\nBlocks are identical; "
                    "no slashable conflict\n"
                )

                return

            # Both blocks must have the same position context
            if block1.prevHash != block2.prevHash:

                print(
                    "\nInvalid slashing evidence: "
                    "different previous hashes\n"
                )

                return

            # ------------------------------------------------
            # Slash creator
            # ------------------------------------------------

            current_block = (
                Chain.instance.chain[pos]
            )

            if (
                current_block.is_equal(block1)
                or current_block.is_equal(block2)
            ):

                if current_block.is_valid:

                    print(
                        f"\nBlock {pos} slashed\n"
                    )

                    current_block.is_valid = False
                    current_block.slash_creator = True

            await self.broadcast_message(
                msg
            )

        # ====================================================
        # CHAIN REQUEST
        # ====================================================

        elif message_type == "chain_request":

            if Chain.instance is None:
                return

            pkt = {
                "type": "chain",
                "id": str(uuid.uuid4()),
                "chain":
                    Chain.instance.to_block_dict_list()
            }

            self.seen_message_ids.add(
                pkt["id"]
            )

            await websocket.send(
                json.dumps(pkt)
            )

        # ====================================================
        # CHAIN
        # ====================================================

        elif message_type == "chain":

            print(
                "Received a Chain"
            )

            block_dict_list = msg.get(
                "chain"
            )

            if not isinstance(
                block_dict_list,
                list
            ) or not block_dict_list:

                return

            block_list = []

            for block_dict in block_dict_list:

                block = (
                    self.block_dict_to_block(
                        block_dict
                    )
                )

                if block is None:

                    print(
                        "\nInvalid block in chain\n"
                    )

                    return

                block_list.append(
                    block
                )

            try:

                if not isvalidChain(
                    block_list
                ):

                    print(
                        "\nInvalid Chain\n"
                    )

                    return

            except Exception as e:

                print(
                    f"\nChain validation error: {e}\n"
                )

                traceback.print_exc()

                return

            # ------------------------------------------------
            # First chain
            # ------------------------------------------------

            if Chain.instance is None:

                self.chain = Chain(
                    blockList=block_list
                )

                if self.activate_disk_save == "y":
                    self.save_chain_to_disk()

                return

            # ------------------------------------------------
            # Compare chains
            # ------------------------------------------------

            current_chain = (
                Chain.instance.chain
            )

            pos = (
                Chain.instance.checkEquivalence(
                    block_list
                )
            )

            # ------------------------------------------------
            # No divergence
            # ------------------------------------------------

            if pos == -1:

                if (
                    weight_of_chain(
                        current_chain
                    )
                    < weight_of_chain(
                        block_list
                    )
                ):

                    Chain.instance.rewrite(
                        block_list
                    )

                    if self.activate_disk_save == "y":
                        self.save_chain_to_disk()

                return

            # ------------------------------------------------
            # One chain ended
            # ------------------------------------------------

            if pos >= len(current_chain):

                if len(block_list) > len(
                    current_chain
                ):

                    Chain.instance.rewrite(
                        block_list
                    )

                return

            if pos >= len(block_list):
                return

            block1 = current_chain[pos]
            block2 = block_list[pos]

            # ------------------------------------------------
            # Same creator = normal fork
            # ------------------------------------------------

            if block1.creator == block2.creator:

                if len(block_list) > len(
                    current_chain
                ):

                    Chain.instance.rewrite(
                        block_list
                    )

                    if self.activate_disk_save == "y":
                        self.save_chain_to_disk()

            # ------------------------------------------------
            # Different creator = possible equivocation
            # ------------------------------------------------

            else:

                await self.verify_and_slash(
                    block1,
                    block2,
                    pos,
                    block_list
                )

            # ------------------------------------------------
            # Clean mempool
            # ------------------------------------------------

            async with self.mem_pool_lock:

                chain_tx_ids = set()

                for block in Chain.instance.chain:

                    for transaction in block.transactions:

                        chain_tx_ids.add(
                            transaction.id
                        )

                self.mem_pool = [
                    tx
                    for tx in self.mem_pool
                    if tx.id not in chain_tx_ids
                ]

            # ------------------------------------------------
            # Clean file pool
            # ------------------------------------------------

            async with self.file_hashes_lock:

                for cid in list(
                    self.file_hashes.keys()
                ):

                    if Chain.instance.cid_exists_in_chain(
                        cid
                    ):

                        self.file_hashes.pop(
                            cid,
                            None
                        )

    # ========================================================
    # VERIFY AND SLASH
    # ========================================================

    async def verify_and_slash(
        self,
        block1: Block,
        block2: Block,
        pos: int,
        block_list: List[Block]
    ):

        # Both blocks must have the same creator
        if block1.creator != block2.creator:
            return

        if block1.is_equal(block2):
            return

        try:

            vk = VerifyingKey.from_pem(
                block1.creator
            )

        except Exception:
            return

        sign1 = block1.sign
        sign2 = block2.sign

        valid1 = False
        valid2 = False

        # IMPORTANT FIX:
        #
        # Original code incorrectly did:
        #
        # vk.verify(sign1, str(block2).encode())
        #
        # sign1 must be checked against block1.

        try:

            vk.verify(
                sign1,
                str(block1).encode()
            )

            valid1 = True

        except BadSignatureError:
            pass

        try:

            vk.verify(
                sign2,
                str(block2).encode()
            )

            valid2 = True

        except BadSignatureError:
            pass

        # If both signatures aren't valid,
        # this isn't valid equivocation evidence.
        if not valid1 or not valid2:

            print(
                "\nInvalid slashing evidence\n"
            )

            return

        # The creator must have signed two different blocks
        # at the same position/context.
        if block1.prevHash != block2.prevHash:

            print(
                "\nInvalid slashing evidence: "
                "different previous hashes\n"
            )

            return

        print(
            f"\nEquivocation detected at block {pos}\n"
        )

        if (
            0 <= pos
            < len(Chain.instance.chain)
        ):

            Chain.instance.chain[
                pos
            ].is_valid = False

            Chain.instance.chain[
                pos
            ].slash_creator = True

        # IMPORTANT FIX:
        #
        # Original code sent:
        # evidence1 = block1
        # evidence2 = block1
        #
        # It must send block2 as evidence2.

        pkt = {
            "type": "slash_announcement",
            "id": str(uuid.uuid4()),

            "evidence1":
                block1.to_dict_with_stakers(),

            "evidence2":
                block2.to_dict_with_stakers(),

            "block1_sign":
                base64.b64encode(
                    block1.sign
                ).decode(),

            "block2_sign":
                base64.b64encode(
                    block2.sign
                ).decode(),

            "pos": pos
        }

        self.seen_message_ids.add(
            pkt["id"]
        )

        await self.broadcast_message(
            pkt
        )

    # ========================================================
    # CONNECTION HANDLING
    # ========================================================

    async def handle_connections(
        self,
        websocket
    ):

        remote = websocket.remote_address

        if remote:

            peer_addr = (
                remote[0],
                remote[1]
            )

        else:

            peer_addr = (
                "unknown",
                "unknown"
            )

        self.server_connections.add(
            websocket
        )

        print(
            f"Inbound Connection from "
            f"{peer_addr[0]}:{peer_addr[1]}"
        )

        try:

            async for raw in websocket:

                try:

                    msg = json.loads(raw)

                except json.JSONDecodeError:

                    print(
                        "Received invalid JSON"
                    )

                    continue

                await self.handle_messages(
                    websocket,
                    msg
                )

        except websockets.exceptions.ConnectionClosed:

            print(
                f"Inbound Connection Closed: "
                f"{peer_addr}"
            )

        except Exception as e:

            print(
                f"Inbound connection error: {e}"
            )

        finally:

            self.server_connections.discard(
                websocket
            )

            try:
                await websocket.close()
            except Exception:
                pass

    # ========================================================
    # BROADCAST
    # ========================================================

    async def broadcast_message(
        self,
        pkt
    ):

        targets = (
            self.server_connections
            | self.client_connections
        )

        dead_connections = []

        for ws in list(targets):

            try:

                await ws.send(
                    json.dumps(pkt)
                )

            except Exception as e:

                print(
                    f"Error broadcasting: {e}"
                )

                dead_connections.append(
                    ws
                )

        for ws in dead_connections:

            self.server_connections.discard(
                ws
            )

            self.client_connections.discard(
                ws
            )

            self.got_pong.pop(
                ws,
                None
            )

            self.have_sent_peer_info.pop(
                ws,
                None
            )

            try:

                if ws.remote_address:

                    endpoint = normalize_endpoint(
                        (
                            ws.remote_address[0],
                            ws.remote_address[1]
                        )
                    )

                    self.outbound_peers.discard(
                        endpoint
                    )

            except Exception:
                pass

            try:
                await ws.close()
            except Exception:
                pass

    # ========================================================
    # TRANSACTION CREATION
    # ========================================================

    async def create_and_broadcast_tx(
        self,
        receiver_public_key,
        payload
    ):

        if Chain.instance is None:
            print(
                "Blockchain has not been initialized"
            )
            return

        transaction = Transaction(
            payload,
            self.wallet.public_key_pem,
            receiver_public_key
        )

        transaction_str = str(
            transaction
        )

        signature = (
            self.wallet.private_key.sign(
                transaction_str.encode()
            )
        )

        transaction.sign = signature

        signature_b64 = (
            base64.b64encode(
                signature
            ).decode()
        )

        pkt = {
            "type": "new_tx",
            "id": str(uuid.uuid4()),
            "transaction":
                transaction_str,
            "sign":
                signature_b64,
            "sender_pem":
                self.wallet.public_key_pem
        }

        self.seen_message_ids.add(
            pkt["id"]
        )

        if Chain.instance.transaction_exists_in_chain(
            transaction
        ):

            return

        async with self.mem_pool_lock:

            # Prevent duplicate pending transactions
            if any(
                tx.id == transaction.id
                for tx in self.mem_pool
            ):
                return

            balance = Chain.instance.calc_balance(
                self.wallet.public_key_pem,
                self.mem_pool,
                list(self.current_stakes)
            )

            try:
                amount = transaction_amount(
                    transaction
                )
            except Exception:
                return

            if amount > balance:
                print(
                    "Insufficient balance"
                )
                return

            self.mem_pool.append(
                transaction
            )

        print(
            "Transaction Created",
            transaction
        )

        await self.broadcast_message(
            pkt
        )

    # ========================================================
    # CONTRACT STATE
    # ========================================================

    def get_contract_state(
        self,
        contract_id
    ):

        if Chain.instance is None:
            return {}

        for block in reversed(
            Chain.instance.chain
        ):

            for transaction in reversed(
                block.transactions
            ):

                if (
                    transaction.receiver
                    == "invoke"
                    and transaction.payload[0]
                    == contract_id
                ):

                    return transaction.payload[3]

        return {}

    # ========================================================
    # USER INPUT
    # ========================================================

    async def user_input_handler(self):

        loop = asyncio.get_running_loop()

        while True:

            print(
                "\nBlock Chain Menu\n"
                "***************"
            )

            if self.staker:

                print(
                    "0) Quit\n"
                    "1) Add Transaction\n"
                    "2) View balance\n"
                    "3) Print Chain\n"
                    "4) Print Pending Transactions\n"
                    "5) Print Current Stakers\n"
                    "6) Time since last epoch\n"
                    "7) Send Files\n"
                    "8) Download Files\n"
                    "9) Stake\n"
                )

            else:

                print(
                    "0) Quit\n"
                    "1) Add Transaction\n"
                    "2) View balance\n"
                    "3) Print Chain\n"
                    "4) Print Pending Transactions\n"
                    "5) Print Current Stakers\n"
                    "6) Time since last epoch\n"
                    "7) Send Files\n"
                    "8) Download Files\n"
                )

            ch = await loop.run_in_executor(
                None,
                input,
                "Enter Your Choice: "
            )

            try:

                ch = int(ch)

            except ValueError:

                print(
                    "\nPlease enter a valid number!!!\n"
                )

                continue

            # =================================================
            # ADD TRANSACTION
            # =================================================

            if ch == 1:

                if Chain.instance is None:

                    print(
                        "Blockchain is not initialized"
                    )

                    continue

                rec = await loop.run_in_executor(
                    None,
                    input,
                    "\nEnter Receiver's Name or Public Key: "
                )

                rec = rec.strip()

                # -------------------------------------------------
                # DEPLOY
                # -------------------------------------------------

                if rec.lower() == "deploy":

                    contract_code = (
                        await asyncio.to_thread(
                            get_contract_code_from_notepad
                        )
                    )

                    if not contract_code:

                        print(
                            "Contract code field is empty"
                        )

                        continue

                    gas_used = (
                        len(contract_code) // 10
                        + BASE_DEPLOY_COST
                    )

                    amount = (
                        gas_used * GAS_PRICE
                    )

                    payload = [
                        contract_code,
                        amount
                    ]

                    balance = (
                        Chain.instance.calc_balance(
                            self.wallet.public_key_pem,
                            self.mem_pool,
                            list(self.current_stakes)
                        )
                    )

                    if amount <= balance:

                        await self.create_and_broadcast_tx(
                            "deploy",
                            payload
                        )

                    else:

                        print(
                            "Insufficient Account Balance"
                        )

                # -------------------------------------------------
                # INVOKE
                # -------------------------------------------------

                elif rec.lower() == "invoke":

                    contract_id = (
                        await loop.run_in_executor(
                            None,
                            input,
                            "\nEnter Contract Id: "
                        )
                    )

                    if (
                        contract_id
                        not in self.contractsDB.contracts
                    ):

                        print(
                            "No such contract found..."
                        )

                        continue

                    func_name = (
                        await loop.run_in_executor(
                            None,
                            input,
                            "\nEnter Function Name: "
                        )
                    )

                    args = []

                    arg_number = 1

                    while True:

                        arg = (
                            await loop.run_in_executor(
                                None,
                                input,
                                f"Enter argument "
                                f"{arg_number} "
                                "(or \\q to finish): "
                            )
                        )

                        if arg.strip() == "\\q":
                            break

                        try:

                            parsed_arg = (
                                ast.literal_eval(arg)
                            )

                        except Exception:

                            parsed_arg = arg

                        args.append(
                            parsed_arg
                        )

                        arg_number += 1

                    try:

                        response = self.run_contract([
                            contract_id,
                            func_name,
                            args
                        ])

                    except Exception as e:

                        print(
                            f"Error: {e}"
                        )

                        continue

                    if response.get(
                        "error"
                    ) is not None:

                        print(
                            "Error:",
                            response["error"]
                        )

                        continue

                    state = response["state"]
                    gas_used = response["gas_used"]

                    amount = (
                        gas_used * GAS_PRICE
                    )

                    payload = [
                        contract_id,
                        func_name,
                        args,
                        state,
                        amount
                    ]

                    balance = (
                        Chain.instance.calc_balance(
                            self.wallet.public_key_pem,
                            self.mem_pool,
                            list(self.current_stakes)
                        )
                    )

                    if amount <= balance:

                        await self.create_and_broadcast_tx(
                            "invoke",
                            payload
                        )

                    else:

                        print(
                            "Insufficient Account Balance"
                        )

                # -------------------------------------------------
                # NORMAL TRANSFER
                # -------------------------------------------------

                else:

                    amt = await loop.run_in_executor(
                        None,
                        input,
                        "\nEnter Amount to send: "
                    )

                    receiver_public_key = (
                        self.name_to_public_key_dict.get(
                            rec.lower()
                        )
                    )

                    if receiver_public_key is None:

                        rec_refined = (
                            rec.replace(
                                "\\n",
                                "\n"
                            )
                        )

                        for pk in (
                            self.name_to_public_key_dict.values()
                        ):

                            if pk == rec_refined:

                                receiver_public_key = pk
                                break

                    if receiver_public_key is None:

                        print(
                            "No person available "
                            "with provided name "
                            "or public key..."
                        )

                        continue

                    try:

                        amt = float(amt)

                    except ValueError:

                        print(
                            "Amount must be a number"
                        )

                        continue

                    if amt <= 0:

                        print(
                            "\nAmount must be positive\n"
                        )

                        continue

                    balance = (
                        Chain.instance.calc_balance(
                            self.wallet.public_key_pem,
                            self.mem_pool,
                            list(self.current_stakes)
                        )
                    )

                    if amt <= balance:

                        await self.create_and_broadcast_tx(
                            receiver_public_key,
                            amt
                        )

                    else:

                        print(
                            "Insufficient Account Balance"
                        )

            # =================================================
            # BALANCE
            # =================================================

            elif ch == 2:

                if Chain.instance is None:
                    print(
                        "Blockchain not initialized"
                    )
                    continue

                balance = (
                    Chain.instance.calc_balance(
                        self.wallet.public_key_pem,
                        self.mem_pool,
                        list(self.current_stakes)
                    )
                )

                print(
                    "Account Balance =",
                    balance
                )

            # =================================================
            # PRINT CHAIN
            # =================================================

            elif ch == 3:

                if Chain.instance is None:

                    print(
                        "\nChain hasn't "
                        "been initialized yet\n"
                    )

                    continue

                for i, block in enumerate(
                    Chain.instance.chain
                ):

                    print(
                        f"block{i}: {block}\n"
                    )

            # =================================================
            # PENDING TRANSACTIONS
            # =================================================

            elif ch == 4:

                for i, transaction in enumerate(
                    self.mem_pool
                ):

                    print(
                        f"transaction{i}: "
                        f"{transaction}\n"
                    )

            # =================================================
            # CURRENT STAKERS
            # =================================================

            elif ch == 5:

                async with (
                    self.curr_stakers_condition
                ):

                    print()

                    for key, value in (
                        self.current_stakers.items()
                    ):

                        print(
                            f"{key}:{value}\n"
                        )

                    print()

            # =================================================
            # TIME
            # =================================================

            elif ch == 6:

                elapsed = (
                    datetime.now()
                    - self.last_epoch_end_ts
                ).total_seconds()

                print(
                    f"\n{elapsed:.2f}\n"
                )

            # =================================================
            # UPLOAD
            # =================================================

            elif ch == 7:

                desc = await loop.run_in_executor(
                    None,
                    input,
                    "\nEnter description of file: "
                )

                path = await loop.run_in_executor(
                    None,
                    input,
                    "\nEnter path of file: "
                )

                pkt = await self.uploadFile(
                    desc,
                    path
                )

                if pkt:
                    await self.broadcast_message(
                        pkt
                    )

            # =================================================
            # DOWNLOAD
            # =================================================

            elif ch == 8:

                cid = await loop.run_in_executor(
                    None,
                    input,
                    "\nEnter cid of file: "
                )

                path = await loop.run_in_executor(
                    None,
                    input,
                    "\nEnter path to download "
                    "the file: "
                )

                try:

                    await asyncio.to_thread(
                        download_ipfs_file_subprocess,
                        cid,
                        path
                    )

                except Exception as e:

                    print(
                        f"Download failed: {e}"
                    )

            # =================================================
            # STAKE
            # =================================================

            elif ch == 9:

                if not self.staker:
                    continue

                currTime = datetime.now()

                time_since = (
                    currTime
                    - self.last_epoch_end_ts
                )

                if self.staked_amt > 0:

                    print(
                        "Can't send multiple "
                        "stakes in one epoch"
                    )

                    continue

                # Registration period
                if (
                    time_since
                    > timedelta(
                        seconds=MIN_BLOCK_INTERVAL
                    )
                ):

                    if (
                        time_since
                        > timedelta(
                            seconds=EPOCH_TIME * 7 / 6
                        )
                    ):

                        self.last_epoch_end_ts = (
                            datetime.now()
                        )

                        self.staked_amt = 0

                        async with (
                            self.curr_stakers_condition
                        ):

                            self.current_stakers.clear()
                            self.current_stakes.clear()

                        time_since = timedelta(0)

                    else:

                        print(
                            "\nStake registration "
                            "period closed, "
                            "try again in next epoch\n"
                        )

                        continue

                amt = await loop.run_in_executor(
                    None,
                    input,
                    "\nEnter Amount to stake: "
                )

                try:

                    amt = int(amt)

                    balance = (
                        Chain.instance.calc_balance(
                            self.wallet.public_key_pem,
                            self.mem_pool,
                            list(self.current_stakes)
                        )
                    )

                    if amt > balance:

                        print(
                            "\nInsufficient bank balance\n"
                        )

                        continue

                    if amt <= 0:

                        print(
                            "\nInvalid amount\n"
                        )

                        continue

                    await self.send_stake_announcements(
                        amt
                    )

                    self.staked_amt = amt

                    time_left = (
                        EPOCH_TIME
                        - int(
                            time_since.total_seconds()
                        )
                    )

                    print(
                        f"Creating block in "
                        f"{time_left} seconds"
                    )

                    if self.mine_task:
                        self.mine_task.cancel()

                    self.mine_task = (
                        asyncio.create_task(
                            self.create_blocks(
                                time_left
                            )
                        )
                    )

                except ValueError as e:

                    print(
                        "\nPlease enter a valid "
                        f"number!!!\n{e}"
                    )

                except Exception as e:

                    print(
                        "\nUnexpected error "
                        f"occurred!!!\n{e}"
                    )

            # =================================================
            # QUIT
            # =================================================

            elif ch == 0:

                print(
                    "Quitting..."
                )

                break

            else:

                print(
                    "\nInvalid choice\n"
                )

    # ========================================================
    # IPFS
    # ========================================================

    async def uploadFile(
        self,
        desc: str,
        path: str
    ):

        file_path = Path(path)

        if not file_path.is_file():

            print(
                "\nFile doesn't exist\n"
            )

            return None

        if not self.daemon_process:

            self.start_daemon()

        cid, name = await asyncio.to_thread(
            addToIpfs,
            path
        )

        if not cid or not name:
            return None

        print(
            f"\nNew File Created : {cid}\n"
        )

        pkt = {
            "type": "file",
            "id": str(uuid.uuid4()),
            "desc": desc,
            "cid": cid
        }

        self.seen_message_ids.add(
            pkt["id"]
        )

        async with self.file_hashes_lock:

            self.file_hashes[cid] = desc

        return pkt

    def init_repo(self):

        if not self.repo_path.exists():

            subprocess.run(
                ["ipfs", "init"],
                env=self.env,
                check=True
            )

            print(
                "\nIPFS repo created\n"
            )

    def configure_ports(self):

        subprocess.run(
            [
                "ipfs",
                "config",
                "Addresses.API",
                f"/ip4/127.0.0.1/tcp/{self.ipfs_port}"
            ],
            env=self.env,
            check=True
        )

        subprocess.run(
            [
                "ipfs",
                "config",
                "Addresses.Gateway",
                f"/ip4/127.0.0.1/tcp/{self.gateway_port}"
            ],
            env=self.env,
            check=True
        )

        subprocess.run(
            [
                "ipfs",
                "config",
                "Addresses.Swarm",
                "--json",
                f'["/ip4/127.0.0.1/tcp/'
                f'{self.swarm_tcp}", '
                f'"/ip4/127.0.0.1/udp/'
                f'{self.swarm_udp}/quic"]'
            ],
            env=self.env,
            check=True
        )

        print(
            "\nConfigured Ports\n"
        )

    def start_daemon(self):

        if self.daemon_process is not None:
            return

        self.daemon_process = subprocess.Popen(
            ["ipfs", "daemon"],
            env=self.env
        )

        print(
            "\nIPFS Daemon Started\n"
        )

    def stop_daemon(self):

        if self.daemon_process:

            try:

                self.daemon_process.terminate()
                self.daemon_process.wait(
                    timeout=5
                )

            except Exception:

                try:
                    self.daemon_process.kill()
                except Exception:
                    pass

            self.daemon_process = None

    # ========================================================
    # PEER CONNECTION
    # ========================================================

    async def connect_to_peer(
        self,
        host,
        port
    ):

        endpoint = (
            normalize_endpoint(
                (host, port)
            )
        )

        if (
            endpoint in self.outbound_peers
            or endpoint
            == normalize_endpoint(
                (self.host, self.port)
            )
        ):

            return

        uri = (
            f"ws://{endpoint[0]}:{endpoint[1]}"
        )

        websocket = None

        try:

            websocket = await websockets.connect(
                uri
            )

            self.client_connections.add(
                websocket
            )

            self.outbound_peers.add(
                endpoint
            )

            self.have_sent_peer_info[
                websocket
            ] = False

            print(
                f"Outbound connection formed "
                f"to {host}:{port}"
            )

            if Chain.instance is None:

                pkt = {
                    "type": "add_peer",
                    "id": str(uuid.uuid4()),
                    "data": {
                        "host": self.host,
                        "port": self.port,
                        "name": self.name,
                        "public_key":
                            self.wallet.public_key_pem
                    }
                }

            else:

                pkt = {
                    "type": "ping",
                    "id": str(uuid.uuid4())
                }

            self.seen_message_ids.add(
                pkt["id"]
            )

            await websocket.send(
                json.dumps(pkt)
            )

            async for raw in websocket:

                try:

                    msg = json.loads(raw)

                except json.JSONDecodeError:
                    continue

                await self.handle_messages(
                    websocket,
                    msg
                )

        except Exception as e:

            print(
                f"Failed to connect to "
                f"{host}:{port} ::: {e}"
            )

        finally:

            if websocket:

                self.client_connections.discard(
                    websocket
                )

            self.outbound_peers.discard(
                endpoint
            )

            if websocket:

                self.got_pong.pop(
                    websocket,
                    None
                )

                self.have_sent_peer_info.pop(
                    websocket,
                    None
                )

                try:
                    await websocket.close()
                except Exception:
                    pass

    # ========================================================
    # PEER DISCOVERY
    # ========================================================

    async def discover_peers(self):

        while True:

            try:

                if (
                    len(self.outbound_peers)
                    < MAX_CONNECTIONS
                ):

                    potential_peers = {
                        endpoint
                        for endpoint
                        in self.known_peers
                        if (
                            endpoint
                            not in self.outbound_peers
                            and endpoint
                            != normalize_endpoint(
                                (
                                    self.host,
                                    self.port
                                )
                            )
                        )
                    }

                    while (
                        len(self.outbound_peers)
                        < MAX_CONNECTIONS
                        and potential_peers
                    ):

                        new_peer = (
                            get_random_element(
                                potential_peers
                            )
                        )

                        potential_peers.discard(
                            new_peer
                        )

                        if new_peer:

                            asyncio.create_task(
                                self.connect_to_peer(
                                    *new_peer
                                )
                            )

                            await asyncio.sleep(
                                1
                            )

                await asyncio.sleep(30)

            except asyncio.CancelledError:
                raise

            except Exception as e:

                print(
                    f"Peer discovery error: {e}"
                )

                await asyncio.sleep(30)

    # ========================================================
    # GOSSIP SAMPLER
    # ========================================================

    async def gossip_peer_sampler(self):

        while True:

            try:

                await asyncio.sleep(60)

                if (
                    len(self.known_peers)
                    <= len(self.outbound_peers)
                    or len(self.outbound_peers)
                    < MAX_CONNECTIONS
                ):

                    continue

                to_drop = (
                    get_random_element(
                        self.client_connections
                    )
                )

                if to_drop:

                    print(
                        "Gossip Sampling: "
                        f"Disconnecting "
                        f"{to_drop.remote_address}"
                    )

                    self.client_connections.discard(
                        to_drop
                    )

                    try:

                        if to_drop.remote_address:

                            endpoint = (
                                normalize_endpoint(
                                    (
                                        to_drop.remote_address[0],
                                        to_drop.remote_address[1]
                                    )
                                )
                            )

                            self.outbound_peers.discard(
                                endpoint
                            )

                    except Exception:
                        pass

                    self.got_pong.pop(
                        to_drop,
                        None
                    )

                    self.have_sent_peer_info.pop(
                        to_drop,
                        None
                    )

                    try:
                        await to_drop.close()
                    except Exception:
                        pass

                potential_peers = {
                    endpoint
                    for endpoint
                    in self.known_peers
                    if (
                        endpoint
                        not in self.outbound_peers
                        and endpoint
                        != normalize_endpoint(
                            (
                                self.host,
                                self.port
                            )
                        )
                    )
                }

                if potential_peers:

                    new_peer = (
                        get_random_element(
                            potential_peers
                        )
                    )

                    if new_peer:

                        print(
                            "Gossip Sampling: "
                            f"Connecting to "
                            f"{new_peer}"
                        )

                        asyncio.create_task(
                            self.connect_to_peer(
                                *new_peer
                            )
                        )

            except asyncio.CancelledError:
                raise

            except Exception as e:

                print(
                    f"Gossip sampler error: {e}"
                )

    # ========================================================
    # STAKING
    # ========================================================

    async def send_stake_announcements(
        self,
        amt: int
    ):

        new_stake = Stake(
            self.wallet.public_key_pem,
            amt
        )

        sign = (
            self.wallet.private_key.sign(
                str(new_stake).encode()
            )
        )

        new_stake.sign = sign

        stake_dict = (
            new_stake.to_dict()
        )

        stake_dict["sign"] = (
            base64.b64encode(
                sign
            ).decode()
        )

        pkt = {
            "id": str(uuid.uuid4()),
            "type":
                "stake_announcement",
            "public_key":
                self.wallet.public_key_pem,
            "stake":
                stake_dict
        }

        self.seen_message_ids.add(
            pkt["id"]
        )

        async with self.curr_stakers_condition:

            if self.wallet.public_key_pem in (
                self.current_stakers
            ):

                print(
                    "Already staked this epoch"
                )

                return

            self.current_stakers[
                self.wallet.public_key_pem
            ] = amt

            self.current_stakes.add(
                new_stake
            )

        self.staked_amt = amt

        print(
            "Stake Created"
        )

        await self.broadcast_message(
            pkt
        )

    # ========================================================
    # EPOCH RESET
    # ========================================================

    async def restart_epoch(self):

        while True:

            try:

                await asyncio.sleep(
                    EPOCH_TIME / 2
                )

                currTime = datetime.now()

                if (
                    currTime
                    - self.last_epoch_end_ts
                    > timedelta(
                        seconds=EPOCH_TIME * 7 / 6
                    )
                ):

                    self.last_epoch_end_ts = (
                        datetime.now()
                    )

                    self.staked_amt = 0

                    async with (
                        self.curr_stakers_condition
                    ):

                        self.current_stakers.clear()
                        self.current_stakes.clear()

            except asyncio.CancelledError:
                raise

    # ========================================================
    # CREATE BLOCK
    # ========================================================

    async def create_blocks(
        self,
        delay
    ):

        if not self.staker:

            print(
                "This peer is not a staker"
            )

            return

        try:

            await asyncio.sleep(
                delay
            )

            if Chain.instance is None:
                return

            # ------------------------------------------------
            # Snapshot epoch state
            # ------------------------------------------------

            async with (
                self.curr_stakers_condition
            ):

                stakers_snapshot = dict(
                    self.current_stakers
                )

                stakes_snapshot = list(
                    self.current_stakes
                )

                my_stake = (
                    self.staked_amt
                )

            if not stakers_snapshot:

                print(
                    "\nNo stakers\n"
                )

                self.last_epoch_end_ts = (
                    datetime.now()
                )

                return

            # ------------------------------------------------
            # Pending transactions
            # ------------------------------------------------

            async with self.mem_pool_lock:

                pending_transactions = [
                    tx
                    for tx in self.mem_pool
                    if not Chain.instance.transaction_exists_in_chain(
                        tx
                    )
                ]

            if not pending_transactions:

                print(
                    "\nNo pending transactions\n"
                )

                self.last_epoch_end_ts = (
                    datetime.now()
                )

                async with (
                    self.curr_stakers_condition
                ):

                    self.current_stakers.clear()
                    self.current_stakes.clear()

                return

            # ------------------------------------------------
            # VRF
            # ------------------------------------------------

            print(
                "\nRunning VRF\n"
            )

            seed = (
                Chain.instance.epoch_seed()
            )

            if not seed:
                return

            vrf_proof = (
                self.wallet.private_key.sign(
                    seed.encode()
                )
            )

            vrf_output = hashlib.sha256(
                vrf_proof
            ).hexdigest()

            vrf_output_int = int(
                vrf_output,
                16
            )

            total_stake = sum(
                stakers_snapshot.values()
            )

            if total_stake <= 0:
                return

            if my_stake <= 0:
                return

            threshold = (
                my_stake
                / total_stake
            ) * MAX_OUTPUT

            # ------------------------------------------------
            # FIX:
            # If output > threshold, we LOSE.
            # If output <= threshold, we WIN.
            # ------------------------------------------------

            if vrf_output_int > threshold:

                print(
                    "\nYou've lost\n"
                )

                self.staked_amt = 0

                return

            # ------------------------------------------------
            # Winner
            # ------------------------------------------------

            print(
                "\nYou won\n"
            )

            newBlock = Block(
                Chain.instance.lastBlock.hash,
                pending_transactions
            )

            newBlock.files = (
                self.file_hashes.copy()
            )

            newBlock.seed = seed
            newBlock.vrf_proof = vrf_proof
            newBlock.staked_amt = my_stake
            newBlock.creator = (
                self.wallet.public_key_pem
            )

            # IMPORTANT FIX:
            # current_stakers is a dict.
            # Block.stakers must be List[Stake].

            newBlock.stakers = (
                stakes_snapshot
            )

            # ------------------------------------------------
            # Sign block
            # ------------------------------------------------

            sign = (
                self.wallet.private_key.sign(
                    str(newBlock).encode()
                )
            )

            newBlock.sign = sign

            # ------------------------------------------------
            # Validate our own block before broadcasting
            # ------------------------------------------------

            if not Chain.instance.isValidBlock(
                newBlock
            ):

                print(
                    "\nLocally created block "
                    "failed validation\n"
                )

                return

            Chain.instance.chain.append(
                newBlock
            )

            self.last_epoch_end_ts = (
                datetime.now()
            )

            print(
                "Block Appended"
            )

            # ------------------------------------------------
            # Deploy contracts
            # ------------------------------------------------

            for transaction in (
                newBlock.transactions
            ):

                if transaction.receiver == "deploy":

                    self.deploy_contract(
                        transaction
                    )

            # ------------------------------------------------
            # Remove included transactions
            # ------------------------------------------------

            async with self.mem_pool_lock:

                included_ids = {
                    tx.id
                    for tx
                    in newBlock.transactions
                }

                self.mem_pool = [
                    tx
                    for tx in self.mem_pool
                    if tx.id not in included_ids
                ]

            # ------------------------------------------------
            # Remove included files
            # ------------------------------------------------

            async with self.file_hashes_lock:

                for cid in list(
                    self.file_hashes.keys()
                ):

                    if newBlock.cid_exists_in_block(
                        cid
                    ):

                        self.file_hashes.pop(
                            cid,
                            None
                        )

            # ------------------------------------------------
            # Reset staking state
            # ------------------------------------------------

            async with (
                self.curr_stakers_condition
            ):

                self.staked_amt = 0
                self.current_stakers.clear()
                self.current_stakes.clear()

            # ------------------------------------------------
            # Broadcast
            # ------------------------------------------------

            vrf_proof_b64 = (
                base64.b64encode(
                    vrf_proof
                ).decode()
            )

            sign_b64 = (
                base64.b64encode(
                    sign
                ).decode()
            )

            pkt = {
                "type": "new_block",
                "id": str(uuid.uuid4()),

                "block":
                    newBlock.to_dict_with_stakers(),

                "vrf_proof":
                    vrf_proof_b64,

                "sign":
                    sign_b64
            }

            self.seen_message_ids.add(
                pkt["id"]
            )

            await self.broadcast_message(
                pkt
            )

            if self.activate_disk_save == "y":
                self.save_chain_to_disk()

        except asyncio.CancelledError:

            raise

        except Exception as e:

            print(
                f"Block creation error: {e}"
            )

            traceback.print_exc()

    # ========================================================
    # CHAIN SYNCHRONIZATION
    # ========================================================

    async def find_longest_chain(self):

        while True:

            try:

                pkt = {
                    "type": "chain_request",
                    "id": str(uuid.uuid4())
                }

                self.seen_message_ids.add(
                    pkt["id"]
                )

                await self.broadcast_message(
                    pkt
                )

                print(
                    "\nSent out chain requests..."
                )

                await asyncio.sleep(
                    60
                )

            except asyncio.CancelledError:
                raise

    # ========================================================
    # CONTRACT FUNCTIONS
    # ========================================================

    def calculate_contract_id(
        self,
        sender,
        timestamp
    ):

        data = (
            f"{sender}:{timestamp}"
        )

        return hashlib.sha256(
            data.encode("utf-8")
        ).hexdigest()

    def deploy_contract(
        self,
        transaction
    ):

        sender = transaction.sender
        timestamp = transaction.ts
        code = transaction.payload[0]

        contract_id = (
            self.calculate_contract_id(
                sender,
                timestamp
            )
        )

        self.contractsDB.store_contract(
            contract_id,
            code
        )

        print(
            "Contract deployed with id:",
            contract_id
        )

    def run_contract(
        self,
        payload
    ):

        contract_id = payload[0]
        func_name = payload[1]
        args = payload[2]

        code = (
            self.contractsDB.get_contract(
                contract_id
            )
        )

        if code is None:

            raise Exception(
                f"Contract '{contract_id}' "
                "not found."
            )

        state = (
            self.get_contract_state(
                contract_id
            )
        )

        executor = (
            SecureContractExecutor(
                code
            )
        )

        return executor.run(
            func_name,
            args,
            state
        )

    # ========================================================
    # START
    # ========================================================

    async def start(
        self,
        bootstrap_host=None,
        bootstrap_port=None,
        web_mode=False
    ):

        server = await websockets.serve(
            self.handle_connections,
            self.host,
            self.port
        )

        print(
            f"WebSocket server running on "
            f"{self.host}:{self.port}"
        )

        # ----------------------------------------------------
        # Bootstrap
        # ----------------------------------------------------

        if (
            bootstrap_host
            and bootstrap_port
        ):

            try:

                normalized_bootstrap_host, \
                normalized_bootstrap_port = (
                    normalize_endpoint(
                        (
                            bootstrap_host,
                            bootstrap_port
                        )
                    )
                )

                asyncio.create_task(
                    self.connect_to_peer(
                        normalized_bootstrap_host,
                        normalized_bootstrap_port
                    )
                )

            except Exception as e:

                print(
                    f"Bootstrap connection error: {e}"
                )

        else:

            # First node creates genesis.
            self.chain = Chain(
                publicKey=self.wallet.public_key_pem,
                privatekey=self.wallet.private_key
            )

            self.last_epoch_end_ts = (
                datetime.now()
            )

        # ----------------------------------------------------
        # Background tasks
        # ----------------------------------------------------

        reset_task = asyncio.create_task(
            self.restart_epoch()
        )

        inp_task = None if web_mode else asyncio.create_task(
            self.user_input_handler()
        )

        consensus_task = asyncio.create_task(
            self.find_longest_chain()
        )

        disc_task = asyncio.create_task(
            self.discover_peers()
        )

        sampler_task = asyncio.create_task(
            self.gossip_peer_sampler()
        )

        try:

            if inp_task is not None:
                await inp_task
            else:
                await asyncio.Event().wait()

        finally:

            for task in [
                reset_task,
                consensus_task,
                disc_task,
                sampler_task
            ]:

                task.cancel()

            await asyncio.gather(
                reset_task,
                consensus_task,
                disc_task,
                sampler_task,
                return_exceptions=True
            )

            self.stop_daemon()

            server.close()

            await server.wait_closed()