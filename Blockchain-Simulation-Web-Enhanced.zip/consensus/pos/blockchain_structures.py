import json
import hashlib
import uuid
import base64
from typing import List, Dict
from datetime import datetime, timedelta

from ecdsa import (
    SigningKey,
    SECP256k1,
    VerifyingKey,
    BadSignatureError
)

from shared_blockchain_structures import (
    Transaction,
    BaseBlock,
    CommonChain,
    Wallet,
    txs_to_json_digestable_form,
    valid_chain_length
)


GAS_PRICE = 0.001
MAX_OUTPUT = 2 ** 256
EPOCH_TIME = 60
MIN_BLOCK_TIME = EPOCH_TIME * 5 / 6


# ============================================================
# Helper functions
# ============================================================

def timestamp_to_datetime(ts):
    """
    Convert all supported timestamp formats to datetime.

    IMPORTANT:
    datetime.timestamp() returns seconds, NOT milliseconds.
    The old code divided timestamps by 1000, which was incorrect.
    """
    if isinstance(ts, (int, float)):
        return datetime.fromtimestamp(ts)

    if isinstance(ts, str):
        return datetime.fromisoformat(ts)

    if isinstance(ts, datetime):
        return ts

    raise ValueError("Invalid timestamp format")


def transaction_amount(transaction: Transaction):
    """
    Return the amount spent by a transaction.
    """
    if transaction.receiver in ("deploy", "invoke"):
        return transaction.payload[-1]

    return transaction.payload


# ============================================================
# Stake
# ============================================================

class Stake:

    def __init__(self, staker: str, amt: int, ts=None):
        self.id = str(uuid.uuid4())
        self.staker = staker
        self.amt = amt
        self.sign: bytes = None

        # timestamp is stored in seconds
        self.ts = ts if ts is not None else datetime.now().timestamp()

    def to_dict(self):
        return {
            "id": self.id,
            "staker": self.staker,
            "amt": self.amt,
            "ts": self.ts
        }

    def __str__(self):
        return json.dumps(self.to_dict(), sort_keys=True)


# ============================================================
# Block
# ============================================================

class Block(BaseBlock):

    def __init__(
        self,
        prevHash: str,
        transactions: List[Transaction],
        ts=None,
        id=None
    ):
        super().__init__(prevHash, transactions, ts, id)

        self.creator: str = ""
        self.staked_amt = 0

        self.stakers: List[Stake] = []

        self.seed: str = ""
        self.vrf_proof: bytes = None
        self.sign: bytes = None

        self.is_valid: bool = True
        self.slash_creator = False

    def to_dict(self):
        return {
            "id": self.id,
            "prevHash": self.prevHash,
            "transactions": txs_to_json_digestable_form(
                self.transactions
            ),
            "ts": self.ts,
            "creator": self.creator,
            "staked_amt": self.staked_amt,
            "files": self.files
        }

    def to_dict_with_stakers(self):

        block_dict = self.to_dict()

        stakes_dict_list: List[Dict] = []

        for stake in self.stakers:

            stake_dict = stake.to_dict()

            if stake.sign:
                stake_dict["sign"] = base64.b64encode(
                    stake.sign
                ).decode()

            stakes_dict_list.append(stake_dict)

        block_dict["stakers"] = stakes_dict_list

        if self.vrf_proof is not None:
            block_dict["vrf_proof_b64"] = base64.b64encode(
                self.vrf_proof
            ).decode()

        if self.seed:
            block_dict["seed"] = self.seed

        return block_dict

    def __str__(self):
        return json.dumps(self.to_dict(), sort_keys=True)

    def is_equal(self, other):

        if not isinstance(other, Block):
            return False

        if len(self.transactions) != len(other.transactions):
            return False

        for tx1, tx2 in zip(self.transactions, other.transactions):
            if tx1 != tx2:
                return False

        # BUG FIX:
        # Old code had:
        # self.creator == self.creator
        #
        # which is always True.
        return (
            self.id == other.id
            and self.ts == other.ts
            and self.prevHash == other.prevHash
            and self.hash == other.hash
            and self.sign == other.sign
            and self.creator == other.creator
            and self.staked_amt == other.staked_amt
            and self.seed == other.seed
            and self.vrf_proof == other.vrf_proof
            and self.is_valid == other.is_valid
            and self.slash_creator == other.slash_creator
        )

    @property
    def hash(self):
        block_str = json.dumps(
            self.to_dict(),
            sort_keys=True
        )

        return hashlib.sha256(
            block_str.encode()
        ).hexdigest()


# ============================================================
# Balance calculation
# ============================================================

def calc_balance_block_list(
    block_list: List[Block],
    publicKey,
    i,
    mem_pool: List[Transaction] = None,
    currStakes: List[Stake] = None
):

    if mem_pool is None:
        mem_pool = []

    if currStakes is None:
        currStakes = []

    bal = 0

    valid_len = valid_chain_length(i)

    # Prevent invalid range if helper returns an unexpected value
    valid_len = max(0, min(valid_len, len(block_list)))

    for block_index in range(valid_len):

        current_block = block_list[block_index]

        # Slashing penalty
        if (
            current_block.slash_creator
            and current_block.creator == publicKey
        ):
            bal -= current_block.staked_amt

        if not current_block.is_valid:
            continue

        for transaction in current_block.transactions:

            if transaction.sender == publicKey:

                bal -= transaction_amount(transaction)

            elif transaction.receiver == publicKey:

                # deploy/invoke may not represent a normal transfer
                # to the receiver, so only credit ordinary transfers.
                if transaction.receiver not in ("deploy", "invoke"):
                    bal += transaction.payload

        # Block creator reward
        if current_block.creator == publicKey:
            bal += 6

    # Transactions already present after finalized portion
    # still consume balance to prevent double spending.
    if valid_len < len(block_list):

        for block_index in range(valid_len, len(block_list)):

            current_block = block_list[block_index]

            for transaction in current_block.transactions:

                if transaction.sender == publicKey:
                    bal -= transaction_amount(transaction)

    # Pending transactions
    for transaction in mem_pool:

        if transaction.sender == publicKey:
            bal -= transaction_amount(transaction)

    # Current stakes
    for stake in currStakes:

        if stake.staker == publicKey:
            bal -= stake.amt

    return bal


# ============================================================
# Chain weight
# ============================================================

def weight_of_chain(block_list: List[Block]):

    total_weight = 0

    for block in block_list:

        for stake in block.stakers:
            total_weight += stake.amt

    return total_weight


# ============================================================
# Chain
# ============================================================

class Chain(CommonChain):

    instance = None

    def __init__(
        self,
        publicKey: str = None,
        privatekey=None,
        blockList: List[Block] = None
    ):

        """
        If this is the first node, create genesis block.

        Otherwise receive blockList from bootstrap node.
        """

        if Chain.instance is not None:
            return

        if publicKey and not blockList:

            genesis_block = Block(
                None,
                [Transaction(50, "Genesis", publicKey)]
            )

            genesis_block.creator = publicKey

            if privatekey is None:
                raise ValueError(
                    "Private key is required to create genesis block"
                )

            genesis_block.sign = privatekey.sign(
                str(genesis_block).encode()
            )

            super().__init__(
                genesis_block=genesis_block
            )

        elif blockList is not None and not publicKey:

            super().__init__(
                block_list=blockList
            )

        else:
            raise ValueError("Invalid arguments")

        Chain.instance = self

    # --------------------------------------------------------
    # Serialization
    # --------------------------------------------------------

    def to_block_dict_list(self):

        block_dict_list = []

        for block in self.chain:

            block_dict = block.to_dict_with_stakers()

            if block.sign:
                block_dict["sign"] = base64.b64encode(
                    block.sign
                ).decode()

            block_dict_list.append(block_dict)

        return block_dict_list

    # --------------------------------------------------------
    # Rewrite chain
    # --------------------------------------------------------

    def rewrite(self, blockList: List[Block]):

        if not blockList:
            return

        if not isvalidChain(blockList):
            return

        if weight_of_chain(self.chain) >= weight_of_chain(blockList):
            return

        Chain.instance.chain = blockList.copy()

    # --------------------------------------------------------
    # Validate individual block
    # --------------------------------------------------------

    def isValidBlock(self, block: Block):

        if not self.chain:
            return False

        # Check previous hash
        if self.lastBlock.hash != block.prevHash:

            print("Hash Problem")
            print(
                f"Actual prev hash: {self.lastBlock.hash}\n"
                f"My prev hash: {block.prevHash}"
            )

            return False

        mem_pool = []

        # ----------------------------------------------------
        # Validate transactions
        # ----------------------------------------------------

        for transaction in block.transactions:

            # Duplicate transaction check
            if Chain.instance.transaction_exists_in_chain(
                transaction
            ):
                print("Duplicate transaction(s)")
                return False

            sign = transaction.sign

            if not sign:
                print("Transaction has no signature")
                return False

            try:

                vk = VerifyingKey.from_pem(
                    transaction.sender
                )

                vk.verify(
                    sign,
                    str(transaction).encode()
                )

            except (
                BadSignatureError,
                ValueError,
                TypeError
            ):

                print("\nFake Transactions\n")
                return False

            amount = transaction_amount(transaction)

            if amount <= 0:
                return False

            balance = Chain.instance.calc_balance(
                publicKey=transaction.sender,
                pending_transactions=mem_pool,
                current_stakes=block.stakers
            )

            if amount > balance:
                return False

            mem_pool.append(transaction)

        # ----------------------------------------------------
        # Validate stakes
        # ----------------------------------------------------

        currStakes = []

        for stake in block.stakers:

            if stake.sign is None:
                print("\nInvalid stake: missing signature\n")
                return False

            if stake.amt <= 0:
                return False

            try:

                vk = VerifyingKey.from_pem(
                    stake.staker
                )

                vk.verify(
                    stake.sign,
                    str(stake).encode()
                )

            except (
                BadSignatureError,
                ValueError,
                TypeError
            ):

                print("\nInvalid signature on stake\n")
                return False

            balance = Chain.instance.calc_balance(
                stake.staker,
                mem_pool,
                currStakes
            )

            if stake.amt > balance:
                return False

            currStakes.append(stake)

        # ----------------------------------------------------
        # Validate creator
        # ----------------------------------------------------

        if block.creator == "":
            return False

        creator_balance = Chain.instance.calc_balance(
            publicKey=block.creator,
            pending_transactions=mem_pool,
            current_stakes=block.stakers
        )

        if creator_balance < 0:
            return False

        return True

    # --------------------------------------------------------
    # Balance
    # --------------------------------------------------------

    def calc_balance(
        self,
        publicKey,
        pending_transactions: List[Transaction] = None,
        current_stakes: List[Stake] = None
    ):

        if pending_transactions is None:
            pending_transactions = []

        if current_stakes is None:
            current_stakes = []

        bal = 0

        valid_len = valid_chain_length(
            len(self.chain)
        )

        valid_len = max(
            0,
            min(valid_len, len(self.chain))
        )

        # ----------------------------------------------------
        # Finalized blocks
        # ----------------------------------------------------

        for i in range(valid_len):

            current_block = self.chain[i]

            if (
                current_block.slash_creator
                and current_block.creator == publicKey
            ):
                bal -= current_block.staked_amt

            if not current_block.is_valid:
                continue

            for transaction in current_block.transactions:

                if transaction.sender == publicKey:

                    bal -= transaction_amount(transaction)

                elif transaction.receiver == publicKey:

                    if transaction.receiver not in (
                        "deploy",
                        "invoke"
                    ):
                        bal += transaction.payload

            if current_block.creator == publicKey:
                bal += 6

        # ----------------------------------------------------
        # Non-finalized blocks
        # ----------------------------------------------------

        if valid_len < len(self.chain):

            for i in range(valid_len, len(self.chain)):

                current_block = self.chain[i]

                for transaction in current_block.transactions:

                    if transaction.sender == publicKey:
                        bal -= transaction_amount(
                            transaction
                        )

        # ----------------------------------------------------
        # Stakes
        # ----------------------------------------------------

        for stake in current_stakes:

            if stake.staker == publicKey:
                bal -= stake.amt

        # ----------------------------------------------------
        # Pending transactions
        # ----------------------------------------------------

        for transaction in pending_transactions:

            if transaction.sender == publicKey:
                bal -= transaction_amount(
                    transaction
                )

        return bal

    # --------------------------------------------------------
    # Epoch seed
    # --------------------------------------------------------

    def epoch_seed(self):

        valid_len = valid_chain_length(
            len(self.chain)
        )

        if valid_len <= 0:
            return None

        last_finalized_block_hash = (
            self.chain[valid_len - 1].hash
        )

        return last_finalized_block_hash

    # --------------------------------------------------------
    # Compare chains
    # --------------------------------------------------------

    def checkEquivalence(
        self,
        block_list: List[Block]
    ):

        """
        Returns:
            -1 -> no divergence
            index -> first divergent block
        """

        min_len = min(
            len(self.chain),
            len(block_list)
        )

        for i in range(min_len):

            if not self.chain[i].is_equal(
                block_list[i]
            ):
                return i

        # If common part is equal but lengths differ,
        # divergence starts at the first missing index.
        if len(self.chain) != len(block_list):
            return min_len

        return -1


# ============================================================
# Transaction duplicate checking
# ============================================================

def transaction_exists_in_block_list(
    blockList: List[Block],
    transaction_tc: Transaction,
    idx
):

    """
    Returns True if the transaction already exists
    in blocks before index idx.

    The old implementation had two bugs:

    1. range(idx - 1) skipped too many blocks.
    2. It returned False when a transaction was found.
    """

    if idx <= 0:
        return False

    for i in range(idx):

        currBlock = blockList[i]

        for transaction in currBlock.transactions:

            if transaction.id == transaction_tc.id:
                return True

    return False


# ============================================================
# Chain validation
# ============================================================

def isvalidChain(blockList: List[Block]):

    if not blockList:
        return False

    # --------------------------------------------------------
    # Validate every block
    # --------------------------------------------------------

    for i in range(len(blockList)):

        currBlock = blockList[i]

        # ----------------------------------------------------
        # Basic block signature
        # ----------------------------------------------------

        if not currBlock.creator:
            print("\nInvalid block creator\n")
            return False

        if not currBlock.sign:
            print("\nMissing block signature\n")
            return False

        try:

            vk = VerifyingKey.from_pem(
                currBlock.creator
            )

            vk.verify(
                currBlock.sign,
                str(currBlock).encode()
            )

        except (
            BadSignatureError,
            ValueError,
            TypeError
        ):

            print(
                f"\nInvalid block signature at block {i}\n"
            )

            return False

        # ----------------------------------------------------
        # Genesis block
        # ----------------------------------------------------

        if i == 0:

            # Genesis does not require previous block,
            # VRF proof or staking information.
            continue

        prevBlock = blockList[i - 1]

        # ----------------------------------------------------
        # Previous hash
        # ----------------------------------------------------

        if currBlock.prevHash != prevBlock.hash:

            print(
                f"\nInvalid previous hash at block {i}\n"
            )

            return False

        # ----------------------------------------------------
        # Timestamp validation
        # ----------------------------------------------------

        try:

            block_time = timestamp_to_datetime(
                currBlock.ts
            )

            prev_block_time = timestamp_to_datetime(
                prevBlock.ts
            )

            current_time = datetime.now()

            # Do not allow future blocks
            if block_time > (
                current_time + timedelta(seconds=10)
            ):

                print(
                    f"\nBlock {i} timestamp in future\n"
                )

                return False

            # Chronological order
            if block_time < prev_block_time:

                print(
                    f"\nBlock {i} timestamp before "
                    f"previous block\n"
                )

                return False

            # Minimum time between blocks
            time_diff = (
                block_time - prev_block_time
            ).total_seconds()

            if time_diff < MIN_BLOCK_TIME:

                print(
                    f"\nBlocks {i - 1} and {i} too "
                    f"close together: "
                    f"{time_diff}s < "
                    f"{MIN_BLOCK_TIME}s\n"
                )

                return False

        except (
            ValueError,
            AttributeError,
            TypeError,
            OSError
        ) as e:

            print(
                f"\nTimestamp validation error "
                f"on block {i}: {e}\n"
            )

            return False

        # ----------------------------------------------------
        # Seed validation
        # ----------------------------------------------------

        valid_len = valid_chain_length(i)

        if valid_len <= 0 or valid_len > len(blockList):

            print("\nInvalid chain length\n")
            return False

        expected_seed = (
            blockList[valid_len - 1].hash
        )

        if str(currBlock.seed) != str(expected_seed):

            print(
                f"\nInvalid Seed at block {i}\n"
            )

            return False

        # ----------------------------------------------------
        # VRF proof
        # ----------------------------------------------------

        if currBlock.vrf_proof is None:

            print(
                f"\nMissing VRF proof at block {i}\n"
            )

            return False

        try:

            # Your implementation uses ECDSA as the
            # VRF-like proof mechanism.
            vk.verify(
                currBlock.vrf_proof,
                currBlock.seed.encode()
            )

        except BadSignatureError:

            print(
                "\nInvalid signature on vrf_proof\n"
            )

            return False

        except (
            ValueError,
            TypeError
        ):

            print(
                "\nInvalid VRF proof format\n"
            )

            return False

        # ----------------------------------------------------
        # Stake validation
        # ----------------------------------------------------

        total_stake = 0

        currStakes = []

        for stake in currBlock.stakers:

            if not stake.staker:
                return False

            if stake.sign is None:
                print(
                    "\nInvalid stake: missing signature\n"
                )
                return False

            if stake.amt <= 0:
                print(
                    "\nInvalid stake amount\n"
                )
                return False

            try:

                vk_stake = VerifyingKey.from_pem(
                    stake.staker
                )

                vk_stake.verify(
                    stake.sign,
                    str(stake).encode()
                )

            except (
                BadSignatureError,
                ValueError,
                TypeError
            ):

                print(
                    "\nInvalid signature on stake\n"
                )

                return False

            # A stake must be backed by the staker's
            # available balance.
            if (
                stake.amt
                > calc_balance_block_list(
                    blockList,
                    stake.staker,
                    i,
                    [],
                    currStakes
                )
            ):

                print(
                    "\nStake exceeds available balance\n"
                )

                return False

            total_stake += stake.amt
            currStakes.append(stake)

        # ----------------------------------------------------
        # VRF threshold
        # ----------------------------------------------------

        if total_stake <= 0:

            print(
                "\nTotal stake is zero\n"
            )

            return False

        if currBlock.staked_amt <= 0:

            print(
                "\nBlock staked amount is invalid\n"
            )

            return False

        if currBlock.staked_amt > total_stake:

            print(
                "\nBlock staked amount exceeds "
                "total stake\n"
            )

            return False

        vrf_output = hashlib.sha256(
            currBlock.vrf_proof
        ).hexdigest()

        vrf_output_int = int(
            vrf_output,
            16
        )

        threshold = (
            currBlock.staked_amt
            / total_stake
        ) * MAX_OUTPUT

        if vrf_output_int > threshold:

            print(
                "\nFalsified VRF\n"
            )

            return False

        # ----------------------------------------------------
        # Transaction validation
        # ----------------------------------------------------

        mem_pool = []

        for transaction in currBlock.transactions:

            # Correct duplicate check
            if transaction_exists_in_block_list(
                blockList,
                transaction,
                i
            ):

                print(
                    "\nDuplicate transaction(s)\n"
                )

                return False

            if not transaction.sign:

                print(
                    "\nMissing transaction signature\n"
                )

                return False

            try:

                vk_tx = VerifyingKey.from_pem(
                    transaction.sender
                )

                vk_tx.verify(
                    transaction.sign,
                    str(transaction).encode()
                )

            except (
                BadSignatureError,
                ValueError,
                TypeError
            ):

                print(
                    "\nInvalid signature on transaction\n"
                )

                return False

            amount = transaction_amount(
                transaction
            )

            if amount <= 0:

                print(
                    "\nInvalid transaction amount\n"
                )

                return False

            balance = calc_balance_block_list(
                blockList,
                transaction.sender,
                i,
                mem_pool,
                currBlock.stakers
            )

            if amount > balance:

                print(
                    "\nTransaction exceeds available "
                    "balance\n"
                )

                return False

            mem_pool.append(transaction)

        # ----------------------------------------------------
        # Check creator balance
        # ----------------------------------------------------

        creator_balance = calc_balance_block_list(
            blockList,
            currBlock.creator,
            i,
            mem_pool,
            currBlock.stakers
        )

        if creator_balance < 0:

            print(
                "\nBlock creator has insufficient balance\n"
            )

            return False

    return True