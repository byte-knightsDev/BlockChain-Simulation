import asyncio
import websockets
import traceback
import hashlib
import argparse
import json
import uuid
import base64
import threading
import socket
import os
import subprocess
import tempfile
import ast

from datetime import datetime, timedelta
from typing import Set, Dict, List, Tuple, Any
from pathlib import Path

from consensus.pos.blockchain_structures import (
    Transaction,
    Stake,
    Block,
    Wallet,
    Chain,
    isvalidChain,
    weight_of_chain,
)

from ipfs.ipfs import addToIpfs, download_ipfs_file_subprocess
from smart_contract.contracts_db import SmartContractDatabase
from smart_contract.secure_executor import SecureContractExecutor

from storage.storage_manager import (
    save_key,
    load_key,
    save_chain,
    load_chain,
    save_peers,
    load_peers,
)

from ecdsa import VerifyingKey, BadSignatureError


MAX_CONNECTIONS = 8
MAX_OUTPUT = 2**256
EPOCH_TIME = 60

GAS_PRICE = 0.001
BASE_DEPLOY_COST = 5

CONSENSUS = "pos"


class VrfThresholdException(Exception):
    pass


def get_random_element(s):
    """Return a random element from a set."""
    import random

    return random.choice(list(s)) if s else None


def normalize_endpoint(ep):
    """
    Resolve hostname into IPv4 and convert port to int.
    """
    host, port = ep
    return (socket.gethostbyname(host), int(port))


def safe_b64decode(value):
    """
    Safely decode Base64 network data.

    Returns bytes on success and None on failure.
    """
    if not isinstance(value, str):
        return None

    try:
        return base64.b64decode(value, validate=True)
    except Exception:
        return None


def get_contract_code_from_notepad():
    """
    Open a temporary Python file in Notepad and return its contents.
    """

    with tempfile.NamedTemporaryFile(
        suffix=".py",
        delete=False,
        mode="w+",
        encoding="utf-8",
    ) as tmp_file:

        temp_filename = tmp_file.name

        tmp_file.write("# Write your smart contract function here.\n")
        tmp_file.write(
            "def contract_logic(parameter1, parameter2, parameter3, state):\n"
        )
        tmp_file.write("    # your code here\n")
        tmp_file.write("    return state, 'some message'\n")

    try:
        subprocess.call(["notepad.exe", temp_filename])

        with open(temp_filename, "r", encoding="utf-8") as f:
            return f.read()

    finally:
        try:
            os.remove(temp_filename)
        except OSError:
            pass


class Peer:

    def __init__(
        self,
        host,
        port,
        name,
        staker: bool,
        activate_disk_load,
        activate_disk_save,
    ):

        self.host = host
        self.name = name
        self.staker = staker

        self.activate_disk_save = activate_disk_save

        self.port = int(port)

        self.ipfs_port = self.port + 50
        self.gateway_port = self.port + 81
        self.swarm_tcp = self.port + 2
        self.swarm_udp = self.port + 3

        self.repo_path = Path.home() / f".ipfs_{self.port}"

        self.env = os.environ.copy()
        self.env["IPFS_PATH"] = str(self.repo_path)

        self.server_connections: Set = set()
        self.client_connections: Set = set()

        self.outbound_peers: Set[tuple] = set()

        self.seen_message_ids: Set[str] = set()

        self.known_peers: Dict[
            Tuple[str, int],
            Tuple[str, str],
        ] = {}

        if activate_disk_load == "y":
            self.load_known_peers_from_disk()

        self.staked_amt: int = 0

        self.got_pong: Dict[Any, bool] = {}

        self.have_sent_peer_info: Dict[Any, bool] = {}

        self.last_epoch_end_ts = datetime.now()

        self.mem_pool: List[Transaction] = []
        self.mem_pool_lock = asyncio.Lock()

        self.file_hashes: Dict[str, str] = {}
        self.file_hashes_lock = asyncio.Lock()

        self.daemon_process = None

        self.current_stakes: Set[Stake] = set()
        self.current_stakers: Dict[str, int] = {}

        self.curr_stakers_condition = asyncio.Condition()

        self.name_to_public_key_dict: Dict[str, str] = {}

        if activate_disk_load == "y":
            self.load_key_from_disk()
        else:
            self.wallet = None

        if not self.wallet:
            self.wallet = Wallet()

            if self.activate_disk_save == "y":
                self.save_key_to_disk()

        if activate_disk_load == "y":
            self.load_chain_from_disk()
        else:
            self.chain = None

        self.contractsDB = SmartContractDatabase()

        self.create_block_condition = asyncio.Condition()

        self.mine_task = None

    # ---------------------------------------------------------
    # STORAGE
    # ---------------------------------------------------------

    def save_key_to_disk(self):
        key = self.wallet.private_key_pem
        save_key(key, CONSENSUS)

    def load_key_from_disk(self):

        key = load_key(CONSENSUS)

        if not key:
            self.wallet = None
            return

        self.wallet = Wallet(key)

    def load_chain_from_disk(self):

        block_dict_list = load_chain(CONSENSUS)

        if not block_dict_list:
            self.chain = None
            return

        block_list: List[Block] = []

        for block_dict in block_dict_list:

            block = self.block_dict_to_block(block_dict)

            if block is not None:
                block_list.append(block)

        if block_list:
            self.chain = Chain(blockList=block_list)
        else:
            self.chain = None

    def save_chain_to_disk(self):

        if not Chain.instance:
            return

        chain = Chain.instance.to_block_dict_list()
        save_chain(chain, CONSENSUS)

    def save_known_peers_to_disk(self):

        content = {}

        for key, value in self.known_peers.items():

            content[json.dumps(key)] = list(value)

        save_peers(content, CONSENSUS)

    def load_known_peers_from_disk(self):

        content = load_peers(CONSENSUS)

        if not content:
            self.known_peers = {}
            return

        self.known_peers = {}

        for key, value in content.items():

            try:
                endpoint = tuple(ast.literal_eval(key))
                self.known_peers[endpoint] = tuple(value)

                if len(value) >= 2:
                    name = value[0]
                    public_key = value[1]

                    self.name_to_public_key_dict[
                        name.lower()
                    ] = public_key

            except Exception:
                print(f"Invalid saved peer entry: {key}")

    # ---------------------------------------------------------
    # NETWORK HANDSHAKE
    # ---------------------------------------------------------

    async def send_peer_info(self, websocket):

        pkt = {
            "type": "peer_info",
            "id": str(uuid.uuid4()),
            "data": {
                "host": self.host,
                "port": self.port,
                "name": self.name,
                "public_key": self.wallet.public_key_pem,
            },
        }

        self.seen_message_ids.add(pkt["id"])

        await websocket.send(json.dumps(pkt))

    async def send_known_peers(self, websocket):

        peers = [
            {
                "host": h,
                "port": p,
                "name": n,
                "public_key": s,
            }
            for (h, p), (n, s) in self.known_peers.items()
        ]

        peers.append(
            {
                "host": self.host,
                "port": self.port,
                "name": self.name,
                "public_key": self.wallet.public_key_pem,
            }
        )

        pkt = {
            "type": "known_peers",
            "id": str(uuid.uuid4()),
            "peers": peers,
        }

        self.seen_message_ids.add(pkt["id"])

        await websocket.send(json.dumps(pkt))

    # ---------------------------------------------------------
    # BLOCK / STAKE DESERIALIZATION
    # ---------------------------------------------------------

    def block_dict_to_block(self, block_dict: Dict[str, Any]):

        if not isinstance(block_dict, dict):
            return None

        try:

            new_block_id = block_dict.get("id")
            new_block_prevHash = block_dict.get("prevHash")
            new_block_ts = block_dict.get("ts")

            transaction_dicts = block_dict.get("transactions")

            if not new_block_id or new_block_ts is None:
                return None

            if not isinstance(transaction_dicts, list):
                return None

            transactions = []

            for transaction_dict in transaction_dicts:

                if not isinstance(transaction_dict, dict):
                    return None

                required = [
                    "payload",
                    "sender",
                    "receiver",
                    "id",
                    "ts",
                ]

                if any(k not in transaction_dict for k in required):
                    return None

                transaction = Transaction(
                    transaction_dict["payload"],
                    transaction_dict["sender"],
                    transaction_dict["receiver"],
                    transaction_dict["id"],
                    transaction_dict["ts"],
                )

                if transaction.sender != "Genesis":

                    sign_b64 = transaction_dict.get("sign")

                    if not sign_b64:
                        return None

                    sign_bytes = safe_b64decode(sign_b64)

                    if sign_bytes is None:
                        return None

                    transaction.sign = sign_bytes

                transactions.append(transaction)

            if not transactions:
                return None

            newBlock = Block(
                new_block_prevHash,
                transactions,
                new_block_ts,
                new_block_id,
            )

            staked_amt = block_dict.get("staked_amt")

            if staked_amt is not None:
                newBlock.staked_amt = staked_amt

            if block_dict.get("files"):
                newBlock.files = block_dict["files"]

            creator = block_dict.get("creator")

            if creator:
                newBlock.creator = creator

            sign_b64 = block_dict.get("sign")

            if sign_b64:

                sign_bytes = safe_b64decode(sign_b64)

                if sign_bytes is None:
                    return None

                newBlock.sign = sign_bytes

            stakers_list: List[Stake] = []

            for staker_dict in block_dict.get("stakers", []):

                stake = self.stake_dict_to_stake(staker_dict)

                if stake:
                    stakers_list.append(stake)

            vrf_proof = block_dict.get("vrf_proof_b64")
            seed = block_dict.get("seed")

            if vrf_proof and seed:

                proof = safe_b64decode(vrf_proof)

                if proof is None:
                    return None

                newBlock.vrf_proof = proof
                newBlock.seed = seed

            newBlock.stakers = stakers_list

            return newBlock

        except Exception as e:

            print(f"Failed to decode block: {e}")
            return None

    def stake_dict_to_stake(self, stake_dict: Dict[str, Any]):

        if not isinstance(stake_dict, dict):
            return None

        try:

            stake_id = stake_dict.get("id")
            staker = stake_dict.get("staker")
            amt = stake_dict.get("amt")
            ts = stake_dict.get("ts")
            sign = stake_dict.get("sign")

            if not stake_id or not staker or amt is None or not sign:
                return None

            if int(amt) <= 0:
                return None

            sign_bytes = safe_b64decode(sign)

            if sign_bytes is None:
                return None

            stake = Stake(staker, amt, ts)
            stake.id = stake_id
            stake.sign = sign_bytes

            return stake

        except Exception:
            return None

    # ---------------------------------------------------------
    # SMART CONTRACT VALIDATION
    # ---------------------------------------------------------

    def valid_deploy_transaction(self, payload):

        if not isinstance(payload, list) or len(payload) < 2:
            return False

        contract_code = payload[0]

        try:
            amount = float(payload[-1])
            gas_used = len(contract_code) // 10 + BASE_DEPLOY_COST
            expected_amount = gas_used * GAS_PRICE

            return amount == expected_amount

        except Exception:
            return False

    def valid_invoke_transaction(self, payload):

        if not isinstance(payload, list) or len(payload) < 5:
            return False

        try:

            contract_id = payload[0]
            func_name = payload[1]
            args = payload[2]

            response = self.run_contract(
                [contract_id, func_name, args]
            )

            if response.get("error") is not None:
                return False

            state = response["state"]
            gas_used = response["gas_used"]

            amount = gas_used * GAS_PRICE

            if state != payload[3]:
                return False

            if amount != payload[-1]:
                return False

            return True

        except Exception:
            return False

    # ---------------------------------------------------------
    # PEER NAME
    # ---------------------------------------------------------

    def get_unique_name(self, base_name):

        existing_names = []

        for _, value in self.known_peers.items():

            if value:
                existing_names.append(value[0].lower())

        existing_names.append(self.name.lower())

        base_name = base_name.lower()

        if base_name not in existing_names:
            return base_name

        counter = 1

        while True:

            new_name = f"{base_name}{counter}"

            if new_name not in existing_names:
                return new_name

            counter += 1

    # ---------------------------------------------------------
    # MESSAGE HANDLING
    # ---------------------------------------------------------

    async def handle_messages(self, websocket, msg):

        if not isinstance(msg, dict):
            return

        t = msg.get("type")
        msg_id = msg.get("id")

        if not t or not msg_id:
            return

        if msg_id in self.seen_message_ids:
            return

        self.seen_message_ids.add(msg_id)

        # -----------------------------------------------------
        # PING
        # -----------------------------------------------------

        if t == "ping":

            pkt = {
                "type": "pong",
                "id": str(uuid.uuid4()),
            }

            self.seen_message_ids.add(pkt["id"])

            await websocket.send(json.dumps(pkt))

        # -----------------------------------------------------
        # PONG
        # -----------------------------------------------------

        elif t == "pong":

            self.got_pong[websocket] = True

            if not self.have_sent_peer_info.get(websocket, True):

                await self.send_peer_info(websocket)

                self.have_sent_peer_info[websocket] = True

        # -----------------------------------------------------
        # PEER INFO
        # -----------------------------------------------------

        elif t == "peer_info":

            data = msg.get("data")

            if not isinstance(data, dict):
                return

            try:

                normalized_self = normalize_endpoint(
                    (self.host, self.port)
                )

                normalized_endpoint = normalize_endpoint(
                    (data["host"], data["port"])
                )

            except Exception:
                return

            if normalized_endpoint == normalized_self:
                return

            if normalized_endpoint not in self.known_peers:

                self.known_peers[normalized_endpoint] = (
                    data["name"],
                    data["public_key"],
                )

                self.name_to_public_key_dict[
                    data["name"].lower()
                ] = data["public_key"]

                if self.activate_disk_save == "y":
                    self.save_known_peers_to_disk()

                print(
                    f"Registered peer "
                    f"{data['name']} "
                    f"{data['host']}:{data['port']}"
                )

                await self.send_known_peers(websocket)

        # -----------------------------------------------------
        # ADD PEER
        # -----------------------------------------------------

        elif t == "add_peer":

            data = msg.get("data")

            if not isinstance(data, dict):
                return

            try:

                normalized_self = normalize_endpoint(
                    (self.host, self.port)
                )

                normalized_endpoint = normalize_endpoint(
                    (data["host"], data["port"])
                )

            except Exception:
                return

            if normalized_endpoint == normalized_self:
                return

            new_peer_msg_id = str(uuid.uuid4())

            if normalized_endpoint not in self.known_peers:

                proposed_name = self.get_unique_name(
                    data["name"]
                )

                if proposed_name != data["name"]:

                    pkt = {
                        "type": "change_name",
                        "id": str(uuid.uuid4()),
                        "new_peer_msg_id": new_peer_msg_id,
                        "new_name": proposed_name,
                    }

                    await websocket.send(json.dumps(pkt))

                    data["name"] = proposed_name

                self.known_peers[normalized_endpoint] = (
                    data["name"],
                    data["public_key"],
                )

                self.name_to_public_key_dict[
                    data["name"].lower()
                ] = data["public_key"]

                if self.activate_disk_save == "y":
                    self.save_known_peers_to_disk()

                print(
                    f"Registered peer "
                    f"{data['name']} "
                    f"{data['host']}:{data['port']}"
                )

                await self.send_known_peers(websocket)

                pkt = {
                    "type": "new_peer",
                    "id": new_peer_msg_id,
                    "data": {
                        "host": data["host"],
                        "port": data["port"],
                        "name": data["name"],
                        "public_key": data["public_key"],
                    },
                }

                self.seen_message_ids.add(pkt["id"])

                await self.broadcast_message(pkt)

        # -----------------------------------------------------
        # NEW PEER
        # -----------------------------------------------------

        elif t == "new_peer":

            data = msg.get("data")

            if not isinstance(data, dict):
                return

            try:

                normalized_self = normalize_endpoint(
                    (self.host, self.port)
                )

                normalized_endpoint = normalize_endpoint(
                    (data["host"], data["port"])
                )

            except Exception:
                return

            if normalized_endpoint == normalized_self:
                return

            if normalized_endpoint not in self.known_peers:

                self.known_peers[normalized_endpoint] = (
                    data["name"],
                    data["public_key"],
                )

                self.name_to_public_key_dict[
                    data["name"].lower()
                ] = data["public_key"]

                if self.activate_disk_save == "y":
                    self.save_known_peers_to_disk()

                print(
                    f"Registered peer "
                    f"{data['name']} "
                    f"{data['host']}:{data['port']}"
                )

                await self.broadcast_message(msg)

        # -----------------------------------------------------
        # CHANGE NAME
        # -----------------------------------------------------

        elif t == "change_name":

            new_name = msg.get("new_name")

            if not new_name:
                return

            self.name = new_name

            new_peer_msg_id = msg.get("new_peer_msg_id")

            if new_peer_msg_id:
                self.seen_message_ids.add(new_peer_msg_id)

        # -----------------------------------------------------
        # KNOWN PEERS
        # -----------------------------------------------------

        elif t == "known_peers":

            peers = msg.get("peers", [])

            if not isinstance(peers, list):
                return

            new_peer_found = False

            for peer in peers:

                try:

                    normalized_self = normalize_endpoint(
                        (self.host, self.port)
                    )

                    normalized_endpoint = normalize_endpoint(
                        (peer["host"], peer["port"])
                    )

                    if normalized_endpoint == normalized_self:
                        continue

                    if normalized_endpoint not in self.known_peers:

                        print(
                            f"Discovered peer "
                            f"{peer['name']} "
                            f"at {peer['host']}:{peer['port']}"
                        )

                        new_peer_found = True

                        self.known_peers[
                            normalized_endpoint
                        ] = (
                            peer["name"],
                            peer["public_key"],
                        )

                        self.name_to_public_key_dict[
                            peer["name"].lower()
                        ] = peer["public_key"]

                except Exception:
                    continue

            if new_peer_found and self.activate_disk_save == "y":
                self.save_known_peers_to_disk()

            pkt = {
                "type": "chain_request",
                "id": str(uuid.uuid4()),
            }

            await websocket.send(json.dumps(pkt))

        # -----------------------------------------------------
        # FILE
        # -----------------------------------------------------

        elif t == "file":

            cid = msg.get("cid")
            desc = msg.get("desc")

            if not cid or desc is None:
                return

            async with self.file_hashes_lock:
                self.file_hashes[cid] = desc

            await self.broadcast_message(msg)

        # -----------------------------------------------------
        # NEW TRANSACTION
        # -----------------------------------------------------

        elif t == "new_tx":

            if Chain.instance is None:
                return

            tx_str = msg.get("transaction")

            if not isinstance(tx_str, str):
                return

            try:
                tx = json.loads(tx_str)
            except Exception:
                return

            if not isinstance(tx, dict):
                return

            try:

                if tx["receiver"] in ("deploy", "invoke"):
                    amount = tx["payload"][-1]
                else:
                    amount = tx["payload"]

                amount = float(amount)

            except Exception:
                return

            if amount <= 0:
                print("\nInvalid Transaction, amount <= 0\n")
                return

            try:

                transaction = Transaction(
                    tx["payload"],
                    tx["sender"],
                    tx["receiver"],
                    tx["id"],
                    tx["ts"],
                )

            except Exception:
                return

            if Chain.instance.transaction_exists_in_chain(
                transaction
            ):
                print(
                    f"{self.name} "
                    f"Transaction already exists in chain"
                )
                return

            sign_bytes = safe_b64decode(msg.get("sign"))

            if sign_bytes is None:
                return

            if transaction.receiver == "deploy":

                if not self.valid_deploy_transaction(
                    transaction.payload
                ):
                    return

            elif transaction.receiver == "invoke":

                if not self.valid_invoke_transaction(
                    transaction.payload
                ):
                    return

            try:

                balance = Chain.instance.calc_balance(
                    transaction.sender,
                    self.mem_pool,
                    list(self.current_stakes),
                )

            except Exception:
                return

            if amount > balance:

                print(
                    "\nAttempt to spend more than available. "
                    "Invalid transaction\n"
                )

                return

            try:

                sender_pem = msg.get("sender_pem")

                if not sender_pem:
                    return

                public_key = VerifyingKey.from_pem(
                    sender_pem.encode()
                )

                public_key.verify(
                    sign_bytes,
                    tx_str.encode(),
                )

            except BadSignatureError:

                print("Invalid Signature")
                return

            except Exception:

                print("Invalid public key/signature")
                return

            transaction.sign = sign_bytes

            print("\nValid Transaction")
            print(f"\n{msg['type']}: {msg['transaction']}")
            print()

            async with self.mem_pool_lock:

                if not Chain.instance.transaction_exists_in_chain(
                    transaction
                ):
                    self.mem_pool.append(transaction)

            await self.broadcast_message(msg)

        # -----------------------------------------------------
        # STAKE ANNOUNCEMENT
        # -----------------------------------------------------

        elif t == "stake_announcement":

            stake_dict = msg.get("stake")

            if not isinstance(stake_dict, dict):
                return

            staker = stake_dict.get("staker")
            amt = stake_dict.get("amt")
            ts = stake_dict.get("ts")
            stake_id = stake_dict.get("id")
            sign_b64 = stake_dict.get("sign")

            if (
                not staker
                or amt is None
                or not stake_id
                or not sign_b64
            ):
                return

            try:
                amt = int(amt)
            except Exception:
                return

            if amt <= 0:
                return

            sign = safe_b64decode(sign_b64)

            if sign is None:
                return

            try:

                stake = Stake(staker, amt, ts)
                stake.id = stake_id

                vk = VerifyingKey.from_pem(
                    staker.encode()
                )

                vk.verify(
                    sign,
                    str(stake).encode(),
                )

                stake.sign = sign

            except BadSignatureError:

                print("\nWrong stake signature\n")
                return

            except Exception:

                print("\nInvalid stake public key/signature\n")
                return

            if Chain.instance is None:
                return

            try:

                balance = Chain.instance.calc_balance(
                    stake.staker,
                    self.mem_pool,
                    list(self.current_stakes),
                )

            except Exception:
                return

            if stake.amt > balance:

                print(
                    "\nInvalid stake: amount exceeds balance\n"
                )

                return

            async with self.curr_stakers_condition:

                self.current_stakes.add(stake)
                self.current_stakers[staker] = amt

                print(f"New stake : {staker}:{amt}")

            await self.broadcast_message(msg)

        # -----------------------------------------------------
        # NEW BLOCK
        # -----------------------------------------------------

        elif t == "new_block":

            if Chain.instance is None:
                return

            new_block_dict = msg.get("block")

            if not isinstance(new_block_dict, dict):
                return

            newBlock = self.block_dict_to_block(
                new_block_dict
            )

            if newBlock is None:
                print("\nInvalid block format\n")
                return

            try:

                if not Chain.instance.isValidBlock(newBlock):

                    print("\nInvalid Block\n")
                    return

            except Exception as e:

                print(f"\nBlock validation error: {e}\n")
                return

            creator = new_block_dict.get("creator")

            if not creator:
                return

            vrf_proof = safe_b64decode(
                msg.get("vrf_proof")
            )

            sign = safe_b64decode(
                msg.get("sign")
            )

            if vrf_proof is None or sign is None:
                return

            try:

                vk = VerifyingKey.from_pem(
                    creator.encode()
                )

            except Exception:

                print("\nInvalid block creator public key\n")
                return

            try:

                seed = Chain.instance.epoch_seed()

                vk.verify(
                    vrf_proof,
                    seed.encode(),
                )

                vk.verify(
                    sign,
                    str(newBlock).encode(),
                )

            except BadSignatureError:

                print("\nInvalid Block Signature\n")
                return

            except Exception as e:

                print(
                    f"\nBlock signature verification error: {e}\n"
                )
                return

            if newBlock.seed != seed:

                print("\nSeed may have been altered\n")
                return

            async with self.curr_stakers_condition:

                staked_amt = self.current_stakers.get(
                    creator
                )

                total_amt_staked = sum(
                    self.current_stakers.values()
                )

                current_stakes_snapshot = list(
                    self.current_stakes
                )

            if staked_amt is None:

                print(
                    "\nBlock creator is not a current staker\n"
                )

                return

            if total_amt_staked <= 0:

                print("\nInvalid total stake\n")
                return

            total_amt_staked_2 = 0

            for stake in newBlock.stakers:

                try:

                    vk_stake = VerifyingKey.from_pem(
                        stake.staker.encode()
                    )

                    vk_stake.verify(
                        stake.sign,
                        str(stake).encode(),
                    )

                    total_amt_staked_2 += stake.amt

                except BadSignatureError:

                    print(
                        "\nInvalid Block "
                        "(Stake Signature Error)\n"
                    )

                    return

                except Exception:

                    return

            if total_amt_staked_2 <= 0:
                return

            if total_amt_staked > total_amt_staked_2:

                print(
                    "\nSome stakes may have been ignored\n"
                )

                return

            threshold = (
                staked_amt / total_amt_staked_2
            ) * MAX_OUTPUT

            vrf_output = hashlib.sha256(
                vrf_proof
            ).hexdigest()

            vrf_output_int = int(
                vrf_output,
                16,
            )

            if vrf_output_int >= threshold:

                print(
                    "\nInvalid Block "
                    "(VRF output above threshold)\n"
                )

                return

            newBlock.sign = sign
            newBlock.seed = seed
            newBlock.vrf_output = vrf_output
            newBlock.vrf_proof = vrf_proof
            newBlock.creator = creator

            for transaction in newBlock.transactions:

                if transaction.receiver == "invoke":

                    if not self.valid_invoke_transaction(
                        transaction.payload
                    ):
                        return

                elif transaction.receiver == "deploy":

                    if not self.valid_deploy_transaction(
                        transaction.payload
                    ):
                        return

            Chain.instance.chain.append(newBlock)

            print("\n\nBlock Appended\n\n")

            self.last_epoch_end_ts = datetime.now()

            for transaction in newBlock.transactions:

                if transaction.receiver == "deploy":

                    self.deploy_contract(transaction)

            async with self.mem_pool_lock:

                self.mem_pool = [
                    transaction
                    for transaction in self.mem_pool
                    if not newBlock.transaction_exists_in_block(
                        transaction
                    )
                ]

            async with self.file_hashes_lock:

                for cid in list(self.file_hashes.keys()):

                    if newBlock.cid_exists_in_block(cid):

                        self.file_hashes.pop(
                            cid,
                            None,
                        )

            async with self.curr_stakers_condition:

                self.staked_amt = 0
                self.current_stakers.clear()
                self.current_stakes.clear()

            await self.broadcast_message(msg)

            if self.activate_disk_save == "y":
                self.save_chain_to_disk()

        # -----------------------------------------------------
        # SLASH ANNOUNCEMENT
        # -----------------------------------------------------

        elif t == "slash_announcement":

            if Chain.instance is None:
                return

            try:

                pos = int(msg.get("pos"))

                if pos < 0 or pos >= len(
                    Chain.instance.chain
                ):
                    return

            except Exception:
                return

            block1_dict = msg.get("evidence1")
            block2_dict = msg.get("evidence2")

            block1 = self.block_dict_to_block(
                block1_dict
            )

            block2 = self.block_dict_to_block(
                block2_dict
            )

            if block1 is None or block2 is None:
                return

            sign1 = safe_b64decode(
                msg.get("block1_sign")
            )

            sign2 = safe_b64decode(
                msg.get("block2_sign")
            )

            if sign1 is None or sign2 is None:
                return

            block1.sign = sign1
            block2.sign = sign2

            if not block1.creator:
                return

            try:

                vk = VerifyingKey.from_pem(
                    block1.creator.encode()
                )

            except Exception:
                return

            block1_exists = (
                Chain.instance.chain[pos].is_equal(
                    block1
                )
            )

            block2_exists = (
                Chain.instance.chain[pos].is_equal(
                    block2
                )
            )

            if not (block1_exists or block2_exists):
                return

            err1 = False
            err2 = False

            try:

                vk.verify(
                    block1.sign,
                    str(block1).encode(),
                )

            except BadSignatureError:

                err1 = True

            try:

                vk.verify(
                    block2.sign,
                    str(block2).encode(),
                )

            except BadSignatureError:

                err2 = True

            if err1 and err2:

                print("\nInvalid Slashing Evidence")
                return

            elif not err1 and not err2:

                print(f"\nBlock {pos} slashed\n")

                Chain.instance.chain[
                    pos
                ].is_valid = False

                Chain.instance.chain[
                    pos
                ].slash_creator = True

                await self.broadcast_message(msg)

            elif (
                err1
                and not err2
                and block1_exists
            ) or (
                err2
                and not err1
                and block2_exists
            ):

                Chain.instance.chain = (
                    Chain.instance.chain[:pos]
                )

        # -----------------------------------------------------
        # CHAIN REQUEST
        # -----------------------------------------------------

        elif t == "chain_request":

            if Chain.instance is None:
                return

            pkt = {
                "type": "chain",
                "id": str(uuid.uuid4()),
                "chain": Chain.instance.to_block_dict_list(),
            }

            await websocket.send(
                json.dumps(pkt)
            )

        # -----------------------------------------------------
        # CHAIN
        # -----------------------------------------------------

        elif t == "chain":

            if Chain.instance is None:
                return

            print("Received a Chain")

            block_dict_list = msg.get("chain")

            if not isinstance(block_dict_list, list):
                return

            block_list: List[Block] = []

            for block_dict in block_dict_list:

                block = self.block_dict_to_block(
                    block_dict
                )

                if block is None:
                    print("\nInvalid Chain\n")
                    return

                block_list.append(block)

            try:

                if not isvalidChain(block_list):

                    print("\nInvalid Chain\n")
                    return

            except Exception as e:

                print(
                    f"\nChain validation error: {e}\n"
                )
                return

            if not self.chain:

                self.chain = Chain(
                    blockList=block_list
                )

                if self.activate_disk_save == "y":
                    self.save_chain_to_disk()

            else:

                pos = Chain.instance.checkEquivalence(
                    block_list
                )

                if pos != -1:

                    block1 = Chain.instance.chain[pos]
                    block2 = block_list[pos]

                    if block1.creator != block2.creator:

                        if (
                            weight_of_chain(
                                Chain.instance.chain
                            )
                            < weight_of_chain(block_list)
                        ):

                            Chain.instance.rewrite(
                                block_list
                            )

                            print(
                                "\nCurrent chain replaced "
                                "by longer chain\n"
                            )

                            if self.activate_disk_save == "y":
                                self.save_chain_to_disk()

                    else:

                        await self.verify_and_slash(
                            block1,
                            block2,
                            pos,
                            block_list,
                        )

                elif (
                    weight_of_chain(
                        Chain.instance.chain
                    )
                    < weight_of_chain(block_list)
                ):

                    Chain.instance.rewrite(
                        block_list
                    )

                    print(
                        "\nCurrent chain replaced "
                        "by longer chain\n"
                    )

                    if self.activate_disk_save == "y":
                        self.save_chain_to_disk()

                else:

                    print(
                        "\nCurrent Chain Longer "
                        "than received chain\n"
                    )

            async with self.mem_pool_lock:

                self.mem_pool = [
                    transaction
                    for transaction in self.mem_pool
                    if not Chain.instance.transaction_exists_in_chain(
                        transaction
                    )
                ]

            async with self.file_hashes_lock:

                for cid in list(
                    self.file_hashes.keys()
                ):

                    if Chain.instance.cid_exists_in_chain(
                        cid
                    ):

                        self.file_hashes.pop(
                            cid,
                            None,
                        )

    # ---------------------------------------------------------
    # SLASH VERIFICATION
    # ---------------------------------------------------------

    async def verify_and_slash(
        self,
        block1: Block,
        block2: Block,
        pos: int,
        block_list: List[Block],
    ):

        if not block1.creator:
            return

        try:

            vk = VerifyingKey.from_pem(
                block1.creator.encode()
            )

        except Exception:
            return

        sign1 = block1.sign
        sign2 = block2.sign

        err1 = False
        err2 = False

        try:

            vk.verify(
                sign1,
                str(block1).encode(),
            )

        except BadSignatureError:

            err1 = True

        try:

            vk.verify(
                sign2,
                str(block2).encode(),
            )

        except BadSignatureError:

            err2 = True

        if err1 and not err2:

            Chain.instance.rewrite(
                block_list
            )

            return

        elif err2 and not err1:

            return

        if err1 and err2:
            return

        Chain.instance.chain[
            pos
        ].is_valid = False

        Chain.instance.chain[
            pos
        ].slash_creator = True

        pkt = {
            "type": "slash_announcement",
            "id": str(uuid.uuid4()),
            "evidence1": block1.to_dict_with_stakers(),
            "evidence2": block2.to_dict_with_stakers(),
            "block1_sign": base64.b64encode(
                block1.sign
            ).decode(),
            "block2_sign": base64.b64encode(
                block2.sign
            ).decode(),
            "pos": pos,
        }

        await self.broadcast_message(pkt)

    # ---------------------------------------------------------
    # CONNECTION HANDLING
    # ---------------------------------------------------------

    async def handle_connections(self, websocket):

        peer_addr = websocket.remote_address

        self.server_connections.add(
            websocket
        )

        print(
            f"Inbound Connection from "
            f"{peer_addr[0]}:{peer_addr[1]}"
        )

        try:

            async for raw in websocket:

                try:
                    msg = json.loads(raw)

                except json.JSONDecodeError:

                    print(
                        "Received invalid JSON"
                    )

                    continue

                await self.handle_messages(
                    websocket,
                    msg,
                )

        except websockets.exceptions.ConnectionClosed:

            print(
                f"Inbound Connection Closed: "
                f"{peer_addr}"
            )

        except Exception:

            traceback.print_exc()

        finally:

            self.server_connections.discard(
                websocket
            )

            try:
                await websocket.close()
            except Exception:
                pass

    async def broadcast_message(self, pkt):

        if not isinstance(pkt, dict):
            return

        targets = (
            self.server_connections
            | self.client_connections
        )

        for ws in list(targets):

            try:

                await ws.send(
                    json.dumps(pkt)
                )

            except Exception as e:

                print(
                    f"Error broadcasting: {e}"
                )

                self.server_connections.discard(
                    ws
                )

                self.client_connections.discard(
                    ws
                )

                self.got_pong.pop(
                    ws,
                    None,
                )

                self.have_sent_peer_info.pop(
                    ws,
                    None,
                )

                try:

                    if ws.remote_address:

                        endpoint = normalize_endpoint(
                            (
                                ws.remote_address[0],
                                ws.remote_address[1],
                            )
                        )

                        self.outbound_peers.discard(
                            endpoint
                        )

                except Exception:
                    pass

                try:
                    await ws.close()
                except Exception:
                    pass

    # ---------------------------------------------------------
    # TRANSACTIONS
    # ---------------------------------------------------------

    async def create_and_broadcast_tx(
        self,
        receiver_public_key,
        payload,
    ):

        if Chain.instance is None:
            print("Blockchain is not initialized.")
            return

        transaction = Transaction(
            payload,
            self.wallet.public_key_pem,
            receiver_public_key,
        )

        transaction_str = str(transaction)

        signature = self.wallet.private_key.sign(
            transaction_str.encode()
        )

        transaction.sign = signature

        signature_b64 = base64.b64encode(
            signature
        ).decode()

        pkt = {
            "type": "new_tx",
            "id": str(uuid.uuid4()),
            "transaction": transaction_str,
            "sign": signature_b64,
            "sender_pem": self.wallet.public_key_pem,
        }

        self.seen_message_ids.add(
            pkt["id"]
        )

        if Chain.instance.transaction_exists_in_chain(
            transaction
        ):
            return

        async with self.mem_pool_lock:

            if not Chain.instance.transaction_exists_in_chain(
                transaction
            ):
                self.mem_pool.append(
                    transaction
                )

        print(
            "Transaction Created",
            transaction,
        )

        print()

        await self.broadcast_message(
            pkt
        )

    # ---------------------------------------------------------
    # CONTRACTS
    # ---------------------------------------------------------

    def get_contract_state(self, contract_id):

        if Chain.instance is None:
            return {}

        for block in reversed(
            Chain.instance.chain
        ):

            for transaction in reversed(
                block.transactions
            ):

                if (
                    transaction.receiver == "invoke"
                    and transaction.payload[0]
                    == contract_id
                ):

                    return transaction.payload[3]

        return {}

    def calculate_contract_id(
        self,
        sender,
        timestamp,
    ):

        data = f"{sender}:{timestamp}"

        return hashlib.sha256(
            data.encode("utf-8")
        ).hexdigest()

    def deploy_contract(self, transaction):

        sender = transaction.sender
        timestamp = transaction.ts
        code = transaction.payload[0]

        contract_id = self.calculate_contract_id(
            sender,
            timestamp,
        )

        self.contractsDB.store_contract(
            contract_id,
            code,
        )

        print(
            "Contract deployed with id:",
            contract_id,
        )

    def run_contract(self, payload):

        contract_id = payload[0]
        func_name = payload[1]
        args = payload[2]

        code = self.contractsDB.get_contract(
            contract_id
        )

        if code is None:
            raise Exception(
                f"Contract '{contract_id}' not found."
            )

        state = self.get_contract_state(
            contract_id
        )

        executor = SecureContractExecutor(
            code
        )

        return executor.run(
            func_name,
            args,
            state,
        )

    # ---------------------------------------------------------
    # USER INPUT
    # ---------------------------------------------------------

    async def user_input_handler(self):

        while True:

            print(
                "Block Chain Menu\n"
                "***************"
            )

            if self.staker:

                print(
                    "0) Quit\n"
                    "1) Add Transaction\n"
                    "2) View balance\n"
                    "3) Print Chain\n"
                    "4) Print Pending Transactions\n"
                    "5) Print Current Stakers\n"
                    "6) Time since last epoch\n"
                    "7) Send Files\n"
                    "8) Download Files\n"
                    "9) Stake\n"
                )

            else:

                print(
                    "0) Quit\n"
                    "1) Add Transaction\n"
                    "2) View balance\n"
                    "3) Print Chain\n"
                    "4) Print Pending Transactions\n"
                    "5) Print Current Stakers\n"
                    "6) Time since last epoch\n"
                    "7) Send Files\n"
                    "8) Download Files\n"
                )

            ch = await asyncio.get_running_loop().run_in_executor(
                None,
                input,
                "Enter Your Choice: ",
            )

            try:
                ch = int(ch)
            except ValueError:

                print(
                    "\nPlease enter a valid number!!!\n"
                )

                continue

            # -------------------------------------------------
            # TRANSACTION
            # -------------------------------------------------

            if ch == 1:

                if Chain.instance is None:

                    print(
                        "\nBlockchain hasn't "
                        "been initialized yet.\n"
                    )

                    continue

                rec = await asyncio.get_running_loop().run_in_executor(
                    None,
                    input,
                    "\nEnter Receiver's Name or Public Key: ",
                )

                if rec == "deploy":

                    contract_code = (
                        get_contract_code_from_notepad()
                    )

                    if not contract_code.strip():

                        print(
                            "Contract code field is empty"
                        )

                        continue

                    gas_used = (
                        len(contract_code) // 10
                        + BASE_DEPLOY_COST
                    )

                    amount = (
                        gas_used * GAS_PRICE
                    )

                    payload = [
                        contract_code,
                        amount,
                    ]

                    balance = Chain.instance.calc_balance(
                        self.wallet.public_key_pem,
                        self.mem_pool,
                        list(self.current_stakes),
                    )

                    if amount <= balance:

                        await self.create_and_broadcast_tx(
                            "deploy",
                            payload,
                        )

                    else:

                        print(
                            "Insufficient Account Balance"
                        )

                elif rec == "invoke":

                    contract_id = await asyncio.get_running_loop().run_in_executor(
                        None,
                        input,
                        "\nEnter Contract Id: ",
                    )

                    if (
                        contract_id
                        not in self.contractsDB.contracts
                    ):

                        print(
                            "No such contract found..."
                        )

                        continue

                    func_name = await asyncio.get_running_loop().run_in_executor(
                        None,
                        input,
                        "\nEnter Function Name: ",
                    )

                    args = []

                    loop = asyncio.get_running_loop()

                    arg_number = 1

                    while True:

                        arg = await loop.run_in_executor(
                            None,
                            input,
                            (
                                f"Enter argument "
                                f"{arg_number} "
                                f"(or \\q to finish): "
                            ),
                        )

                        if arg.strip() == "\\q":
                            break

                        try:
                            parsed_arg = ast.literal_eval(
                                arg
                            )

                        except Exception:

                            parsed_arg = arg

                        args.append(
                            parsed_arg
                        )

                        arg_number += 1

                    try:

                        response = self.run_contract(
                            [
                                contract_id,
                                func_name,
                                args,
                            ]
                        )

                    except Exception as e:

                        print(
                            "Error:",
                            e,
                        )

                        continue

                    if response.get("error") is not None:

                        print(
                            "Error:",
                            response["error"],
                        )

                        continue

                    state = response["state"]
                    gas_used = response["gas_used"]

                    amount = (
                        gas_used * GAS_PRICE
                    )

                    payload = [
                        contract_id,
                        func_name,
                        args,
                        state,
                        amount,
                    ]

                    balance = Chain.instance.calc_balance(
                        self.wallet.public_key_pem,
                        self.mem_pool,
                        list(self.current_stakes),
                    )

                    if amount <= balance:

                        await self.create_and_broadcast_tx(
                            "invoke",
                            payload,
                        )

                    else:

                        print(
                            "Insufficient Account Balance"
                        )

                else:

                    amt = await asyncio.get_running_loop().run_in_executor(
                        None,
                        input,
                        "\nEnter Amount to send: ",
                    )

                    receiver_public_key = (
                        self.name_to_public_key_dict.get(
                            rec.lower().strip()
                        )
                    )

                    if receiver_public_key is None:

                        rec_refined = rec.replace(
                            "\\n",
                            "\n",
                        )

                        for pk in (
                            self.name_to_public_key_dict.values()
                        ):

                            if pk == rec_refined:

                                receiver_public_key = pk
                                break

                    if receiver_public_key is None:

                        print(
                            "No person available in directory "
                            "with provided name or public key..."
                        )

                        continue

                    try:

                        amt = float(amt)

                    except ValueError:

                        print(
                            "\nAmount must be a number\n"
                        )

                        continue

                    if amt <= 0:

                        print(
                            "\nAmount must be greater than zero\n"
                        )

                        continue

                    await self.create_and_broadcast_tx(
                        receiver_public_key,
                        amt,
                    )

            # -------------------------------------------------
            # BALANCE
            # -------------------------------------------------

            elif ch == 2:

                if Chain.instance is None:
                    print(
                        "\nBlockchain hasn't "
                        "been initialized yet\n"
                    )
                    continue

                print(
                    "Account Balance =",
                    Chain.instance.calc_balance(
                        self.wallet.public_key_pem,
                        self.mem_pool,
                        list(self.current_stakes),
                    ),
                )

            # -------------------------------------------------
            # CHAIN
            # -------------------------------------------------

            elif ch == 3:

                if Chain.instance is None:

                    print(
                        "\nChain hasn't "
                        "been initialized yet\n"
                    )

                    continue

                for i, block in enumerate(
                    Chain.instance.chain
                ):

                    print(
                        f"block{i}: {block}\n"
                    )

            # -------------------------------------------------
            # MEMPOOL
            # -------------------------------------------------

            elif ch == 4:

                for i, transaction in enumerate(
                    self.mem_pool
                ):

                    print(
                        f"transaction{i}: "
                        f"{transaction}\n\n"
                    )

            # -------------------------------------------------
            # STAKERS
            # -------------------------------------------------

            elif ch == 5:

                async with self.curr_stakers_condition:

                    print()

                    for key, value in (
                        self.current_stakers.items()
                    ):

                        print(
                            f"{key}:{value}\n"
                        )

                    print()

            # -------------------------------------------------
            # EPOCH
            # -------------------------------------------------

            elif ch == 6:

                elapsed = (
                    datetime.now()
                    - self.last_epoch_end_ts
                ).total_seconds()

                print(
                    f"\n{int(elapsed)}\n"
                )

            # -------------------------------------------------
            # UPLOAD
            # -------------------------------------------------

            elif ch == 7:

                desc = await asyncio.get_running_loop().run_in_executor(
                    None,
                    input,
                    "\nEnter description of file: ",
                )

                path = await asyncio.get_running_loop().run_in_executor(
                    None,
                    input,
                    "\nEnter path of file: ",
                )

                pkt = await self.uploadFile(
                    desc,
                    path,
                )

                if pkt is not None:

                    await self.broadcast_message(
                        pkt
                    )

            # -------------------------------------------------
            # DOWNLOAD
            # -------------------------------------------------

            elif ch == 8:

                cid = await asyncio.get_running_loop().run_in_executor(
                    None,
                    input,
                    "\nEnter cid of file: ",
                )

                path = await asyncio.get_running_loop().run_in_executor(
                    None,
                    input,
                    "\nEnter path to download the file: ",
                )

                try:

                    download_ipfs_file_subprocess(
                        cid,
                        path,
                    )

                except Exception as e:

                    print(
                        f"Download failed: {e}"
                    )

            # -------------------------------------------------
            # STAKE
            # -------------------------------------------------

            elif ch == 9:

                if not self.staker:
                    continue

                currTime = datetime.now()

                time_since = (
                    currTime
                    - self.last_epoch_end_ts
                )

                if self.staked_amt > 0:

                    print(
                        "Can't send multiple "
                        "stakes in one epoch"
                    )

                    continue

                if (
                    time_since
                    > timedelta(
                        seconds=EPOCH_TIME * 5 / 6
                    )
                ):

                    if (
                        time_since
                        > timedelta(
                            seconds=EPOCH_TIME * 7 / 6
                        )
                    ):

                        self.last_epoch_end_ts = (
                            datetime.now()
                        )

                        self.staked_amt = 0

                        async with self.curr_stakers_condition:

                            self.current_stakers.clear()
                            self.current_stakes.clear()

                    else:

                        print(
                            "Stake registration period closed, "
                            "try again in the next epoch."
                        )

                        continue

                amt = await asyncio.get_running_loop().run_in_executor(
                    None,
                    input,
                    "\nEnter Amount to stake: ",
                )

                try:

                    amt = int(amt)

                    if amt <= 0:

                        print(
                            "\nStake must be greater than zero\n"
                        )

                        continue

                    await self.send_stake_announcements(
                        amt
                    )

                    self.staked_amt = amt

                    time_left = max(
                        0,
                        EPOCH_TIME
                        - int(
                            time_since.total_seconds()
                        ),
                    )

                    print(
                        f"Creating block in "
                        f"{time_left} seconds"
                    )

                    asyncio.create_task(
                        self.create_blocks(
                            time_left
                        )
                    )

                except ValueError:

                    print(
                        "\nPlease enter a valid number!!!\n"
                    )

                except Exception as e:

                    print(
                        "\nUnexpected error occurred!!!\n",
                        e,
                    )

            # -------------------------------------------------
            # QUIT
            # -------------------------------------------------

            elif ch == 0:

                print(
                    "Quitting..."
                )

                break

            else:

                print(
                    "\nInvalid choice.\n"
                )

    # ---------------------------------------------------------
    # IPFS
    # ---------------------------------------------------------

    async def uploadFile(
        self,
        desc: str,
        path: str,
    ):

        file_path = Path(path)

        if not file_path.is_file():

            print(
                "\nFile doesn't exist\n"
            )

            return None

        if not self.daemon_process:

            try:
                self.start_daemon()

            except Exception as e:

                print(
                    f"Could not start IPFS daemon: {e}"
                )

                return None

        try:

            cid, name = await asyncio.to_thread(
                addToIpfs,
                path,
            )

        except Exception as e:

            print(
                f"IPFS upload failed: {e}"
            )

            return None

        if not cid or not name:
            return None

        print(
            f"\nNew File Created : {cid}\n"
        )

        pkt = {
            "type": "file",
            "id": str(uuid.uuid4()),
            "desc": desc,
            "cid": cid,
        }

        self.seen_message_ids.add(
            pkt["id"]
        )

        async with self.file_hashes_lock:

            self.file_hashes[cid] = desc

        return pkt

    def init_repo(self):

        if not self.repo_path.exists():

            subprocess.run(
                ["ipfs", "init"],
                env=self.env,
                check=True,
            )

            print(
                "\nIPFS repo created\n"
            )

    def configure_ports(self):

        subprocess.run(
            [
                "ipfs",
                "config",
                "Addresses.API",
                f"/ip4/127.0.0.1/tcp/{self.ipfs_port}",
            ],
            env=self.env,
            check=True,
        )

        subprocess.run(
            [
                "ipfs",
                "config",
                "Addresses.Gateway",
                f"/ip4/127.0.0.1/tcp/{self.gateway_port}",
            ],
            env=self.env,
            check=True,
        )

        subprocess.run(
            [
                "ipfs",
                "config",
                "Addresses.Swarm",
                "--json",
                (
                    f'["/ip4/127.0.0.1/tcp/{self.swarm_tcp}", '
                    f'"/ip4/127.0.0.1/udp/{self.swarm_udp}/quic"]'
                ),
            ],
            env=self.env,
            check=True,
        )

        print(
            "\nConfigured Ports\n"
        )

    def start_daemon(self):

        self.daemon_process = subprocess.Popen(
            ["ipfs", "daemon"],
            env=self.env,
        )

        print(
            "\nIPFS Daemon Started\n"
        )

    def stop_daemon(self):

        if self.daemon_process:

            try:

                self.daemon_process.terminate()
                self.daemon_process.wait(
                    timeout=5
                )

            except Exception:

                try:
                    self.daemon_process.kill()
                except Exception:
                    pass

            finally:

                self.daemon_process = None

    # ---------------------------------------------------------
    # CONNECT TO PEER
    # ---------------------------------------------------------

    async def connect_to_peer(
        self,
        host,
        port,
    ):

        endpoint = (
            host,
            int(port),
        )

        if (
            endpoint in self.outbound_peers
            or endpoint == (
                self.host,
                self.port,
            )
        ):

            return

        uri = (
            f"ws://{host}:{port}"
        )

        websocket = None

        try:

            websocket = await websockets.connect(
                uri
            )

            self.client_connections.add(
                websocket
            )

            self.outbound_peers.add(
                endpoint
            )

            self.have_sent_peer_info[
                websocket
            ] = False

            print(
                f"Outbound connection formed "
                f"to {host}:{port}"
            )

            if Chain.instance is None:

                pkt = {
                    "type": "add_peer",
                    "id": str(uuid.uuid4()),
                    "data": {
                        "host": self.host,
                        "port": self.port,
                        "name": self.name,
                        "public_key": (
                            self.wallet.public_key_pem
                        ),
                    },
                }

            else:

                pkt = {
                    "type": "ping",
                    "id": str(uuid.uuid4()),
                }

            self.seen_message_ids.add(
                pkt["id"]
            )

            await websocket.send(
                json.dumps(pkt)
            )

            async for raw in websocket:

                try:

                    msg = json.loads(raw)

                except json.JSONDecodeError:

                    continue

                await self.handle_messages(
                    websocket,
                    msg,
                )

        except Exception as e:

            print(
                f"Failed to connect to "
                f"{host}:{port} ::: {e}"
            )

        finally:

            self.client_connections.discard(
                websocket
            )

            self.outbound_peers.discard(
                endpoint
            )

            self.got_pong.pop(
                websocket,
                None,
            )

            self.have_sent_peer_info.pop(
                websocket,
                None,
            )

            if websocket:

                try:
                    await websocket.close()
                except Exception:
                    pass

    # ---------------------------------------------------------
    # PEER DISCOVERY
    # ---------------------------------------------------------

    async def discover_peers(self):

        while True:

            try:

                if (
                    len(self.outbound_peers)
                    < MAX_CONNECTIONS
                ):

                    potential_peers = {
                        endpoint
                        for endpoint in self.known_peers
                        if (
                            endpoint
                            not in self.outbound_peers
                            and endpoint
                            != (
                                self.host,
                                self.port,
                            )
                        )
                    }

                    while (
                        len(self.outbound_peers)
                        < MAX_CONNECTIONS
                        and potential_peers
                    ):

                        new_peer = get_random_element(
                            potential_peers
                        )

                        potential_peers.discard(
                            new_peer
                        )

                        if new_peer:

                            asyncio.create_task(
                                self.connect_to_peer(
                                    *new_peer
                                )
                            )

                            await asyncio.sleep(1)

                await asyncio.sleep(30)

            except asyncio.CancelledError:

                raise

            except Exception:

                traceback.print_exc()

                await asyncio.sleep(5)

    async def gossip_peer_sampler(self):

        while True:

            try:

                await asyncio.sleep(60)

                if (
                    len(self.known_peers)
                    <= len(self.outbound_peers)
                    or len(self.outbound_peers)
                    < MAX_CONNECTIONS
                ):
                    continue

                to_drop = get_random_element(
                    self.client_connections
                )

                if to_drop:

                    print(
                        "Gossip Sampling: "
                        f"Disconnecting "
                        f"{to_drop.remote_address}"
                    )

                    self.client_connections.discard(
                        to_drop
                    )

                    try:

                        normalized_endpoint = (
                            normalize_endpoint(
                                (
                                    to_drop.remote_address[
                                        0
                                    ],
                                    to_drop.remote_address[
                                        1
                                    ],
                                )
                            )
                        )

                        self.outbound_peers.discard(
                            normalized_endpoint
                        )

                    except Exception:
                        pass

                    self.got_pong.pop(
                        to_drop,
                        None,
                    )

                    self.have_sent_peer_info.pop(
                        to_drop,
                        None,
                    )

                    try:
                        await to_drop.close()
                    except Exception:
                        pass

                potential_peers = {
                    endpoint
                    for endpoint in self.known_peers
                    if (
                        endpoint
                        not in self.outbound_peers
                        and endpoint
                        != (
                            self.host,
                            self.port,
                        )
                    )
                }

                if potential_peers:

                    new_peer = get_random_element(
                        potential_peers
                    )

                    if new_peer:

                        print(
                            "Gossip Sampling: "
                            f"Connecting to new peer "
                            f"{new_peer}"
                        )

                        asyncio.create_task(
                            self.connect_to_peer(
                                *new_peer
                            )
                        )

            except asyncio.CancelledError:

                raise

            except Exception:

                traceback.print_exc()

    # ---------------------------------------------------------
    # STAKING
    # ---------------------------------------------------------

    async def send_stake_announcements(
        self,
        amt: int,
    ):

        if Chain.instance is None:
            return

        new_stake = Stake(
            self.wallet.public_key_pem,
            amt,
        )

        sign = self.wallet.private_key.sign(
            str(new_stake).encode()
        )

        new_stake.sign = sign

        stake_dict = new_stake.to_dict()

        stake_dict["sign"] = (
            base64.b64encode(sign).decode()
        )

        pkt = {
            "id": str(uuid.uuid4()),
            "type": "stake_announcement",
            "public_key": (
                self.wallet.public_key_pem
            ),
            "stake": stake_dict,
        }

        self.seen_message_ids.add(
            pkt["id"]
        )

        async with self.curr_stakers_condition:

            self.current_stakers[
                self.wallet.public_key_pem
            ] = amt

            self.current_stakes.add(
                new_stake
            )

        self.staked_amt = amt

        print(
            "Stake Created"
        )

        await self.broadcast_message(
            pkt
        )

    async def restart_epoch(self):

        while True:

            try:

                await asyncio.sleep(
                    EPOCH_TIME / 2
                )

                currTime = datetime.now()

                if (
                    currTime
                    - self.last_epoch_end_ts
                    > timedelta(
                        seconds=EPOCH_TIME * 7 / 6
                    )
                ):

                    self.last_epoch_end_ts = (
                        datetime.now()
                    )

                    async with self.curr_stakers_condition:

                        self.staked_amt = 0
                        self.current_stakers.clear()
                        self.current_stakes.clear()

            except asyncio.CancelledError:

                raise

    # ---------------------------------------------------------
    # BLOCK CREATION
    # ---------------------------------------------------------

    async def create_blocks(self, time):

        if not self.staker:
            return

        await asyncio.sleep(
            max(0, time)
        )

        if Chain.instance is None:
            return

        async with self.curr_stakers_condition:

            stakers_snapshot = dict(
                self.current_stakers
            )

            stakes_snapshot = list(
                self.current_stakes
            )

            own_stake = self.staked_amt

        if not stakers_snapshot:

            print(
                "\nNo stakers\n"
            )

            self.last_epoch_end_ts = (
                datetime.now()
            )

            self.staked_amt = 0

            return

        async with self.mem_pool_lock:

            transactions_in_mem_pool = list(
                self.mem_pool
            )

        pending_transactions = []

        for transaction in (
            transactions_in_mem_pool
        ):

            if not Chain.instance.transaction_exists_in_chain(
                transaction
            ):

                pending_transactions.append(
                    transaction
                )

        if not pending_transactions:

            print(
                "\nNo pending transactions\n"
            )

            self.last_epoch_end_ts = (
                datetime.now()
            )

            self.staked_amt = 0

            async with self.curr_stakers_condition:

                self.current_stakers.clear()
                self.current_stakes.clear()

            return

        if len(self.name_to_public_key_dict) <= 1:

            print(
                "\nDoesn't know enough people\n"
            )

            return

        print(
            "\nRunning vrf\n"
        )

        seed = Chain.instance.epoch_seed()

        vrf_proof = self.wallet.private_key.sign(
            seed.encode()
        )

        vrf_output = hashlib.sha256(
            vrf_proof
        ).hexdigest()

        vrf_output_int = int(
            vrf_output,
            16,
        )

        total_stake = sum(
            stakers_snapshot.values()
        )

        if total_stake <= 0:
            return

        threshold = (
            own_stake / total_stake
        ) * MAX_OUTPUT

        if vrf_output_int >= threshold:

            print(
                "\nYou've lost\n"
            )

            self.staked_amt = 0

            return

        print(
            "\nYou won\n"
        )

        values_iter = iter(
            self.name_to_public_key_dict.values()
        )

        pk1 = next(
            values_iter,
            None,
        )

        pk2 = next(
            values_iter,
            None,
        )

        if pk1 is None or pk2 is None:

            print(
                "\nNot enough known peers\n"
            )

            return

        acc_bal = Chain.instance.calc_balance(
            self.wallet.public_key_pem,
            self.mem_pool,
            stakes_snapshot,
        )

        payload = acc_bal * 0.75

        transaction1 = Transaction(
            payload,
            self.wallet.public_key_pem,
            pk1,
        )

        transaction1_str = str(
            transaction1
        )

        signature1 = (
            self.wallet.private_key.sign(
                transaction1_str.encode()
            )
        )

        transaction1.sign = signature1

        pending1 = list(
            pending_transactions
        )

        pending1.append(
            transaction1
        )

        newBlock1 = Block(
            Chain.instance.lastBlock.hash,
            pending1,
        )

        transaction2 = Transaction(
            payload,
            self.wallet.public_key_pem,
            pk2,
        )

        transaction2_str = str(
            transaction2
        )

        signature2 = (
            self.wallet.private_key.sign(
                transaction2_str.encode()
            )
        )

        transaction2.sign = signature2

        pending2 = list(
            pending_transactions
        )

        pending2.append(
            transaction2
        )

        newBlock2 = Block(
            Chain.instance.lastBlock.hash,
            pending2,
        )

        newBlock1.files = (
            self.file_hashes.copy()
        )

        newBlock2.files = (
            self.file_hashes.copy()
        )

        newBlock1.seed = seed
        newBlock2.seed = seed

        newBlock1.vrf_proof = vrf_proof
        newBlock2.vrf_proof = vrf_proof

        newBlock1.staked_amt = own_stake
        newBlock2.staked_amt = own_stake

        newBlock1.creator = (
            self.wallet.public_key_pem
        )

        newBlock2.creator = (
            self.wallet.public_key_pem
        )

        newBlock1.stakers = list(
            stakes_snapshot
        )

        newBlock2.stakers = list(
            stakes_snapshot
        )

        self.last_epoch_end_ts = (
            datetime.now()
        )

        print(
            "Block Appended"
        )

        for transaction in (
            newBlock1.transactions
        ):

            if transaction.receiver == "deploy":

                self.deploy_contract(
                    transaction
                )

        sign1 = self.wallet.private_key.sign(
            str(newBlock1).encode()
        )

        newBlock1.sign = sign1

        sign2 = self.wallet.private_key.sign(
            str(newBlock2).encode()
        )

        newBlock2.sign = sign2

        vrf_proof_b64 = (
            base64.b64encode(
                vrf_proof
            ).decode()
        )

        sign_b64_1 = (
            base64.b64encode(
                sign1
            ).decode()
        )

        sign_b64_2 = (
            base64.b64encode(
                sign2
            ).decode()
        )

        pkt1 = {
            "type": "new_block",
            "id": str(uuid.uuid4()),
            "block": (
                newBlock1.to_dict_with_stakers()
            ),
            "vrf_proof": vrf_proof_b64,
            "sign": sign_b64_1,
        }

        pkt2 = {
            "type": "new_block",
            "id": str(uuid.uuid4()),
            "block": (
                newBlock2.to_dict_with_stakers()
            ),
            "vrf_proof": vrf_proof_b64,
            "sign": sign_b64_2,
        }

        self.seen_message_ids.add(
            pkt1["id"]
        )

        self.seen_message_ids.add(
            pkt2["id"]
        )

        # IMPORTANT:
        # Your original code appended newBlock1 here.
        # Keep this only if intentionally creating a local
        # fork for your slashing demonstration.
        #
        # For normal PoS operation, do NOT append an
        # unvalidated block locally before network consensus.
        Chain.instance.chain.append(
            newBlock1
        )

        if self.activate_disk_save == "y":
            self.save_chain_to_disk()

        targets = (
            self.server_connections
            | self.client_connections
        )

        targets_list = list(
            targets
        )

        midpoint = (
            len(targets_list) // 2
        )

        for ws in targets_list[:midpoint]:

            try:

                await ws.send(
                    json.dumps(pkt1)
                )

            except Exception as e:

                print(
                    f"Error broadcasting: {e}"
                )

        for ws in targets_list[midpoint:]:

            try:

                await ws.send(
                    json.dumps(pkt2)
                )

            except Exception as e:

                print(
                    f"Error broadcasting: {e}"
                )

        async with self.mem_pool_lock:

            self.mem_pool = [
                transaction
                for transaction in self.mem_pool
                if not newBlock1.transaction_exists_in_block(
                    transaction
                )
            ]

        async with self.file_hashes_lock:

            for cid in list(
                self.file_hashes.keys()
            ):

                if newBlock1.cid_exists_in_block(
                    cid
                ):

                    self.file_hashes.pop(
                        cid,
                        None,
                    )

        async with self.curr_stakers_condition:

            self.staked_amt = 0
            self.current_stakers.clear()
            self.current_stakes.clear()

    # ---------------------------------------------------------
    # CHAIN SYNCHRONIZATION
    # ---------------------------------------------------------

    async def find_longest_chain(self):

        while True:

            try:

                pkt = {
                    "type": "chain_request",
                    "id": str(uuid.uuid4()),
                }

                self.seen_message_ids.add(
                    pkt["id"]
                )

                await self.broadcast_message(
                    pkt
                )

                print(
                    "\nSent out chain requests..."
                )

                await asyncio.sleep(
                    60
                )

            except asyncio.CancelledError:

                raise

            except Exception:

                traceback.print_exc()

                await asyncio.sleep(
                    5
                )

    # ---------------------------------------------------------
    # START
    # ---------------------------------------------------------

    async def start(
        self,
        bootstrap_host=None,
        bootstrap_port=None,
    ):

        await websockets.serve(
            self.handle_connections,
            self.host,
            self.port,
        )

        if (
            bootstrap_host
            and bootstrap_port
        ):

            try:

                normalized_bootstrap_host, normalized_bootstrap_port = (
                    normalize_endpoint(
                        (
                            bootstrap_host,
                            bootstrap_port,
                        )
                    )
                )

                asyncio.create_task(
                    self.connect_to_peer(
                        normalized_bootstrap_host,
                        normalized_bootstrap_port,
                    )
                )

            except Exception as e:

                print(
                    f"Bootstrap connection error: {e}"
                )

        else:

            self.chain = Chain(
                publicKey=self.wallet.public_key_pem,
                privatekey=self.wallet.private_key,
            )

            self.last_epoch_end_ts = (
                datetime.now()
            )

        reset_task = asyncio.create_task(
            self.restart_epoch()
        )

        inp_task = asyncio.create_task(
            self.user_input_handler()
        )

        consensus_task = asyncio.create_task(
            self.find_longest_chain()
        )

        disc_task = asyncio.create_task(
            self.discover_peers()
        )

        sampler_task = asyncio.create_task(
            self.gossip_peer_sampler()
        )

        try:

            await inp_task

        finally:

            for task in (
                reset_task,
                disc_task,
                consensus_task,
                sampler_task,
            ):

                task.cancel()

            await asyncio.gather(
                reset_task,
                disc_task,
                consensus_task,
                sampler_task,
                return_exceptions=True,
            )

            self.stop_daemon()