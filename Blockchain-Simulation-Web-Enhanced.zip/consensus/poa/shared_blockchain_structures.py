import json
import uuid
import base64
from typing import List, Dict
from datetime import datetime, timezone

from ecdsa import VerifyingKey, SigningKey, SECP256k1


class Transaction:
    def __init__(
        self,
        payload,
        sender: str,
        receiver: str,
        id=None,
        ts=None
    ):
        self.id = id or str(uuid.uuid4())
        self.payload = payload
        self.sender = sender
        self.receiver = receiver
        self.sign: bytes = None

        if ts is None:
            self.ts = datetime.now(timezone.utc).timestamp()
        else:
            self.ts = ts

    def to_dict(self):
        return {
            "id": self.id,
            "payload": self.payload,
            "sender": self.sender,
            "receiver": self.receiver,
            "ts": self.ts
        }

    def signing_dict(self):
        """
        Return exactly the transaction fields that are signed.
        The signature itself is deliberately excluded.
        """
        return self.to_dict()

    def to_signing_string(self):
        """
        Canonical representation used for signing/verifying.
        """
        return json.dumps(
            self.signing_dict(),
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False
        )

    def __eq__(self, other):
        if not isinstance(other, Transaction):
            return NotImplemented

        # Transaction ID is the unique transaction identity.
        return self.id == other.id

    def __hash__(self):
        return hash(self.id)

    def __str__(self):
        return self.to_signing_string()

    def is_valid_signature(self):
        """
        Verify this transaction's signature.

        Genesis transactions do not require a normal ECDSA signature.
        """
        if self.sender == "Genesis":
            return True

        if not self.sign:
            return False

        try:
            public_key = VerifyingKey.from_pem(
                self.sender.encode()
            )

            public_key.verify(
                self.sign,
                self.to_signing_string().encode("utf-8")
            )

            return True

        except Exception:
            return False


def txs_to_json_digestable_form(
    transactions: List[Transaction]
):
    """
    Convert transactions into deterministic JSON-compatible
    dictionaries.

    Signatures are encoded as base64 strings.
    """
    result = []

    for transaction in transactions:
        tx_dict = transaction.to_dict()

        if (
            transaction.sender != "Genesis"
            and transaction.sign is not None
        ):
            tx_dict["sign"] = base64.b64encode(
                transaction.sign
            ).decode("ascii")

        result.append(tx_dict)

    return result


class BaseBlock:
    def __init__(
        self,
        prevHash: str,
        transactions: List[Transaction],
        ts=None,
        id=None
    ):
        self.prevHash = prevHash
        self.transactions = transactions
        self.id = id or str(uuid.uuid4())

        if ts is None:
            self.ts = int(
                datetime.now(timezone.utc).timestamp() * 1000
            )
        else:
            self.ts = ts

        self.files: Dict[str, str] = {}

    def transaction_exists_in_block(
        self,
        transaction: Transaction
    ):
        if transaction is None:
            return False

        for existing_transaction in self.transactions:
            if existing_transaction.id == transaction.id:
                return True

        return False

    def cid_exists_in_block(self, cid: str):
        if cid is None:
            return False

        return cid in self.files


class CommonChain:

    def __init__(
        self,
        genesis_block=None,
        block_list=None
    ):
        if genesis_block is not None:
            self.chain = [genesis_block]

        elif block_list is not None:
            self.chain = list(block_list)

        else:
            raise ValueError(
                "Either genesis_block or block_list is required"
            )

    @property
    def lastBlock(self):
        if not self.chain:
            raise IndexError("Blockchain is empty")

        return self.chain[-1]

    def to_block_dict_list(self):
        result = []

        for block in self.chain:
            if not hasattr(block, "to_dict"):
                raise AttributeError(
                    "Block object does not implement to_dict()"
                )

            result.append(block.to_dict())

        return result

    def transaction_exists_in_chain(
        self,
        transaction: Transaction
    ):
        if transaction is None:
            return False

        for block in reversed(self.chain):
            if block.transaction_exists_in_block(
                transaction
            ):
                return True

        return False

    def cid_exists_in_chain(self, cid: str):
        if cid is None:
            return False

        for block in reversed(self.chain):
            if block.cid_exists_in_block(cid):
                return True

        return False


class Wallet:
    def __init__(
        self,
        private_key_pem: str = None
    ):
        if private_key_pem:
            self.private_key = SigningKey.from_pem(
                private_key_pem
            )
        else:
            self.private_key = SigningKey.generate(
                curve=SECP256k1
            )

        self.private_key_pem = (
            self.private_key.to_pem().decode()
        )

        self.public_key = (
            self.private_key.get_verifying_key()
        )

        self.public_key_pem = (
            self.public_key.to_pem().decode()
        )


def transaction_exists_in_block_list(
    blockList,
    transaction_tc: Transaction,
    idx
):
    """
    Return True if the transaction ID already appears in
    blocks before index idx.

    Blocks [0, idx) are searched.
    """
    if transaction_tc is None:
        return False

    try:
        limit = max(0, min(int(idx), len(blockList)))
    except (TypeError, ValueError):
        return False

    for i in range(limit):
        currBlock = blockList[i]

        for transaction in currBlock.transactions:
            if transaction.id == transaction_tc.id:
                return True

    return False


def valid_chain_length(i):
    """
    Calculate the depth after which blocks are considered
    sufficiently confirmed according to the original project rule.
    """
    valid_chain_len = int(i)

    if valid_chain_len < 250:
        valid_chain_len -= valid_chain_len // 5
    else:
        valid_chain_len -= 50

    return max(0, valid_chain_len)