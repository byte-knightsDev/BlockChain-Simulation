import json
import hashlib
import math
from typing import List
from ecdsa import SECP256k1, VerifyingKey

from shared_blockchain_structures import (
    Transaction,
    BaseBlock,
    CommonChain,
    Wallet,
    txs_to_json_digestable_form,
    transaction_exists_in_block_list,
)


GAS_PRICE = 0.001
MINER_REWARD = 6


# ============================================================
# Utility functions
# ============================================================

def public_key_to_pem(public_key):
    """
    Convert a public key into a JSON-serializable PEM string.
    """

    if public_key is None:
        return None

    if isinstance(public_key, VerifyingKey):
        return public_key.to_pem().decode("utf-8")

    if isinstance(public_key, bytes):
        try:
            return public_key.decode("utf-8")
        except UnicodeDecodeError:
            return None

    if isinstance(public_key, str):
        return public_key

    return str(public_key)


def is_valid_number(value):
    """
    Validate monetary values.

    bool is rejected because bool is a subclass of int.
    """

    if isinstance(value, bool):
        return False

    if not isinstance(value, (int, float)):
        return False

    try:
        return math.isfinite(float(value))
    except (TypeError, ValueError, OverflowError):
        return False


def get_transaction_amount(transaction):
    """
    Return the amount associated with a transaction.

    Normal transaction:
        payload = amount

    Deploy:
        payload = [contract_code, amount]

    Invoke:
        payload = [contract_id, function_name, args, state, amount]
    """

    try:
        if transaction.receiver in ("deploy", "invoke"):

            if not isinstance(
                transaction.payload,
                (list, tuple)
            ):
                return None

            if len(transaction.payload) == 0:
                return None

            amount = transaction.payload[-1]

        else:
            amount = transaction.payload

        if not is_valid_number(amount):
            return None

        amount = float(amount)

        if amount <= 0:
            return None

        return amount

    except Exception:
        return None


def verify_transaction_signature(transaction):
    """
    Verify a transaction's ECDSA signature.

    Genesis transactions are special and do not require
    a normal transaction signature.
    """

    try:

        if transaction.sender == "Genesis":
            return True

        if not transaction.sign:
            return False

        sender_pem = public_key_to_pem(
            transaction.sender
        )

        if not sender_pem:
            return False

        public_key = VerifyingKey.from_pem(
            sender_pem.encode("utf-8")
        )

        # IMPORTANT:
        # Transaction.__str__() in the corrected
        # shared_blockchain_structures.py uses the same
        # canonical representation that is signed.
        message = transaction.to_signing_string()

        public_key.verify(
            transaction.sign,
            message.encode("utf-8")
        )

        return True

    except Exception as e:

        print(
            f"Invalid transaction signature: {e}"
        )

        return False


# ============================================================
# Block
# ============================================================

class Block(BaseBlock):

    def __init__(
        self,
        prevHash: str,
        transactions: List[Transaction],
        ts=None,
        id=None
    ):

        super().__init__(
            prevHash,
            transactions,
            ts,
            id
        )

        self.miner_node_id = None
        self.miner_public_key = None
        self.signature = None
        self.miners_list = None

    # --------------------------------------------------------
    # Serialization
    # --------------------------------------------------------

    def to_dict(self):
        """
        Convert the block into a JSON-serializable dictionary.
        """

        miner_public_key = public_key_to_pem(
            self.miner_public_key
        )

        return {
            "id": self.id,
            "prevHash": self.prevHash,
            "transactions": txs_to_json_digestable_form(
                self.transactions
            ),
            "ts": self.ts,
            "miner_node_id": self.miner_node_id,
            "miner_public_key": miner_public_key,
            "miners_list": self.miners_list,
            "signature": self.signature,
            "files": self.files,
        }

    def __str__(self):
        return json.dumps(
            self.to_dict(),
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
        )

    # --------------------------------------------------------
    # Hash
    # --------------------------------------------------------

    @property
    def hash(self):
        """
        Deterministic SHA-256 hash of the complete block.

        The signature is included in the block hash.
        """

        block_string = json.dumps(
            self.to_dict(),
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
        )

        return hashlib.sha256(
            block_string.encode("utf-8")
        ).hexdigest()

    # --------------------------------------------------------
    # Signing
    # --------------------------------------------------------

    def get_message_to_sign(self):
        """
        Return the exact canonical byte representation
        used for block signing and verification.

        The block signature itself is intentionally excluded.
        """

        miner_public_key = public_key_to_pem(
            self.miner_public_key
        )

        message = {
            "id": self.id,
            "ts": self.ts,
            "prevHash": self.prevHash,

            "transactions": [
                transaction.to_dict()
                for transaction in self.transactions
            ],

            "miner_node_id": self.miner_node_id,
            "miner_public_key": miner_public_key,
            "miners_list": self.miners_list,
            "files": self.files,
        }

        return json.dumps(
            message,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
        ).encode("utf-8")

    # --------------------------------------------------------
    # Signature
    # --------------------------------------------------------

    def is_valid_signature(self):
        """
        Verify the block's ECDSA signature.

        Signature is stored as hexadecimal text by p2p.py.
        """

        try:

            if not self.miner_public_key:

                print(
                    "Block has no miner public key"
                )

                return False

            if not self.signature:

                print(
                    "Block has no signature"
                )

                return False

            miner_public_key = public_key_to_pem(
                self.miner_public_key
            )

            public_key = VerifyingKey.from_pem(
                miner_public_key.encode("utf-8")
            )

            # ------------------------------------------------
            # Convert signature to bytes.
            # ------------------------------------------------

            if isinstance(self.signature, bytes):

                signature_bytes = self.signature

            elif isinstance(self.signature, str):

                signature_text = self.signature.strip()

                try:

                    signature_bytes = bytes.fromhex(
                        signature_text
                    )

                except ValueError:

                    # Compatibility fallback if an older
                    # chain stored the signature as base64.
                    import base64

                    signature_bytes = base64.b64decode(
                        signature_text,
                        validate=True
                    )

            else:

                print(
                    "Invalid block signature format"
                )

                return False

            if not signature_bytes:

                return False

            # ------------------------------------------------
            # Generate exactly the same message that was signed.
            # ------------------------------------------------

            message = self.get_message_to_sign()

            public_key.verify(
                signature_bytes,
                message
            )

            return True

        except Exception as e:

            print(
                f"Invalid block signature: {e}"
            )

            return False


# ============================================================
# Balance
# ============================================================

def valid_chain_length(i):
    """
    Number of blocks to consider.

    For this PoA implementation, all blocks before the
    current transaction are considered.
    """

    if i <= 0:
        return 0

    return int(i)


def calc_balance_block_list(
    block_list: List[Block],
    publicKey,
    i,
    pending_transactions: List[Transaction] = None,
):
    """
    Calculate balance using blocks [0, i).

    Pending transactions only subtract outgoing amounts.
    """

    if not block_list:
        return 0

    publicKey = public_key_to_pem(
        publicKey
    )

    balance = 0

    valid_length = min(
        valid_chain_length(i),
        len(block_list),
    )

    for block_index in range(valid_length):

        block = block_list[block_index]

        for transaction in block.transactions:

            sender = public_key_to_pem(
                transaction.sender
            )

            receiver = transaction.receiver

            amount = get_transaction_amount(
                transaction
            )

            if amount is None:
                continue

            # ------------------------------------------------
            # Outgoing
            # ------------------------------------------------

            if sender == publicKey:

                balance -= amount

            # ------------------------------------------------
            # Incoming
            # ------------------------------------------------

            elif receiver == publicKey:

                if receiver not in (
                    "deploy",
                    "invoke",
                ):

                    balance += amount

        # ----------------------------------------------------
        # Miner reward
        # ----------------------------------------------------

        block_miner_key = public_key_to_pem(
            block.miner_public_key
        )

        if block_miner_key == publicKey:

            balance += MINER_REWARD

    # --------------------------------------------------------
    # Pending outgoing transactions
    # --------------------------------------------------------

    if pending_transactions:

        for transaction in pending_transactions:

            sender = public_key_to_pem(
                transaction.sender
            )

            if sender != publicKey:
                continue

            amount = get_transaction_amount(
                transaction
            )

            if amount is not None:

                balance -= amount

    return balance


# ============================================================
# Chain
# ============================================================

class Chain(CommonChain):

    instance = None

    def __init__(
        self,
        publicKey=None,
        blockList=None,
    ):
        """
        Create the singleton chain.

        New network:
            Chain(publicKey=...)

        Existing network:
            Chain(blockList=...)
        """

        if Chain.instance is not None:
            return

        if (
            publicKey is not None
            and blockList is None
        ):

            publicKey = public_key_to_pem(
                publicKey
            )

            # ------------------------------------------------
            # Genesis transaction
            # ------------------------------------------------

            genesis_transaction = Transaction(
                50,
                "Genesis",
                publicKey,
            )

            # ------------------------------------------------
            # Genesis block
            # ------------------------------------------------

            genesis_block = Block(
                None,
                [genesis_transaction],
            )

            super().__init__(
                genesis_block=genesis_block
            )

        elif (
            blockList is not None
            and publicKey is None
        ):

            if not isinstance(
                blockList,
                list
            ):

                raise ValueError(
                    "blockList must be a list"
                )

            if len(blockList) == 0:

                raise ValueError(
                    "Cannot create chain from empty block list"
                )

            super().__init__(
                block_list=blockList
            )

        else:

            raise ValueError(
                "Invalid Chain initialization arguments"
            )

        Chain.instance = self

    # --------------------------------------------------------
    # Mining
    # --------------------------------------------------------

    def mine(self, block: Block):
        """
        Compatibility method.

        Actual PoA mining is performed by p2p.py.
        """

        return None

    # --------------------------------------------------------
    # Rewrite
    # --------------------------------------------------------

    def rewrite(
        self,
        blockList: List[Block]
    ):

        if not blockList:
            return False

        if len(self.chain) >= len(blockList):
            return False

        self.chain = list(blockList)

        return True

    # --------------------------------------------------------
    # Block validation
    # --------------------------------------------------------

    def isValidBlock(
        self,
        block: Block,
        reqd_miner_node_id,
        reqd_miner_public_key,
    ):

        try:

            if not self.chain:

                print(
                    "Chain is empty"
                )

                return False

            if block is None:

                print(
                    "Block is None"
                )

                return False

            # ------------------------------------------------
            # Block ID
            # ------------------------------------------------

            for existing_block in self.chain:

                if existing_block.id == block.id:

                    print(
                        "Duplicate block ID"
                    )

                    return False

            # ------------------------------------------------
            # Required miner
            # ------------------------------------------------

            if (
                block.miner_node_id
                != reqd_miner_node_id
            ):

                print(
                    "Mined by malicious/incorrect miner"
                )

                return False

            # ------------------------------------------------
            # Previous hash
            # ------------------------------------------------

            expected_prev_hash = self.lastBlock.hash

            if block.prevHash != expected_prev_hash:

                print(
                    "Hash Problem"
                )

                print(
                    f"Expected prev hash: "
                    f"{expected_prev_hash}"
                )

                print(
                    f"Received prev hash: "
                    f"{block.prevHash}"
                )

                return False

            # ------------------------------------------------
            # Miner public key
            # ------------------------------------------------

            expected_public_key = public_key_to_pem(
                reqd_miner_public_key
            )

            actual_public_key = public_key_to_pem(
                block.miner_public_key
            )

            if not expected_public_key:

                print(
                    "Required miner public key missing"
                )

                return False

            if actual_public_key != expected_public_key:

                print(
                    "Invalid miner public key"
                )

                return False

            # ------------------------------------------------
            # Block signature
            # ------------------------------------------------

            if not block.is_valid_signature():

                print(
                    "Invalid Signature On Block"
                )

                return False

            # ------------------------------------------------
            # Transaction IDs inside this block
            # ------------------------------------------------

            transaction_ids = set()

            for transaction in block.transactions:

                if transaction.id in transaction_ids:

                    print(
                        "Duplicate transaction ID "
                        "inside block"
                    )

                    return False

                transaction_ids.add(
                    transaction.id
                )

            # ------------------------------------------------
            # Validate transactions
            # ------------------------------------------------

            pending_transactions = []

            for transaction in block.transactions:

                # --------------------------------------------
                # Existing transaction
                # --------------------------------------------

                if self.transaction_exists_in_chain(
                    transaction
                ):

                    print(
                        "Duplicate transaction"
                    )

                    return False

                # --------------------------------------------
                # Transaction signature
                # --------------------------------------------

                if not verify_transaction_signature(
                    transaction
                ):

                    print(
                        "Invalid Signature On Transaction"
                    )

                    return False

                # --------------------------------------------
                # Amount
                # --------------------------------------------

                amount = get_transaction_amount(
                    transaction
                )

                if amount is None:

                    print(
                        "Invalid transaction amount"
                    )

                    return False

                # --------------------------------------------
                # Genesis transaction should never appear
                # in a non-genesis block.
                # --------------------------------------------

                if transaction.sender == "Genesis":

                    print(
                        "Genesis transaction found "
                        "outside genesis block"
                    )

                    return False

                # --------------------------------------------
                # Balance
                # --------------------------------------------

                balance = self.calc_balance(
                    publicKey=transaction.sender,
                    pending_transactions=pending_transactions,
                )

                if amount > balance:

                    print(
                        "Transaction attempts to "
                        "spend more than available balance"
                    )

                    return False

                pending_transactions.append(
                    transaction
                )

            return True

        except Exception as e:

            print(
                f"Exception while validating block: {e}"
            )

            return False

    # --------------------------------------------------------
    # Balance
    # --------------------------------------------------------

    def calc_balance(
        self,
        publicKey,
        pending_transactions: List[Transaction] = None,
    ):

        if not self.chain:
            return 0

        publicKey = public_key_to_pem(
            publicKey
        )

        balance = 0

        for block in self.chain:

            for transaction in block.transactions:

                sender = public_key_to_pem(
                    transaction.sender
                )

                receiver = transaction.receiver

                amount = get_transaction_amount(
                    transaction
                )

                if amount is None:
                    continue

                # --------------------------------------------
                # Outgoing
                # --------------------------------------------

                if sender == publicKey:

                    balance -= amount

                # --------------------------------------------
                # Incoming
                # --------------------------------------------

                elif receiver == publicKey:

                    if receiver not in (
                        "deploy",
                        "invoke",
                    ):

                        balance += amount

            # ----------------------------------------------
            # Miner reward
            # ----------------------------------------------

            miner_key = public_key_to_pem(
                block.miner_public_key
            )

            if miner_key == publicKey:

                balance += MINER_REWARD

        # ----------------------------------------------------
        # Pending outgoing transactions
        # ----------------------------------------------------

        if pending_transactions:

            for transaction in pending_transactions:

                sender = public_key_to_pem(
                    transaction.sender
                )

                if sender != publicKey:
                    continue

                amount = get_transaction_amount(
                    transaction
                )

                if amount is not None:

                    balance -= amount

        return balance


# ============================================================
# Full chain validation
# ============================================================

def isvalidChain(blockList: List[Block]):
    """
    Validate an entire blockchain.

    Checks:

    1. Chain is not empty.
    2. Genesis block is structurally valid.
    3. Genesis block signature is valid.
    4. Every block points to the previous block.
    5. Every block has a valid signature.
    6. Every block has a miner identity.
    7. Transaction signatures are valid.
    8. Transaction IDs are unique.
    9. Transactions do not overspend.
    """

    try:

        # ----------------------------------------------------
        # Basic checks
        # ----------------------------------------------------

        if not blockList:

            print(
                "Empty chain"
            )

            return False

        if not isinstance(
            blockList,
            list
        ):

            print(
                "Invalid chain type"
            )

            return False

        # ----------------------------------------------------
        # Genesis
        # ----------------------------------------------------

        genesis = blockList[0]

        if genesis.prevHash is not None:

            print(
                "Invalid genesis prevHash"
            )

            return False

        if not genesis.miner_node_id:

            print(
                "Invalid genesis miner node ID"
            )

            return False

        if not genesis.miner_public_key:

            print(
                "Invalid genesis miner public key"
            )

            return False

        if not genesis.signature:

            print(
                "Invalid genesis signature"
            )

            return False

        # ----------------------------------------------------
        # Genesis transactions
        # ----------------------------------------------------

        if len(genesis.transactions) == 0:

            print(
                "Genesis has no transaction"
            )

            return False

        genesis_ids = set()

        for transaction in genesis.transactions:

            if transaction.id in genesis_ids:

                print(
                    "Duplicate transaction in genesis"
                )

                return False

            genesis_ids.add(
                transaction.id
            )

            if transaction.sender != "Genesis":

                print(
                    "Invalid genesis transaction sender"
                )

                return False

            if not verify_transaction_signature(
                transaction
            ):

                print(
                    "Invalid genesis transaction"
                )

                return False

            amount = get_transaction_amount(
                transaction
            )

            if amount is None:

                print(
                    "Invalid genesis transaction amount"
                )

                return False

        # ----------------------------------------------------
        # Genesis block signature
        # ----------------------------------------------------

        if not genesis.is_valid_signature():

            print(
                "Invalid genesis block signature"
            )

            return False

        # ----------------------------------------------------
        # Validate every later block
        # ----------------------------------------------------

        for i in range(1, len(blockList)):

            current_block = blockList[i]
            previous_block = blockList[i - 1]

            # ------------------------------------------------
            # Basic block fields
            # ------------------------------------------------

            if not current_block.id:

                print(
                    f"Missing block ID at block {i}"
                )

                return False

            if not current_block.miner_node_id:

                print(
                    f"Missing miner node ID at block {i}"
                )

                return False

            if not current_block.miner_public_key:

                print(
                    f"Missing miner public key at block {i}"
                )

                return False

            # ------------------------------------------------
            # Previous hash
            # ------------------------------------------------

            if (
                current_block.prevHash
                != previous_block.hash
            ):

                print(
                    f"Invalid prevHash at block {i}"
                )

                return False

            # ------------------------------------------------
            # Block signature
            # ------------------------------------------------

            if not current_block.is_valid_signature():

                print(
                    f"Invalid block signature "
                    f"at block {i}"
                )

                return False

            # ------------------------------------------------
            # Transaction IDs within current block
            # ------------------------------------------------

            current_transaction_ids = set()

            for transaction in current_block.transactions:

                if transaction.id in current_transaction_ids:

                    print(
                        f"Duplicate transaction ID "
                        f"at block {i}"
                    )

                    return False

                current_transaction_ids.add(
                    transaction.id
                )

            # ------------------------------------------------
            # Validate transactions
            # ------------------------------------------------

            pending_transactions = []

            for transaction in current_block.transactions:

                # --------------------------------------------
                # Transaction must not already exist in
                # an earlier block.
                # --------------------------------------------

                if transaction_exists_in_block_list(
                    blockList,
                    transaction,
                    i,
                ):

                    print(
                        f"Duplicate transaction "
                        f"at block {i}"
                    )

                    return False

                # --------------------------------------------
                # Genesis transactions are only permitted
                # in the genesis block.
                # --------------------------------------------

                if transaction.sender == "Genesis":

                    print(
                        f"Genesis transaction found "
                        f"at block {i}"
                    )

                    return False

                # --------------------------------------------
                # Signature
                # --------------------------------------------

                if not verify_transaction_signature(
                    transaction
                ):

                    print(
                        f"Invalid transaction signature "
                        f"at block {i}"
                    )

                    return False

                # --------------------------------------------
                # Amount
                # --------------------------------------------

                amount = get_transaction_amount(
                    transaction
                )

                if amount is None:

                    print(
                        f"Invalid transaction amount "
                        f"at block {i}"
                    )

                    return False

                # --------------------------------------------
                # Balance
                # --------------------------------------------

                balance = calc_balance_block_list(
                    blockList,
                    transaction.sender,
                    i,
                    pending_transactions,
                )

                if amount > balance:

                    print(
                        f"Insufficient balance for "
                        f"transaction at block {i}"
                    )

                    return False

                pending_transactions.append(
                    transaction
                )

        return True

    except Exception as e:

        print(
            f"Exception while validating chain: {e}"
        )

        return False