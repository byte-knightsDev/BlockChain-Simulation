import asyncio
import websockets
import json
import uuid
import base64
from typing import Set, Dict, List, Tuple
import copy
import socket
from consensus.poa.blockchain_structures import (
    Transaction,
    Block,
    Wallet,
    Chain,
    isvalidChain
)
from ipfs.ipfs import addToIpfs, download_ipfs_file_subprocess
from smart_contract.contracts_db import SmartContractDatabase
from smart_contract.secure_executor import SecureContractExecutor
from storage.storage_manager import (
    save_node_id,
    load_node_id,
    save_key,
    load_key,
    save_chain,
    load_chain,
    save_peers,
    load_peers
)
from ecdsa import VerifyingKey
import binascii
import os
import tempfile
import subprocess
import hashlib
import ast
from pathlib import Path


MAX_CONNECTIONS = 8
GAS_PRICE = 0.001
BASE_DEPLOY_COST = 5
CONSENSUS = "poa"


def get_random_element(s):
    """
    Return a random element from a set.
    """
    import random

    if not s:
        return None

    return random.choice(list(s))


def normalize_endpoint(ep):
    """
    Resolve host into IPv4 address and convert port to int.
    """
    host, port = ep

    try:
        resolved_host = socket.gethostbyname(host)
    except socket.gaierror:
        resolved_host = host

    return (resolved_host, int(port))


def get_contract_code_from_notepad():
    """
    Create a temporary Python file, open it in Notepad,
    then read the edited contract code.
    """

    with tempfile.NamedTemporaryFile(
        suffix=".py",
        delete=False,
        mode="w+",
        encoding="utf-8"
    ) as tmp_file:

        temp_filename = tmp_file.name

        tmp_file.write(
            "# Write your smart contract function here.\n"
        )

        tmp_file.write(
            "def contract_logic(parameter1, parameter2, parameter3, state):\n"
        )

        tmp_file.write(
            "    # your code here\n"
        )

        tmp_file.write(
            "    return state, 'some message'\n"
        )

    try:
        subprocess.call(["notepad.exe", temp_filename])

        with open(temp_filename, "r", encoding="utf-8") as f:
            contract_code = f.read()

    finally:
        try:
            os.remove(temp_filename)
        except OSError:
            pass

    return contract_code


class Peer:

    def __init__(
        self,
        host,
        port,
        name,
        activate_disk_load,
        activate_disk_save
    ):

        self.host = host
        self.port = int(port)
        self.name = name

        self.activate_disk_save = activate_disk_save

        # ---------------------------------------------------------
        # IPFS configuration
        # ---------------------------------------------------------

        self.ipfs_port = self.port + 50
        self.gateway_port = self.port + 81
        self.swarm_tcp = self.port + 2
        self.swarm_udp = self.port + 3

        self.repo_path = Path.home() / f".ipfs_{self.port}"

        self.env = os.environ.copy()
        self.env["IPFS_PATH"] = str(self.repo_path)

        # ---------------------------------------------------------
        # Mining / PoA state
        # ---------------------------------------------------------

        self.miner = False
        self.miner_task = None

        self.round = 0
        self.round_task = None

        self.admin_id = None

        # ---------------------------------------------------------
        # Node ID
        # ---------------------------------------------------------

        self.node_id = None

        if activate_disk_load == "y":
            self.load_node_id_from_disk()

        if not self.node_id:
            self.node_id = str(uuid.uuid4())

            if self.activate_disk_save == "y":
                self.save_node_id_to_disk()

        # List of:
        # [
        #     [miners_list, activation_block],
        #     ...
        # ]
        self.miners: List[list] = []

        # ---------------------------------------------------------
        # WebSocket connections
        # ---------------------------------------------------------

        self.server_connections: Set = set()

        self.client_connections: Set = set()

        self.outbound_peers: Set[Tuple[str, int]] = set()

        # ---------------------------------------------------------
        # Message deduplication
        # ---------------------------------------------------------

        self.seen_message_ids: Set[str] = set()

        # ---------------------------------------------------------
        # Known peers
        # ---------------------------------------------------------

        self.known_peers: Dict[
            Tuple[str, int],
            Tuple[str, str, str]
        ] = {}

        if activate_disk_load == "y":
            self.load_known_peers_from_disk()

        # ---------------------------------------------------------
        # Ping / handshake state
        # ---------------------------------------------------------

        self.got_pong = {}

        self.have_sent_peer_info = {}

        # ---------------------------------------------------------
        # Transactions / files
        # ---------------------------------------------------------

        self.mem_pool: List[Transaction] = []

        self.file_hashes: Dict[str, str] = {}

        self.file_hashes_lock = asyncio.Lock()

        # ---------------------------------------------------------
        # Peer lookup dictionaries
        # ---------------------------------------------------------

        self.name_to_public_key_dict: Dict[str, str] = {}

        self.node_id_to_name_dict: Dict[str, str] = {}

        self.name_to_node_id_dict: Dict[str, str] = {}

        # ---------------------------------------------------------
        # Wallet
        # ---------------------------------------------------------

        self.wallet = None

        if activate_disk_load == "y":
            self.load_key_from_disk()

        if not self.wallet:
            self.wallet = Wallet()

            if self.activate_disk_save == "y":
                self.save_key_to_disk()

        # ---------------------------------------------------------
        # Blockchain
        # ---------------------------------------------------------

        self.chain = None

        if activate_disk_load == "y":
            self.load_chain_from_disk()

        # ---------------------------------------------------------
        # Smart contracts
        # ---------------------------------------------------------

        self.contractsDB = SmartContractDatabase()

        # ---------------------------------------------------------
        # Mempool synchronization
        # ---------------------------------------------------------

        self.mem_pool_condition = asyncio.Condition()

        # ---------------------------------------------------------
        # IPFS daemon
        # ---------------------------------------------------------

        self.daemon_process = None

    # =============================================================
    # DISK STORAGE
    # =============================================================

    def save_node_id_to_disk(self):
        save_node_id(self.node_id, CONSENSUS)

    def load_node_id_from_disk(self):
        node_id = load_node_id(CONSENSUS)

        if not node_id:
            self.node_id = None
            return

        self.node_id = node_id

    def save_key_to_disk(self):
        if self.wallet is None:
            return

        key = self.wallet.private_key_pem
        save_key(key, CONSENSUS)

    def load_key_from_disk(self):
        key = load_key(CONSENSUS)

        if not key:
            self.wallet = None
            return

        self.wallet = Wallet(key)

    def load_chain_from_disk(self):

        block_dict_list = load_chain(CONSENSUS)

        if not block_dict_list:
            self.chain = None
            return

        block_list: List[Block] = []

        try:
            for block_dict in block_dict_list:
                block = self.block_dict_to_block(block_dict)
                block_list.append(block)

            self.chain = Chain(blockList=block_list)

        except Exception as e:
            print(f"Failed to load blockchain from disk: {e}")
            self.chain = None

    def save_chain_to_disk(self):

        try:
            if Chain.instance is None:
                return

            chain = Chain.instance.to_block_dict_list()

            save_chain(chain, CONSENSUS)

        except Exception as e:
            print(f"Failed to save blockchain: {e}")

    def save_known_peers_to_disk(self):

        try:
            content = {}

            for key, value in self.known_peers.items():
                content[json.dumps(key)] = list(value)

            save_peers(content, CONSENSUS)

        except Exception as e:
            print(f"Failed to save peers: {e}")

    def load_known_peers_from_disk(self):

        content = load_peers(CONSENSUS)

        if not content:
            self.known_peers = {}
            return

        self.known_peers = {}

        try:
            for key, value in content.items():

                endpoint = tuple(ast.literal_eval(key))

                self.known_peers[endpoint] = tuple(value)

                name = str(value[0])
                public_key = str(value[1])
                node_id = str(value[2])

                self.name_to_public_key_dict[
                    name.lower()
                ] = public_key

                self.node_id_to_name_dict[
                    node_id
                ] = name.lower()

                self.name_to_node_id_dict[
                    name.lower()
                ] = node_id

        except Exception as e:
            print(f"Failed to load known peers: {e}")
            self.known_peers = {}

    # =============================================================
    # PEER INFORMATION
    # =============================================================

    def get_peer_info_message(self):

        pkt = {
            "type": "peer_info",
            "id": str(uuid.uuid4()),
            "data": {
                "host": self.host,
                "port": self.port,
                "name": self.name,
                "public_key": self.wallet.public_key_pem,
                "node_id": self.node_id
            }
        }

        self.seen_message_ids.add(pkt["id"])

        return pkt

    def get_known_peers_message(self):

        peers = []

        for (
            host,
            port
        ), (
            name,
            public_key,
            node_id
        ) in self.known_peers.items():

            peers.append({
                "host": host,
                "port": port,
                "name": name,
                "public_key": public_key,
                "node_id": node_id
            })

        # Always include ourselves.
        peers.append({
            "host": self.host,
            "port": self.port,
            "name": self.name,
            "public_key": self.wallet.public_key_pem,
            "node_id": self.node_id
        })

        pkt = {
            "type": "known_peers",
            "id": str(uuid.uuid4()),
            "peers": peers
        }

        self.seen_message_ids.add(pkt["id"])

        return pkt

    async def broadcast_miners_list(
        self,
        miners_list,
        activation_block
    ):

        pkt = {
            "type": "miners_list_update",
            "id": str(uuid.uuid4()),
            "miners_list": miners_list,
            "activation_block": activation_block
        }

        message = json.dumps(
            pkt,
            sort_keys=True
        ).encode()

        signature = self.wallet.private_key.sign(message)

        pkt["signature"] = signature.hex()

        self.seen_message_ids.add(pkt["id"])

        await self.broadcast_message(pkt)

    # =============================================================
    # BLOCK CONVERSION
    # =============================================================

    def block_dict_to_block(self, block_dict):

        new_block_id = block_dict["id"]
        new_block_prevHash = block_dict["prevHash"]
        new_block_ts = block_dict["ts"]

        new_block_miner_node_id = block_dict.get(
            "miner_node_id"
        )

        new_block_miner_public_key = block_dict.get(
            "miner_public_key"
        )

        new_block_miners_list = block_dict.get(
            "miners_list",
            []
        )

        new_block_signature = block_dict.get(
            "signature"
        )

        transactions = []

        for transaction_dict in block_dict.get(
            "transactions",
            []
        ):

            transaction = Transaction(
                transaction_dict["payload"],
                transaction_dict["sender"],
                transaction_dict["receiver"],
                transaction_dict["id"],
                transaction_dict["ts"]
            )

            if transaction.sender != "Genesis":

                sign_value = transaction_dict.get("sign")

                if sign_value:
                    transaction.sign = base64.b64decode(
                        sign_value
                    )

            transactions.append(transaction)

        newBlock = Block(
            new_block_prevHash,
            transactions,
            new_block_ts,
            new_block_id
        )

        newBlock.miner_node_id = new_block_miner_node_id
        newBlock.miner_public_key = new_block_miner_public_key
        newBlock.miners_list = new_block_miners_list

        newBlock.files = block_dict.get(
            "files",
            {}
        )

        newBlock.signature = new_block_signature

        return newBlock

    # =============================================================
    # PUBLIC KEY LOOKUP
    # =============================================================

    def get_public_key_by_node_id(self, target_node_id):

        if target_node_id == self.node_id:
            return self.wallet.public_key_pem

        for (
            host,
            port
        ), (
            name,
            public_key,
            node_id
        ) in self.known_peers.items():

            if node_id == target_node_id:
                return public_key

        return None

    # =============================================================
    # MINER MANAGEMENT
    # =============================================================

    def get_current_miners_list(self):

        if Chain.instance is None:
            return []

        if not Chain.instance.chain:
            return []

        miners_list = None

        if (
            self.miners
            and len(Chain.instance.chain) == self.miners[0][1]
        ):

            miners_list = self.miners[0][0]

            for i in range(1, len(self.miners)):

                if (
                    self.miners[i][1]
                    == len(Chain.instance.chain)
                ):
                    miners_list = self.miners[i][0]
                else:
                    break

        else:

            miners_list = Chain.instance.chain[-1].miners_list

        if miners_list is None:
            return []

        return list(miners_list)

    # =============================================================
    # CONNECTION CLEANUP
    # =============================================================

    def discard_server_connection_details(
        self,
        websocket
    ):

        self.server_connections.discard(websocket)

    def discard_client_connection_details(
        self,
        websocket
    ):

        self.client_connections.discard(websocket)

        self.got_pong.pop(
            websocket,
            None
        )

        self.have_sent_peer_info.pop(
            websocket,
            None
        )

        try:

            remote_address = websocket.remote_address

            if remote_address:
                normalized_endpoint = normalize_endpoint(
                    (
                        remote_address[0],
                        remote_address[1]
                    )
                )

                self.outbound_peers.discard(
                    normalized_endpoint
                )

        except Exception:
            pass

    # =============================================================
    # MINING ROLE
    # =============================================================

    async def update_role(self, is_miner_now):

        if is_miner_now and not self.miner:

            self.miner = True

            if (
                self.miner_task is None
                or self.miner_task.done()
            ):

                self.miner_task = asyncio.create_task(
                    self.mine_blocks()
                )

        elif not is_miner_now and self.miner:

            self.miner = False

            if self.miner_task:

                task = self.miner_task
                self.miner_task = None

                task.cancel()

                try:
                    await task
                except asyncio.CancelledError:
                    pass
                except Exception as e:
                    print(
                        f"Miner task stopped with error: {e}"
                    )

    # =============================================================
    # ROUND CALCULATOR
    # =============================================================

    async def round_calculator(self):

        self.round = 0

        try:

            while True:

                for _ in range(2):
                    await asyncio.sleep(5)

                if len(self.mem_pool) > 0:

                    for _ in range(16):
                        await asyncio.sleep(5)

                    print("Shifting miner...")

                    self.round += 1

                    print("Miner shifted")

        except asyncio.CancelledError:

            print(
                "Round calculator task stopped cleanly"
            )

            raise

    # =============================================================
    # CONTRACT VALIDATION
    # =============================================================

    def valid_deploy_transaction(self, payload):

        try:

            contract_code = payload[0]

            gas_used = (
                len(contract_code) // 10
                + BASE_DEPLOY_COST
            )

            amount = gas_used * GAS_PRICE

            return amount == payload[-1]

        except Exception as e:

            print(
                f"Invalid deploy transaction: {e}"
            )

            return False

    def valid_invoke_transaction(self, payload):

        try:

            contract_id = payload[0]
            func_name = payload[1]
            args = payload[2]

            response = self.run_contract(
                [
                    contract_id,
                    func_name,
                    args
                ]
            )

            if response.get("error") is not None:
                return False

            state = response["state"]
            gas_used = response["gas_used"]

            amount = gas_used * GAS_PRICE

            if state != payload[3]:
                return False

            if amount != payload[-1]:
                return False

            return True

        except Exception as e:

            print(
                f"Invalid invoke transaction: {e}"
            )

            return False

    # =============================================================
    # UNIQUE PEER NAME
    # =============================================================

    def get_unique_name(self, base_name):

        existing_names = []

        for (
            host,
            port
        ), (
            name,
            public_key,
            node_id
        ) in self.known_peers.items():

            existing_names.append(
                name.lower()
            )

        existing_names.append(
            self.name.lower()
        )

        base_name = base_name.lower()

        if base_name not in existing_names:
            return base_name

        counter = 1

        while True:

            new_name = f"{base_name}{counter}"

            if new_name not in existing_names:
                return new_name

            counter += 1

    # =============================================================
    # MESSAGE HANDLING
    # =============================================================

    async def handle_messages(
        self,
        websocket,
        msg
    ):

        if not isinstance(msg, dict):
            return

        t = msg.get("type")
        message_id = msg.get("id")

        if not t or not message_id:
            return

        if message_id in self.seen_message_ids:
            return

        self.seen_message_ids.add(message_id)

        # ---------------------------------------------------------
        # Miner list update
        # ---------------------------------------------------------

        if t == "miners_list_update":

            try:

                admin_public_key = (
                    self.get_public_key_by_node_id(
                        self.admin_id
                    )
                )

                if not admin_public_key:
                    print(
                        "Cannot verify miner update: "
                        "admin public key unavailable."
                    )
                    return

                public_key = VerifyingKey.from_pem(
                    admin_public_key.encode()
                )

                message = json.dumps(
                    {
                        "type": "miners_list_update",
                        "id": msg["id"],
                        "miners_list": msg["miners_list"],
                        "activation_block": msg[
                            "activation_block"
                        ]
                    },
                    sort_keys=True
                ).encode()

                signature = binascii.unhexlify(
                    msg["signature"]
                )

                public_key.verify(
                    signature,
                    message
                )

            except Exception as e:

                print(
                    f"Invalid miners list update signature: {e}"
                )

                return

            self.miners.append(
                [
                    msg["miners_list"],
                    msg["activation_block"]
                ]
            )

            await self.broadcast_message(msg)

        # ---------------------------------------------------------
        # Ping
        # ---------------------------------------------------------

        elif t == "ping":

            pkt = {
                "type": "pong",
                "id": str(uuid.uuid4())
            }

            self.seen_message_ids.add(
                pkt["id"]
            )

            await self.send_message(
                websocket,
                pkt,
                False
            )

        # ---------------------------------------------------------
        # Pong
        # ---------------------------------------------------------

        elif t == "pong":

            self.got_pong[websocket] = True

            if not self.have_sent_peer_info.get(
                websocket,
                True
            ):

                message = self.get_peer_info_message()

                await self.send_message(
                    websocket,
                    message,
                    True
                )

                self.have_sent_peer_info[
                    websocket
                ] = True

        # ---------------------------------------------------------
        # Peer info
        # ---------------------------------------------------------

        elif t == "peer_info":

            try:

                data = msg["data"]

                normalized_self = normalize_endpoint(
                    (
                        self.host,
                        self.port
                    )
                )

                normalized_endpoint = normalize_endpoint(
                    (
                        data["host"],
                        data["port"]
                    )
                )

                if (
                    normalized_endpoint not in self.known_peers
                    and normalized_endpoint != normalized_self
                ):

                    peer_name = data["name"]
                    public_key = data["public_key"]
                    node_id = data["node_id"]

                    self.known_peers[
                        normalized_endpoint
                    ] = (
                        peer_name,
                        public_key,
                        node_id
                    )

                    self.name_to_public_key_dict[
                        peer_name.lower()
                    ] = public_key

                    self.node_id_to_name_dict[
                        node_id
                    ] = peer_name.lower()

                    self.name_to_node_id_dict[
                        peer_name.lower()
                    ] = node_id

                    if self.activate_disk_save == "y":
                        self.save_known_peers_to_disk()

                    print(
                        f"Registered peer "
                        f"{peer_name} "
                        f"{data['host']}:{data['port']}"
                    )

                message = self.get_known_peers_message()

                await self.send_message(
                    websocket,
                    message,
                    False
                )

            except Exception as e:

                print(
                    f"Error processing peer_info: {e}"
                )

        # ---------------------------------------------------------
        # Add peer
        # ---------------------------------------------------------

        elif t == "add_peer":

            try:

                data = msg["data"]

                normalized_self = normalize_endpoint(
                    (
                        self.host,
                        self.port
                    )
                )

                normalized_endpoint = normalize_endpoint(
                    (
                        data["host"],
                        data["port"]
                    )
                )

                new_peer_msg_id = str(
                    uuid.uuid4()
                )

                if (
                    normalized_endpoint not in self.known_peers
                    and normalized_endpoint != normalized_self
                ):

                    proposed_name = self.get_unique_name(
                        data["name"]
                    )

                    if proposed_name != data["name"]:

                        pkt = {
                            "type": "change_name",
                            "id": str(uuid.uuid4()),
                            "new_peer_msg_id": new_peer_msg_id,
                            "new_name": proposed_name
                        }

                        await self.send_message(
                            websocket,
                            pkt,
                            False
                        )

                        data["name"] = proposed_name

                    self.known_peers[
                        normalized_endpoint
                    ] = (
                        data["name"],
                        data["public_key"],
                        data["node_id"]
                    )

                    self.name_to_public_key_dict[
                        data["name"].lower()
                    ] = data["public_key"]

                    self.node_id_to_name_dict[
                        data["node_id"]
                    ] = data["name"].lower()

                    self.name_to_node_id_dict[
                        data["name"].lower()
                    ] = data["node_id"]

                    if self.activate_disk_save == "y":
                        self.save_known_peers_to_disk()

                    print(
                        f"Registered peer "
                        f"{data['name']} "
                        f"{data['host']}:{data['port']}"
                    )

                    message = self.get_known_peers_message()

                    await self.send_message(
                        websocket,
                        message,
                        False
                    )

                    pkt = {
                        "type": "new_peer",
                        "id": new_peer_msg_id,
                        "data": {
                            "host": data["host"],
                            "port": data["port"],
                            "name": data["name"],
                            "public_key": data[
                                "public_key"
                            ],
                            "node_id": data["node_id"]
                        }
                    }

                    self.seen_message_ids.add(
                        pkt["id"]
                    )

                    await self.broadcast_message(pkt)

            except Exception as e:

                print(
                    f"Error processing add_peer: {e}"
                )

        # ---------------------------------------------------------
        # New peer
        # ---------------------------------------------------------

        elif t == "new_peer":

            try:

                data = msg["data"]

                normalized_self = normalize_endpoint(
                    (
                        self.host,
                        self.port
                    )
                )

                normalized_endpoint = normalize_endpoint(
                    (
                        data["host"],
                        data["port"]
                    )
                )

                if (
                    normalized_endpoint not in self.known_peers
                    and normalized_endpoint != normalized_self
                ):

                    self.known_peers[
                        normalized_endpoint
                    ] = (
                        data["name"],
                        data["public_key"],
                        data["node_id"]
                    )

                    self.name_to_public_key_dict[
                        data["name"].lower()
                    ] = data["public_key"]

                    self.node_id_to_name_dict[
                        data["node_id"]
                    ] = data["name"].lower()

                    self.name_to_node_id_dict[
                        data["name"].lower()
                    ] = data["node_id"]

                    if self.activate_disk_save == "y":
                        self.save_known_peers_to_disk()

                    print(
                        f"Registered peer "
                        f"{data['name']} "
                        f"{data['host']}:{data['port']}"
                    )

                    await self.broadcast_message(msg)

            except Exception as e:

                print(
                    f"Error processing new_peer: {e}"
                )

        # ---------------------------------------------------------
        # Change name
        # ---------------------------------------------------------

        elif t == "change_name":

            try:

                old_name = self.name.lower()

                self.name_to_node_id_dict.pop(
                    old_name,
                    None
                )

                new_name = str(
                    msg["new_name"]
                ).lower()

                self.name = new_name

                self.name_to_node_id_dict[
                    new_name
                ] = self.node_id

                self.node_id_to_name_dict[
                    self.node_id
                ] = new_name

                self.seen_message_ids.add(
                    msg.get(
                        "new_peer_msg_id",
                        ""
                    )
                )

            except Exception as e:

                print(
                    f"Error processing change_name: {e}"
                )

        # ---------------------------------------------------------
        # Known peers
        # ---------------------------------------------------------

        elif t == "known_peers":

            try:

                peers = msg.get(
                    "peers",
                    []
                )

                new_peer_found = False

                normalized_self = normalize_endpoint(
                    (
                        self.host,
                        self.port
                    )
                )

                for peer in peers:

                    normalized_endpoint = normalize_endpoint(
                        (
                            peer["host"],
                            peer["port"]
                        )
                    )

                    if (
                        normalized_endpoint
                        not in self.known_peers
                        and normalized_endpoint
                        != normalized_self
                    ):

                        print(
                            f"Discovered peer "
                            f"{peer['name']} "
                            f"at "
                            f"{peer['host']}:"
                            f"{peer['port']}"
                        )

                        new_peer_found = True

                        self.known_peers[
                            normalized_endpoint
                        ] = (
                            peer["name"],
                            peer["public_key"],
                            peer["node_id"]
                        )

                        self.name_to_public_key_dict[
                            peer["name"].lower()
                        ] = peer["public_key"]

                        self.node_id_to_name_dict[
                            peer["node_id"]
                        ] = peer["name"].lower()

                        self.name_to_node_id_dict[
                            peer["name"].lower()
                        ] = peer["node_id"]

                if new_peer_found:

                    if self.activate_disk_save == "y":
                        self.save_known_peers_to_disk()

                pkt = {
                    "type": "network_details_request",
                    "id": str(uuid.uuid4())
                }

                self.seen_message_ids.add(
                    pkt["id"]
                )

                await self.send_message(
                    websocket,
                    pkt,
                    True
                )

            except Exception as e:

                print(
                    f"Error processing known_peers: {e}"
                )

        # ---------------------------------------------------------
        # File
        # ---------------------------------------------------------

        elif t == "file":

            try:

                cid = msg["cid"]
                desc = msg["desc"]

                async with self.file_hashes_lock:

                    self.file_hashes[cid] = desc

                await self.broadcast_message(msg)

            except Exception as e:

                print(
                    f"Error processing file message: {e}"
                )

        # ---------------------------------------------------------
        # Network details request
        # ---------------------------------------------------------

        elif t == "network_details_request":

            pkt = {
                "type": "network_details",
                "id": str(uuid.uuid4()),
                "admin": self.admin_id,
                "miners": self.miners
            }

            self.seen_message_ids.add(
                pkt["id"]
            )

            await self.send_message(
                websocket,
                pkt,
                False
            )

        # ---------------------------------------------------------
        # Network details
        # ---------------------------------------------------------

        elif t == "network_details":

            self.admin_id = msg.get(
                "admin"
            )

            self.miners = msg.get(
                "miners",
                []
            )

            pkt = {
                "type": "chain_request",
                "id": str(uuid.uuid4())
            }

            self.seen_message_ids.add(
                pkt["id"]
            )

            await self.send_message(
                websocket,
                pkt,
                True
            )

        # ---------------------------------------------------------
        # New transaction
        # ---------------------------------------------------------

        elif t == "new_tx":

            try:

                tx_str = msg["transaction"]

                tx = json.loads(
                    tx_str
                )

                transaction = Transaction(
                    tx["payload"],
                    tx["sender"],
                    tx["receiver"],
                    tx["id"],
                    tx["timestamp"]
                )

                if Chain.instance is None:
                    print(
                        "Ignoring transaction: "
                        "blockchain not initialized."
                    )
                    return

                if Chain.instance.transaction_exists_in_chain(
                    transaction
                ):

                    print(
                        f"{self.name} "
                        f"Transaction already exists in chain"
                    )

                    return

                sign_bytes = base64.b64decode(
                    msg["sign"]
                )

                if transaction.receiver == "deploy":

                    if not self.valid_deploy_transaction(
                        transaction.payload
                    ):
                        return

                elif transaction.receiver == "invoke":

                    if not self.valid_invoke_transaction(
                        transaction.payload
                    ):
                        return

                if (
                    transaction.receiver == "deploy"
                    or transaction.receiver == "invoke"
                ):

                    amount = transaction.payload[-1]

                else:

                    amount = transaction.payload

                try:
                    amount = float(amount)
                except Exception:
                    print(
                        "Invalid transaction amount"
                    )
                    return

                if amount <= 0:

                    print(
                        "\nInvalid Transaction, amount <= 0\n"
                    )

                    return

                balance = Chain.instance.calc_balance(
                    transaction.sender,
                    self.mem_pool
                )

                if amount > balance:

                    print(
                        "\nAttempt to spend more "
                        "than available balance. "
                        "Invalid transaction.\n"
                    )

                    return

                try:

                    public_key = VerifyingKey.from_pem(
                        tx["sender"].encode()
                    )

                    public_key.verify(
                        sign_bytes,
                        tx_str.encode()
                    )

                except Exception as e:

                    print(
                        f"Invalid Signature: {e}"
                    )

                    return

                transaction.sign = sign_bytes

                print("\nValid Transaction")

                print(
                    f"\n{msg['type']}: "
                    f"{msg['transaction']}"
                )

                print()

                async with self.mem_pool_condition:

                    if not any(
                        existing.id == transaction.id
                        for existing in self.mem_pool
                    ):

                        self.mem_pool.append(
                            transaction
                        )

                await self.broadcast_message(msg)

            except Exception as e:

                print(
                    f"Error processing transaction: {e}"
                )

        # ---------------------------------------------------------
        # New block
        # ---------------------------------------------------------

        elif t == "new_block":

            try:

                if Chain.instance is None:
                    print(
                        "Cannot process block: "
                        "blockchain not initialized."
                    )
                    return

                new_block_dict = msg["block"]

                newBlock = self.block_dict_to_block(
                    new_block_dict
                )

                miners_list = self.get_current_miners_list()

                if not miners_list:

                    print(
                        "Cannot validate block: "
                        "miner list is empty."
                    )

                    return

                miner_index = (
                    len(Chain.instance.chain)
                    + self.round
                ) % len(miners_list)

                reqd_miner_node_id = miners_list[
                    miner_index
                ]

                reqd_miner_public_key = (
                    self.get_public_key_by_node_id(
                        reqd_miner_node_id
                    )
                )

                if not reqd_miner_public_key:

                    print(
                        "Cannot validate block: "
                        "miner public key unavailable."
                    )

                    return

                if not Chain.instance.isValidBlock(
                    newBlock,
                    reqd_miner_node_id,
                    reqd_miner_public_key
                ):

                    print("\nInvalid Block\n")

                    return

                # Validate transactions before appending.
                for transaction in newBlock.transactions:

                    if transaction.receiver == "invoke":

                        if not self.valid_invoke_transaction(
                            transaction.payload
                        ):
                            print(
                                "Invalid invoke transaction "
                                "inside block."
                            )
                            return

                    elif transaction.receiver == "deploy":

                        if not self.valid_deploy_transaction(
                            transaction.payload
                        ):
                            print(
                                "Invalid deploy transaction "
                                "inside block."
                            )
                            return

                # Prevent duplicate block.
                if any(
                    block.id == newBlock.id
                    for block in Chain.instance.chain
                ):
                    return

                Chain.instance.chain.append(
                    newBlock
                )

                print(
                    "\n\nBlock Appended\n\n"
                )

                for transaction in newBlock.transactions:

                    if transaction.receiver == "deploy":

                        try:
                            self.deploy_contract(
                                transaction
                            )
                        except Exception as e:
                            print(
                                f"Contract deployment error: {e}"
                            )

                # Safely remove confirmed transactions.
                async with self.mem_pool_condition:

                    new_mem_pool = [
                        transaction
                        for transaction in self.mem_pool
                        if not newBlock.transaction_exists_in_block(
                            transaction
                        )
                    ]

                    self.mem_pool = new_mem_pool

                async with self.file_hashes_lock:

                    for file_hash in list(
                        self.file_hashes.keys()
                    ):

                        if newBlock.cid_exists_in_block(
                            file_hash
                        ):

                            self.file_hashes.pop(
                                file_hash,
                                None
                            )

                await self.broadcast_message(msg)

                # Reset round timer safely.
                if self.round_task:

                    task = self.round_task

                    if not task.done():
                        task.cancel()

                        try:
                            await task
                        except asyncio.CancelledError:
                            pass

                self.round_task = asyncio.create_task(
                    self.round_calculator()
                )

                # Remove expired miner updates.
                while self.miners:

                    if self.miners[0][1] < len(
                        Chain.instance.chain
                    ):
                        self.miners.pop(0)
                    else:
                        break

                new_miners_list = (
                    self.get_current_miners_list()
                )

                if self.node_id in new_miners_list:

                    await self.update_role(True)

                else:

                    await self.update_role(False)

                if self.activate_disk_save == "y":

                    self.save_chain_to_disk()

            except Exception as e:

                print(
                    f"Error processing new block: {e}"
                )

        # ---------------------------------------------------------
        # Chain request
        # ---------------------------------------------------------

        elif t == "chain_request":

            if Chain.instance is None:
                return

            if not Chain.instance.chain:
                return

            pkt = {
                "type": "chain",
                "id": str(uuid.uuid4()),
                "chain": Chain.instance.to_block_dict_list()
            }

            self.seen_message_ids.add(
                pkt["id"]
            )

            await self.send_message(
                websocket,
                pkt,
                False
            )

        # ---------------------------------------------------------
        # Chain
        # ---------------------------------------------------------

        elif t == "chain":

            try:

                print(
                    "Received a Chain"
                )

                block_dict_list = msg["chain"]

                block_list: List[Block] = []

                for block_dict in block_dict_list:

                    block = self.block_dict_to_block(
                        block_dict
                    )

                    block_list.append(
                        block
                    )

                if not block_list:
                    print(
                        "Received empty chain."
                    )
                    return

                if not isvalidChain(
                    block_list
                ):

                    print(
                        "\nInvalid Chain\n"
                    )

                    return

                # No current chain.
                if Chain.instance is None:

                    self.chain = Chain(
                        blockList=block_list
                    )

                    if self.activate_disk_save == "y":
                        self.save_chain_to_disk()

                # Current chain exists.
                elif (
                    len(Chain.instance.chain)
                    < len(block_list)
                ):

                    Chain.instance.rewrite(
                        block_list
                    )

                    print(
                        "\nCurrent chain replaced "
                        "by longer chain"
                    )

                    if self.activate_disk_save == "y":
                        self.save_chain_to_disk()

                else:

                    print(
                        "\nCurrent Chain is "
                        "same length or longer "
                        "than received chain"
                    )

                    return

                # Remove transactions already
                # included in the new chain.
                async with self.mem_pool_condition:

                    self.mem_pool = [
                        transaction
                        for transaction in self.mem_pool
                        if not Chain.instance.transaction_exists_in_chain(
                            transaction
                        )
                    ]

                async with self.file_hashes_lock:

                    for file_hash in list(
                        self.file_hashes.keys()
                    ):

                        if Chain.instance.cid_exists_in_chain(
                            file_hash
                        ):

                            self.file_hashes.pop(
                                file_hash,
                                None
                            )

            except Exception as e:

                print(
                    f"Error processing chain: {e}"
                )

    # =============================================================
    # CONNECTION HANDLING
    # =============================================================

    async def handle_connections(
        self,
        websocket
    ):

        peer_addr = websocket.remote_address

        self.server_connections.add(
            websocket
        )

        if peer_addr:

            print(
                f"Inbound Connection from "
                f"{peer_addr[0]}:{peer_addr[1]}"
            )

        try:

            async for raw in websocket:

                try:

                    msg = json.loads(raw)

                except json.JSONDecodeError as e:

                    print(
                        f"Invalid JSON received: {e}"
                    )

                    continue

                await self.handle_messages(
                    websocket,
                    msg
                )

        except websockets.exceptions.ConnectionClosed:

            print(
                f"Inbound Connection Closed: "
                f"{peer_addr}"
            )

        except Exception as e:

            print(
                f"Inbound connection error: {e}"
            )

        finally:

            self.discard_server_connection_details(
                websocket
            )

            try:
                await websocket.close()
            except Exception:
                pass

    # =============================================================
    # SEND MESSAGE
    # =============================================================

    async def send_message(
        self,
        websocket,
        message,
        client_connection
    ):

        try:

            await websocket.send(
                json.dumps(message)
            )

        except Exception as e:

            print(
                f"Unexpected error during "
                f"WebSocket send: {e}"
            )

            if client_connection:

                self.discard_client_connection_details(
                    websocket
                )

            else:

                self.discard_server_connection_details(
                    websocket
                )

            try:
                await websocket.close()
            except Exception:
                pass

    # =============================================================
    # BROADCAST
    # =============================================================

    async def broadcast_message(
        self,
        pkt
    ):

        targets = (
            self.server_connections
            | self.client_connections
        )

        for ws in list(targets):

            if ws in self.server_connections:

                await self.send_message(
                    ws,
                    pkt,
                    False
                )

            elif ws in self.client_connections:

                await self.send_message(
                    ws,
                    pkt,
                    True
                )

    # =============================================================
    # TRANSACTIONS
    # =============================================================

    async def create_and_broadcast_tx(
        self,
        receiver_public_key,
        payload
    ):

        transaction = Transaction(
            payload,
            self.wallet.public_key_pem,
            receiver_public_key
        )

        transaction_str = str(
            transaction
        )

        signature = self.wallet.private_key.sign(
            transaction_str.encode()
        )

        signature_b64 = base64.b64encode(
            signature
        ).decode()

        pkt = {
            "type": "new_tx",
            "id": str(uuid.uuid4()),
            "transaction": transaction_str,
            "sign": signature_b64,
            "sender_pem": self.wallet.public_key_pem
        }

        self.seen_message_ids.add(
            pkt["id"]
        )

        if Chain.instance is not None:

            if Chain.instance.transaction_exists_in_chain(
                transaction
            ):
                return

        transaction.sign = signature

        async with self.mem_pool_condition:

            if not any(
                existing.id == transaction.id
                for existing in self.mem_pool
            ):

                self.mem_pool.append(
                    transaction
                )

        print(
            "Transaction Created",
            transaction
        )

        print()

        await self.broadcast_message(
            pkt
        )

    # =============================================================
    # CONTRACT STATE
    # =============================================================

    def get_contract_state(
        self,
        contract_id
    ):

        if Chain.instance is None:
            return {}

        for block in reversed(
            Chain.instance.chain
        ):

            for transaction in reversed(
                block.transactions
            ):

                if (
                    transaction.receiver == "invoke"
                    and transaction.payload[0]
                    == contract_id
                ):

                    return transaction.payload[3]

        return {}

    # =============================================================
    # USER INPUT
    # =============================================================

    async def user_input_handler(self):

        loop = asyncio.get_running_loop()

        while True:

            try:

                print(
                    "Block Chain Menu\n"
                    "***************"
                )

                menu = (
                    "1) Add Transaction\n"
                    "2) View balance\n"
                    "3) Print Chain\n"
                    "4) Print Pending Transactions\n"
                    "5) Send Files\n"
                    "6) Download Files\n"
                )

                if self.node_id == self.admin_id:

                    menu += (
                        "7) View Miners\n"
                        "8) Add Miner\n"
                        "9) Remove Miner\n"
                    )

                menu += "0) Quit"

                print(menu)

                ch = await loop.run_in_executor(
                    None,
                    input,
                    "Enter Your Choice: "
                )

                try:
                    ch = int(ch)
                except ValueError:

                    print(
                        "\nPlease enter a valid number!!!\n"
                    )

                    continue

                # -------------------------------------------------
                # ADD TRANSACTION
                # -------------------------------------------------

                if ch == 1:

                    if Chain.instance is None:

                        print(
                            "Blockchain is not initialized."
                        )

                        continue

                    rec = await loop.run_in_executor(
                        None,
                        input,
                        "\nEnter Receiver's Name or Public Key: "
                    )

                    rec = rec.strip()

                    # -------------------------------------------------
                    # DEPLOY
                    # -------------------------------------------------

                    if rec.lower() == "deploy":

                        contract_code = (
                            get_contract_code_from_notepad()
                        )

                        if not contract_code.strip():

                            print(
                                "Contract code field is empty"
                            )

                            continue

                        gas_used = (
                            len(contract_code) // 10
                            + BASE_DEPLOY_COST
                        )

                        amount = (
                            gas_used * GAS_PRICE
                        )

                        payload = [
                            contract_code,
                            amount
                        ]

                        balance = (
                            Chain.instance.calc_balance(
                                self.wallet.public_key_pem,
                                self.mem_pool
                            )
                        )

                        if amount <= balance:

                            await self.create_and_broadcast_tx(
                                "deploy",
                                payload
                            )

                        else:

                            print(
                                "Insufficient Account Balance"
                            )

                    # -------------------------------------------------
                    # INVOKE
                    # -------------------------------------------------

                    elif rec.lower() == "invoke":

                        contract_id = await loop.run_in_executor(
                            None,
                            input,
                            "\nEnter Contract Id: "
                        )

                        contract_id = contract_id.strip()

                        if (
                            contract_id
                            not in self.contractsDB.contracts
                        ):

                            print(
                                "No such contract found..."
                            )

                            continue

                        func_name = await loop.run_in_executor(
                            None,
                            input,
                            "\nEnter Function Name: "
                        )

                        func_name = func_name.strip()

                        args = []

                        arg_number = 1

                        while True:

                            arg = await loop.run_in_executor(
                                None,
                                input,
                                f"Enter argument "
                                f"{arg_number} "
                                f"(or \\q to finish): "
                            )

                            if arg.strip() == "\\q":
                                break

                            try:

                                parsed_arg = ast.literal_eval(
                                    arg
                                )

                            except Exception:

                                parsed_arg = arg

                            args.append(
                                parsed_arg
                            )

                            arg_number += 1

                        try:

                            response = self.run_contract(
                                [
                                    contract_id,
                                    func_name,
                                    args
                                ]
                            )

                        except Exception as e:

                            print(
                                f"Contract execution error: {e}"
                            )

                            continue

                        if response.get("error") is not None:

                            print(
                                "Error:",
                                response["error"]
                            )

                            continue

                        state = response["state"]

                        gas_used = response["gas_used"]

                        amount = (
                            gas_used * GAS_PRICE
                        )

                        payload = [
                            contract_id,
                            func_name,
                            args,
                            state,
                            amount
                        ]

                        balance = (
                            Chain.instance.calc_balance(
                                self.wallet.public_key_pem,
                                self.mem_pool
                            )
                        )

                        if amount <= balance:

                            await self.create_and_broadcast_tx(
                                "invoke",
                                payload
                            )

                        else:

                            print(
                                "Insufficient Account Balance"
                            )

                    # -------------------------------------------------
                    # NORMAL TRANSFER
                    # -------------------------------------------------

                    else:

                        amt = await loop.run_in_executor(
                            None,
                            input,
                            "\nEnter Amount to send: "
                        )

                        receiver_public_key = (
                            self.name_to_public_key_dict.get(
                                rec.lower()
                            )
                        )

                        if receiver_public_key is None:

                            rec_refined = rec.replace(
                                "\\n",
                                "\n"
                            )

                            for (
                                nme,
                                pk
                            ) in self.name_to_public_key_dict.items():

                                if pk == rec_refined:

                                    receiver_public_key = pk

                                    break

                        if receiver_public_key is None:

                            print(
                                "No person available in "
                                "directory with provided "
                                "name or public key..."
                            )

                            continue

                        try:

                            amt = float(amt)

                        except ValueError:

                            print(
                                "Amount must be a number"
                            )

                            continue

                        if amt <= 0:

                            print(
                                "\nAmount must be positive\n"
                            )

                            continue

                        balance = (
                            Chain.instance.calc_balance(
                                self.wallet.public_key_pem,
                                self.mem_pool
                            )
                        )

                        if amt <= balance:

                            await self.create_and_broadcast_tx(
                                receiver_public_key,
                                amt
                            )

                        else:

                            print(
                                "Insufficient Account Balance"
                            )

                # -------------------------------------------------
                # BALANCE
                # -------------------------------------------------

                elif ch == 2:

                    if Chain.instance is None:

                        print(
                            "Blockchain is not initialized."
                        )

                        continue

                    print(
                        "Account Balance =",
                        Chain.instance.calc_balance(
                            self.wallet.public_key_pem,
                            self.mem_pool
                        )
                    )

                # -------------------------------------------------
                # PRINT CHAIN
                # -------------------------------------------------

                elif ch == 3:

                    if Chain.instance is None:

                        print(
                            "Blockchain is not initialized."
                        )

                        continue

                    for i, block in enumerate(
                        Chain.instance.chain
                    ):

                        print(
                            f"block{i}: "
                            f"{block}\n"
                        )

                # -------------------------------------------------
                # PENDING TRANSACTIONS
                # -------------------------------------------------

                elif ch == 4:

                    for i, transaction in enumerate(
                        self.mem_pool
                    ):

                        print(
                            f"transaction{i}: "
                            f"{transaction}\n\n"
                        )

                # -------------------------------------------------
                # SEND FILE
                # -------------------------------------------------

                elif ch == 5:

                    desc = await loop.run_in_executor(
                        None,
                        input,
                        "\nEnter description of file: "
                    )

                    path = await loop.run_in_executor(
                        None,
                        input,
                        "\nEnter path of file: "
                    )

                    pkt = await self.uploadFile(
                        desc,
                        path
                    )

                    if pkt:

                        await self.broadcast_message(
                            pkt
                        )

                # -------------------------------------------------
                # DOWNLOAD FILE
                # -------------------------------------------------

                elif ch == 6:

                    cid = await loop.run_in_executor(
                        None,
                        input,
                        "\nEnter cid of file: "
                    )

                    path = await loop.run_in_executor(
                        None,
                        input,
                        "\nEnter path to download the file: "
                    )

                    try:

                        download_ipfs_file_subprocess(
                            cid,
                            path
                        )

                    except Exception as e:

                        print(
                            f"File download error: {e}"
                        )

                # -------------------------------------------------
                # VIEW MINERS
                # -------------------------------------------------

                elif ch == 7:

                    if self.node_id != self.admin_id:

                        print(
                            "Only the admin can view miners."
                        )

                        continue

                    if Chain.instance is None:

                        print(
                            "Blockchain is not initialized."
                        )

                        continue

                    current_miners = (
                        Chain.instance.chain[-1].miners_list
                    )

                    miner_names = []

                    for miner in current_miners:

                        miner_name = (
                            self.node_id_to_name_dict.get(
                                miner,
                                miner
                            )
                        )

                        miner_names.append(
                            miner_name
                        )

                    print(
                        "Current miners"
                    )

                    print(
                        miner_names
                    )

                    for miner_item in self.miners:

                        miner_names = []

                        for miner in miner_item[0]:

                            miner_name = (
                                self.node_id_to_name_dict.get(
                                    miner,
                                    miner
                                )
                            )

                            miner_names.append(
                                miner_name
                            )

                        print(
                            f"Miners to be activated "
                            f"from block "
                            f"{miner_item[1]}"
                        )

                        print(
                            miner_names
                        )

                # -------------------------------------------------
                # ADD MINER
                # -------------------------------------------------

                elif ch == 8:

                    if self.node_id != self.admin_id:

                        print(
                            "Only the admin can add miners."
                        )

                        continue

                    miner_name = await loop.run_in_executor(
                        None,
                        input,
                        "\nEnter Miner's Name: "
                    )

                    miner_name = miner_name.strip().lower()

                    miner_node_id = (
                        self.name_to_node_id_dict.get(
                            miner_name
                        )
                    )

                    if miner_node_id is None:

                        print(
                            "Miner not found."
                        )

                        continue

                    if Chain.instance is None:

                        print(
                            "Blockchain is not initialized."
                        )

                        continue

                    if self.miners:

                        miners_list = copy.deepcopy(
                            self.miners[-1][0]
                        )

                    else:

                        miners_list = copy.deepcopy(
                            Chain.instance.chain[-1].miners_list
                        )

                    if miner_node_id not in miners_list:

                        miners_list.append(
                            miner_node_id
                        )

                        activation_block = (
                            len(
                                Chain.instance.chain
                            ) + 3
                        )

                        self.miners.append(
                            [
                                miners_list,
                                activation_block
                            ]
                        )

                        await self.broadcast_miners_list(
                            miners_list,
                            activation_block
                        )

                    else:

                        print(
                            f"{miner_name} "
                            f"is already in miners list"
                        )

                # -------------------------------------------------
                # REMOVE MINER
                # -------------------------------------------------

                elif ch == 9:

                    if self.node_id != self.admin_id:

                        print(
                            "Only the admin can remove miners."
                        )

                        continue

                    miner_name = await loop.run_in_executor(
                        None,
                        input,
                        "\nEnter Miner's Name: "
                    )

                    miner_name = miner_name.strip().lower()

                    miner_node_id = (
                        self.name_to_node_id_dict.get(
                            miner_name
                        )
                    )

                    if miner_node_id is None:

                        print(
                            "Miner not found."
                        )

                        continue

                    if Chain.instance is None:

                        print(
                            "Blockchain is not initialized."
                        )

                        continue

                    if self.miners:

                        miners_list = copy.deepcopy(
                            self.miners[-1][0]
                        )

                    else:

                        miners_list = copy.deepcopy(
                            Chain.instance.chain[-1].miners_list
                        )

                    if miner_node_id in miners_list:

                        # Do not allow an empty miner set.
                        if len(miners_list) <= 1:

                            print(
                                "Cannot remove the last miner."
                            )

                            continue

                        miners_list.remove(
                            miner_node_id
                        )

                        activation_block = (
                            len(
                                Chain.instance.chain
                            ) + 3
                        )

                        self.miners.append(
                            [
                                miners_list,
                                activation_block
                            ]
                        )

                        await self.broadcast_miners_list(
                            miners_list,
                            activation_block
                        )

                    else:

                        print(
                            f"{miner_name} "
                            f"is already not in miners list"
                        )

                # -------------------------------------------------
                # QUIT
                # -------------------------------------------------

                elif ch == 0:

                    print(
                        "Quitting..."
                    )

                    break

                else:

                    print(
                        "Invalid choice."
                    )

            except EOFError:

                print(
                    "Input stream closed. "
                    "Stopping user input handler."
                )

                break

            except Exception as e:

                print(
                    f"Menu error: {e}"
                )

    # =============================================================
    # CONNECT TO PEER
    # =============================================================

    async def connect_to_peer(
        self,
        host,
        port
    ):

        endpoint = (
            host,
            int(port)
        )

        if (
            endpoint in self.outbound_peers
            or endpoint == (self.host, self.port)
        ):
            return

        uri = f"ws://{host}:{port}"

        websocket = None

        try:

            websocket = await websockets.connect(
                uri
            )

            self.client_connections.add(
                websocket
            )

            self.outbound_peers.add(
                endpoint
            )

            self.have_sent_peer_info[
                websocket
            ] = False

            print(
                f"Outbound connection formed "
                f"to {host}:{port}"
            )

            if Chain.instance is None:

                pkt = {
                    "type": "add_peer",
                    "id": str(uuid.uuid4()),
                    "data": {
                        "host": self.host,
                        "port": self.port,
                        "name": self.name,
                        "public_key": self.wallet.public_key_pem,
                        "node_id": self.node_id
                    }
                }

            else:

                pkt = {
                    "type": "ping",
                    "id": str(uuid.uuid4())
                }

            self.seen_message_ids.add(
                pkt["id"]
            )

            await self.send_message(
                websocket,
                pkt,
                True
            )

            async for raw in websocket:

                try:

                    msg = json.loads(raw)

                except json.JSONDecodeError as e:

                    print(
                        f"Invalid JSON received "
                        f"from {host}:{port}: {e}"
                    )

                    continue

                await self.handle_messages(
                    websocket,
                    msg
                )

        except asyncio.CancelledError:

            raise

        except Exception as e:

            print(
                f"Failed to connect to "
                f"{host}:{port} ::: {e}"
            )

        finally:

            if websocket is not None:

                self.discard_client_connection_details(
                    websocket
                )

                try:
                    await websocket.close()
                except Exception:
                    pass

    # =============================================================
    # PEER DISCOVERY
    # =============================================================

    async def discover_peers(self):

        while True:

            try:

                if len(self.outbound_peers) < MAX_CONNECTIONS:

                    potential_peers = {
                        endpoint
                        for endpoint in self.known_peers
                        if (
                            endpoint
                            not in self.outbound_peers
                            and endpoint
                            != (self.host, self.port)
                        )
                    }

                    while (
                        len(self.outbound_peers)
                        < MAX_CONNECTIONS
                        and potential_peers
                    ):

                        new_peer = get_random_element(
                            potential_peers
                        )

                        potential_peers.discard(
                            new_peer
                        )

                        if new_peer:

                            asyncio.create_task(
                                self.connect_to_peer(
                                    *new_peer
                                )
                            )

                            await asyncio.sleep(1)

                for _ in range(6):

                    await asyncio.sleep(5)

            except asyncio.CancelledError:

                raise

            except Exception as e:

                print(
                    f"Peer discovery error: {e}"
                )

                await asyncio.sleep(5)

    # =============================================================
    # GOSSIP PEER SAMPLER
    # =============================================================

    async def gossip_peer_sampler(self):

        while True:

            try:

                for _ in range(12):

                    await asyncio.sleep(5)

                if (
                    len(self.known_peers)
                    <= len(self.outbound_peers)
                    or len(self.outbound_peers)
                    < MAX_CONNECTIONS
                ):

                    continue

                to_drop = get_random_element(
                    self.client_connections
                )

                if to_drop:

                    try:

                        print(
                            "Gossip Sampling: "
                            f"Disconnecting "
                            f"{to_drop.remote_address}"
                        )

                    except Exception:
                        pass

                    self.discard_client_connection_details(
                        to_drop
                    )

                    try:
                        await to_drop.close()
                    except Exception:
                        pass

                potential_peers = {
                    endpoint
                    for endpoint in self.known_peers
                    if (
                        endpoint
                        not in self.outbound_peers
                        and endpoint
                        != (self.host, self.port)
                    )
                }

                if potential_peers:

                    new_peer = get_random_element(
                        potential_peers
                    )

                    if new_peer:

                        print(
                            "Gossip Sampling: "
                            f"Connecting to new peer "
                            f"{new_peer}"
                        )

                        asyncio.create_task(
                            self.connect_to_peer(
                                *new_peer
                            )
                        )

            except asyncio.CancelledError:

                raise

            except Exception as e:

                print(
                    f"Gossip sampler error: {e}"
                )

                await asyncio.sleep(5)

    # =============================================================
    # IPFS UPLOAD
    # =============================================================

    async def uploadFile(
        self,
        desc: str,
        path: str
    ):

        file_path = Path(
            path
        )

        if not file_path.is_file():

            print(
                "\nFile doesn't exist\n"
            )

            return None

        if not self.daemon_process:

            try:

                self.start_daemon()

            except Exception as e:

                print(
                    f"Failed to start IPFS daemon: {e}"
                )

                return None

        try:

            cid, name = await asyncio.to_thread(
                addToIpfs,
                path
            )

        except Exception as e:

            print(
                f"IPFS upload error: {e}"
            )

            return None

        if not cid or not name:
            return None

        print(
            f"\nNew File Created : {cid}\n"
        )

        pkt = {
            "type": "file",
            "id": str(uuid.uuid4()),
            "desc": desc,
            "cid": cid
        }

        self.seen_message_ids.add(
            pkt["id"]
        )

        async with self.file_hashes_lock:

            self.file_hashes[cid] = desc

        return pkt

    # =============================================================
    # IPFS INITIALIZATION
    # =============================================================

    def init_repo(self):

        if not self.repo_path.exists():

            subprocess.run(
                ["ipfs", "init"],
                env=self.env,
                check=True
            )

            print(
                "\nIPFS repo created\n"
            )

        else:

            print(
                "\nIPFS repo already exists\n"
            )

    def configure_ports(self):

        subprocess.run(
            [
                "ipfs",
                "config",
                "Addresses.API",
                f"/ip4/127.0.0.1/tcp/{self.ipfs_port}"
            ],
            env=self.env,
            check=True
        )

        subprocess.run(
            [
                "ipfs",
                "config",
                "Addresses.Gateway",
                f"/ip4/127.0.0.1/tcp/{self.gateway_port}"
            ],
            env=self.env,
            check=True
        )

        subprocess.run(
            [
                "ipfs",
                "config",
                "Addresses.Swarm",
                "--json",
                json.dumps(
                    [
                        f"/ip4/127.0.0.1/tcp/{self.swarm_tcp}",
                        f"/ip4/127.0.0.1/udp/{self.swarm_udp}/quic"
                    ]
                )
            ],
            env=self.env,
            check=True
        )

        print(
            "\nConfigured Ports\n"
        )

    def start_daemon(self):

        if self.daemon_process is not None:

            if self.daemon_process.poll() is None:
                return

        self.daemon_process = subprocess.Popen(
            ["ipfs", "daemon"],
            env=self.env
        )

        print(
            "\nIPFS Daemon Started\n"
        )

    def stop_daemon(self):

        if self.daemon_process:

            try:

                if self.daemon_process.poll() is None:

                    self.daemon_process.terminate()

                    try:

                        self.daemon_process.wait(
                            timeout=10
                        )

                    except subprocess.TimeoutExpired:

                        self.daemon_process.kill()

                        self.daemon_process.wait()

            except Exception as e:

                print(
                    f"Error stopping IPFS daemon: {e}"
                )

            finally:

                self.daemon_process = None

    # =============================================================
    # BLOCK SIGNING
    # =============================================================

    def sign_block(
        self,
        block: Block
    ):

        message = block.get_message_to_sign()

        signature = self.wallet.private_key.sign(
            message
        )

        block.signature = signature.hex()

    # =============================================================
    # MINING
    # =============================================================

    async def mine_blocks(self):

        try:

            while True:

                for _ in range(6):

                    await asyncio.sleep(5)

                if Chain.instance is None:
                    continue

                miners_list = (
                    self.get_current_miners_list()
                )

                if not miners_list:
                    continue

                miner_index = (
                    len(Chain.instance.chain)
                    + self.round
                ) % len(miners_list)

                reqd_miner_node_id = (
                    miners_list[miner_index]
                )

                if self.node_id != reqd_miner_node_id:
                    continue

                if self.round != 0:

                    for _ in range(3):

                        await asyncio.sleep(5)

                async with self.mem_pool_condition:

                    if len(self.mem_pool) == 0:
                        continue

                    transaction_list = []

                    # Do NOT remove items from self.mem_pool
                    # while iterating over it.
                    for transaction in self.mem_pool:

                        if Chain.instance.transaction_exists_in_chain(
                            transaction
                        ):

                            continue

                        transaction_list.append(
                            transaction
                        )

                    if not transaction_list:
                        continue

                    print(
                        "Mining Started"
                    )

                    print(
                        "Mining..."
                    )

                    newBlock = Block(
                        Chain.instance.lastBlock.hash,
                        transaction_list
                    )

                    newBlock.miner_node_id = (
                        self.node_id
                    )

                    newBlock.miner_public_key = (
                        self.wallet.public_key_pem
                    )

                    newBlock.miners_list = (
                        miners_list
                    )

                    async with self.file_hashes_lock:

                        newBlock.files = (
                            self.file_hashes.copy()
                        )

                    self.sign_block(
                        newBlock
                    )

                    reqd_miner_public_key = (
                        self.wallet.public_key_pem
                    )

                    if not Chain.instance.isValidBlock(
                        newBlock,
                        reqd_miner_node_id,
                        reqd_miner_public_key
                    ):

                        print(
                            "\nInvalid Block\n"
                        )

                        continue

                    Chain.instance.chain.append(
                        newBlock
                    )

                    print(
                        "\nBlock Appended\n"
                    )

                    # Deploy contracts.
                    for transaction in newBlock.transactions:

                        if transaction.receiver == "deploy":

                            try:

                                self.deploy_contract(
                                    transaction
                                )

                            except Exception as e:

                                print(
                                    f"Contract deployment "
                                    f"error: {e}"
                                )

                    # Remove included transactions.
                    self.mem_pool = [
                        transaction
                        for transaction in self.mem_pool
                        if not newBlock.transaction_exists_in_block(
                            transaction
                        )
                    ]

                    async with self.file_hashes_lock:

                        for file_hash in list(
                            self.file_hashes.keys()
                        ):

                            if newBlock.cid_exists_in_block(
                                file_hash
                            ):

                                self.file_hashes.pop(
                                    file_hash,
                                    None
                                )

                    pkt = {
                        "type": "new_block",
                        "id": str(uuid.uuid4()),
                        "block": newBlock.to_dict()
                    }

                    self.seen_message_ids.add(
                        pkt["id"]
                    )

                    await self.broadcast_message(
                        pkt
                    )

                # -------------------------------------------------
                # Restart round calculator
                # -------------------------------------------------

                if self.round_task:

                    task = self.round_task

                    if not task.done():

                        task.cancel()

                        try:
                            await task
                        except asyncio.CancelledError:
                            pass

                self.round_task = asyncio.create_task(
                    self.round_calculator()
                )

                # -------------------------------------------------
                # Apply miner updates
                # -------------------------------------------------

                while self.miners:

                    if (
                        self.miners[0][1]
                        < len(Chain.instance.chain)
                    ):

                        self.miners.pop(0)

                    else:

                        break

                new_miners_list = (
                    self.get_current_miners_list()
                )

                if self.node_id in new_miners_list:

                    await self.update_role(True)

                else:

                    await self.update_role(False)

                if self.activate_disk_save == "y":

                    self.save_chain_to_disk()

        except asyncio.CancelledError:

            print(
                "Miner task stopped cleanly"
            )

            raise

        except Exception as e:

            print(
                f"Mining task crashed: {e}"
            )

            raise

    # =============================================================
    # LONGEST CHAIN
    # =============================================================

    async def find_longest_chain(self):

        try:

            while True:

                pkt = {
                    "type": "chain_request",
                    "id": str(uuid.uuid4())
                }

                self.seen_message_ids.add(
                    pkt["id"]
                )

                await self.broadcast_message(
                    pkt
                )

                print(
                    "\nSent out chain requests..."
                )

                for _ in range(12):

                    await asyncio.sleep(5)

        except asyncio.CancelledError:

            raise

    # =============================================================
    # SMART CONTRACT ID
    # =============================================================

    def calculate_contract_id(
        self,
        sender,
        timestamp
    ):

        data = f"{sender}:{timestamp}"

        hash_object = hashlib.sha256(
            data.encode("utf-8")
        )

        return hash_object.hexdigest()

    # =============================================================
    # DEPLOY CONTRACT
    # =============================================================

    def deploy_contract(
        self,
        transaction
    ):

        sender = transaction.sender
        timestamp = transaction.ts
        code = transaction.payload[0]

        contract_id = self.calculate_contract_id(
            sender,
            timestamp
        )

        self.contractsDB.store_contract(
            contract_id,
            code
        )

        print(
            "Contract deployed with id:",
            contract_id
        )

    # =============================================================
    # RUN CONTRACT
    # =============================================================

    def run_contract(
        self,
        payload
    ):

        if len(payload) < 3:

            raise ValueError(
                "Invalid contract payload."
            )

        contract_id = payload[0]
        func_name = payload[1]
        args = payload[2]

        code = self.contractsDB.get_contract(
            contract_id
        )

        if code is None:

            raise Exception(
                f"Contract '{contract_id}' not found."
            )

        state = self.get_contract_state(
            contract_id
        )

        executor = SecureContractExecutor(
            code
        )

        response = executor.run(
            func_name,
            args,
            state
        )

        return response

    # =============================================================
    # START PEER
    # =============================================================

    async def start(
        self,
        bootstrap_host=None,
        bootstrap_port=None,
        web_mode=False
    ):

        # ---------------------------------------------------------
        # Start WebSocket server
        # ---------------------------------------------------------

        server = await websockets.serve(
            self.handle_connections,
            self.host,
            self.port
        )

        print(
            f"WebSocket server started on "
            f"{self.host}:{self.port}"
        )

        # ---------------------------------------------------------
        # Initialize blockchain / bootstrap
        # ---------------------------------------------------------

        if bootstrap_host and bootstrap_port:

            normalized_bootstrap_host, normalized_bootstrap_port = (
                normalize_endpoint(
                    (
                        bootstrap_host,
                        bootstrap_port
                    )
                )
            )

            asyncio.create_task(
                self.connect_to_peer(
                    normalized_bootstrap_host,
                    normalized_bootstrap_port
                )
            )

        else:

            self.chain = Chain(
                publicKey=self.wallet.public_key_pem
            )

            if not Chain.instance.chain:

                raise RuntimeError(
                    "Genesis block was not created."
                )

            genesis = (
                Chain.instance.chain[0]
            )

            genesis.miner_node_id = (
                self.node_id
            )

            genesis.miner_public_key = (
                self.wallet.public_key_pem
            )

            genesis.miners_list = [
                self.node_id
            ]

            self.sign_block(
                genesis
            )

            self.admin_id = (
                self.node_id
            )

            await self.update_role(
                True
            )

        # ---------------------------------------------------------
        # Start background tasks
        # ---------------------------------------------------------

        inp_task = None if web_mode else asyncio.create_task(
            self.user_input_handler()
        )

        consensus_task = asyncio.create_task(
            self.find_longest_chain()
        )

        disc_task = asyncio.create_task(
            self.discover_peers()
        )

        sampler_task = asyncio.create_task(
            self.gossip_peer_sampler()
        )

        self.round_task = asyncio.create_task(
            self.round_calculator()
        )

        # ---------------------------------------------------------
        # IPFS
        # ---------------------------------------------------------

        try:

            self.init_repo()

            self.configure_ports()

        except Exception as e:

            print(
                f"IPFS initialization failed: {e}"
            )

        # ---------------------------------------------------------
        # Wait for user to quit
        # ---------------------------------------------------------

        try:

            if inp_task is not None:
                await inp_task
            else:
                await asyncio.Event().wait()

        finally:

            # -----------------------------------------------------
            # Cancel background tasks
            # -----------------------------------------------------

            tasks_to_cancel = [
                consensus_task,
                disc_task,
                sampler_task
            ]

            if self.round_task:

                tasks_to_cancel.append(
                    self.round_task
                )

            for task in tasks_to_cancel:

                if not task.done():

                    task.cancel()

            for task in tasks_to_cancel:

                try:
                    await task
                except asyncio.CancelledError:
                    pass
                except Exception as e:

                    print(
                        f"Background task stopped "
                        f"with error: {e}"
                    )

            # -----------------------------------------------------
            # Stop miner
            # -----------------------------------------------------

            await self.update_role(
                False
            )

            # -----------------------------------------------------
            # Stop IPFS
            # -----------------------------------------------------

            if self.daemon_process:

                self.stop_daemon()

            # -----------------------------------------------------
            # Close connections
            # -----------------------------------------------------

            all_connections = (
                list(self.server_connections)
                + list(self.client_connections)
            )

            for ws in all_connections:

                try:
                    await ws.close()
                except Exception:
                    pass

            # -----------------------------------------------------
            # Close server
            # -----------------------------------------------------

            try:

                server.close()

                await server.wait_closed()

            except Exception as e:

                print(
                    f"Error closing WebSocket server: {e}"
                )