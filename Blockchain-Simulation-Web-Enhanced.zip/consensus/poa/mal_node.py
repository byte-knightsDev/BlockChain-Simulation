import asyncio
import websockets
import json
import uuid
import base64
from typing import Set, Dict, List, Tuple, Any
import copy
import socket
from consensus.poa.blockchain_structures import (
    Transaction,
    Block,
    Wallet,
    Chain,
    isvalidChain
)
from ipfs.ipfs import addToIpfs, download_ipfs_file_subprocess
from smart_contract.contracts_db import SmartContractDatabase
from smart_contract.secure_executor import SecureContractExecutor
from storage.storage_manager import (
    save_node_id,
    load_node_id,
    save_key,
    load_key,
    save_chain,
    load_chain,
    save_peers,
    load_peers
)
from ecdsa import VerifyingKey
import binascii
import os
import tempfile
import subprocess
import hashlib
import ast
import math
from pathlib import Path


MAX_CONNECTIONS = 8
GAS_PRICE = 0.001
BASE_DEPLOY_COST = 5
CONSENSUS = "poa"


# ============================================================
# Utility functions
# ============================================================

def get_random_element(s):
    import random
    return random.choice(list(s)) if s else None


def normalize_endpoint(ep):
    host, port = ep
    return socket.gethostbyname(host), int(port)


def public_key_to_pem(public_key):
    """
    Converts an ECDSA VerifyingKey to PEM string.

    This is important because VerifyingKey objects cannot be
    serialized by json.dumps().
    """
    if public_key is None:
        return None

    if isinstance(public_key, VerifyingKey):
        return public_key.to_pem().decode("utf-8")

    if isinstance(public_key, bytes):
        try:
            return public_key.decode("utf-8")
        except UnicodeDecodeError:
            return None

    return str(public_key)


def get_transaction_timestamp(transaction_dict):
    """
    Supports both old and new saved transaction formats.

    Older files may contain:
        "timestamp": ...

    Current Transaction.to_dict() may contain:
        "ts": ...
    """
    if "ts" in transaction_dict:
        return transaction_dict["ts"]

    if "timestamp" in transaction_dict:
        return transaction_dict["timestamp"]

    return None


def get_transaction_signature(transaction_dict):
    """
    Supports the normal 'sign' field and protects against
    missing signatures in malformed/legacy data.
    """
    sign = transaction_dict.get("sign")

    if sign is None:
        return None

    if isinstance(sign, bytes):
        return sign

    try:
        return base64.b64decode(sign, validate=True)
    except Exception:
        return None


def get_contract_code_from_notepad():
    temp_filename = None

    try:
        with tempfile.NamedTemporaryFile(
            suffix=".py",
            delete=False,
            mode="w+",
            encoding="utf-8"
        ) as tmp_file:

            temp_filename = tmp_file.name

            tmp_file.write(
                "# Write your smart contract function here.\n"
            )
            tmp_file.write(
                "def contract_logic(parameter1, parameter2, parameter3, state):\n"
            )
            tmp_file.write(
                "    # your code here\n"
            )
            tmp_file.write(
                "    return state, 'some message'\n"
            )

        subprocess.call(["notepad.exe", temp_filename])

        with open(temp_filename, "r", encoding="utf-8") as f:
            return f.read()

    finally:
        if temp_filename and os.path.exists(temp_filename):
            try:
                os.remove(temp_filename)
            except OSError:
                pass


# ============================================================
# Peer
# ============================================================

class Peer:

    def __init__(
        self,
        host,
        port,
        name,
        activate_disk_load,
        activate_disk_save
    ):

        self.host = host
        self.port = int(port)
        self.name = name

        self.activate_disk_save = activate_disk_save

        # ----------------------------------------------------
        # IPFS ports
        # ----------------------------------------------------

        self.ipfs_port = self.port + 50
        self.gateway_port = self.port + 81
        self.swarm_tcp = self.port + 2
        self.swarm_udp = self.port + 3

        self.repo_path = Path.home() / f".ipfs_{self.port}"

        self.env = os.environ.copy()
        self.env["IPFS_PATH"] = str(self.repo_path)

        # ----------------------------------------------------
        # Consensus state
        # ----------------------------------------------------

        self.miner = False
        self.miner_task = None

        self.round = 0
        self.round_task = None

        self.admin_id = None

        self.miners: List[list] = []

        # ----------------------------------------------------
        # Node ID
        # ----------------------------------------------------

        if activate_disk_load == "y":
            self.load_node_id_from_disk()
        else:
            self.node_id = None

        if not self.node_id:
            self.node_id = str(uuid.uuid4())

            if self.activate_disk_save == "y":
                self.save_node_id_to_disk()

        # ----------------------------------------------------
        # Connections
        # ----------------------------------------------------

        self.server_connections: Set[Any] = set()
        self.client_connections: Set[Any] = set()

        self.outbound_peers: Set[tuple] = set()

        # Prevent duplicate simultaneous connection attempts.
        self.connecting_peers: Set[tuple] = set()

        self.seen_message_ids: Set[str] = set()

        self.got_pong: Dict[Any, bool] = {}

        self.have_sent_peer_info: Dict[Any, bool] = {}

        # ----------------------------------------------------
        # Known peers
        # ----------------------------------------------------

        if activate_disk_load == "y":
            self.load_known_peers_from_disk()
        else:
            self.known_peers = None

        if not self.known_peers:
            self.known_peers: Dict[
                Tuple[str, int],
                Tuple[str, str, str]
            ] = {}

        # ----------------------------------------------------
        # Wallet
        # ----------------------------------------------------

        if activate_disk_load == "y":
            self.load_key_from_disk()
        else:
            self.wallet = None

        if not self.wallet:
            self.wallet = Wallet()

            if self.activate_disk_save == "y":
                self.save_key_to_disk()

        # ----------------------------------------------------
        # Chain
        # ----------------------------------------------------

        if activate_disk_load == "y":
            self.load_chain_from_disk()
        else:
            self.chain = None

        # ----------------------------------------------------
        # Smart contracts
        # ----------------------------------------------------

        self.contractsDB = SmartContractDatabase()

        # ----------------------------------------------------
        # Mempool
        # ----------------------------------------------------

        self.mem_pool: List[Transaction] = []

        self.mem_pool_condition = asyncio.Condition()

        # ----------------------------------------------------
        # Files
        # ----------------------------------------------------

        self.file_hashes: Dict[str, str] = {}
        self.file_hashes_lock = asyncio.Lock()

        # ----------------------------------------------------
        # Peer dictionaries
        # ----------------------------------------------------

        self.name_to_public_key_dict: Dict[str, str] = {}
        self.node_id_to_name_dict: Dict[str, str] = {}
        self.name_to_node_id_dict: Dict[str, str] = {}

        # ----------------------------------------------------
        # Chain lock
        # ----------------------------------------------------

        self.chain_lock = asyncio.Lock()

        # ----------------------------------------------------
        # IPFS
        # ----------------------------------------------------

        self.daemon_process = None

        # Build dictionaries after loading everything.
        self.rebuild_peer_maps()

    # ========================================================
    # Basic helpers
    # ========================================================

    def wallet_public_key(self):
        return public_key_to_pem(self.wallet.public_key)

    def rebuild_peer_maps(self):

        self.name_to_public_key_dict.clear()
        self.node_id_to_name_dict.clear()
        self.name_to_node_id_dict.clear()

        for _, value in self.known_peers.items():

            if len(value) != 3:
                continue

            name, public_key, node_id = value

            name = str(name)
            public_key = public_key_to_pem(public_key)

            self.name_to_public_key_dict[name.lower()] = public_key
            self.node_id_to_name_dict[node_id] = name.lower()
            self.name_to_node_id_dict[name.lower()] = node_id

    def chain_available(self):
        return (
            Chain.instance is not None
            and getattr(Chain.instance, "chain", None)
            and len(Chain.instance.chain) > 0
        )

    # ========================================================
    # Disk
    # ========================================================

    def save_node_id_to_disk(self):
        save_node_id(self.node_id, CONSENSUS)

    def load_node_id_from_disk(self):
        node_id = load_node_id(CONSENSUS)

        if not node_id:
            self.node_id = None
            return

        self.node_id = node_id

    def save_key_to_disk(self):
        save_key(self.wallet.private_key_pem, CONSENSUS)

    def load_key_from_disk(self):
        key = load_key(CONSENSUS)

        if not key:
            self.wallet = None
            return

        try:
            self.wallet = Wallet(key)
        except Exception as e:
            print(f"Could not load wallet: {e}")
            self.wallet = None

    # ========================================================
    # Chain loading
    # ========================================================

    def load_chain_from_disk(self):

        block_dict_list = load_chain(CONSENSUS)

        if not block_dict_list:
            self.chain = None
            return

        block_list: List[Block] = []

        try:
            for block_dict in block_dict_list:
                block = self.block_dict_to_block(block_dict)
                block_list.append(block)

        except Exception as e:
            print(f"Could not load saved blockchain: {e}")
            self.chain = None
            return

        if not block_list:
            self.chain = None
            return

        try:
            if not isvalidChain(block_list):
                print("Saved blockchain is invalid. Ignoring saved chain.")
                self.chain = None
                return
        except Exception as e:
            print(f"Saved blockchain validation failed: {e}")
            self.chain = None
            return

        try:
            if Chain.instance is None:
                self.chain = Chain(blockList=block_list)
            else:
                Chain.instance.chain = block_list
                self.chain = Chain.instance

            print(
                f"Loaded blockchain from disk: "
                f"{len(block_list)} block(s)"
            )

        except Exception as e:
            print(f"Could not initialise saved blockchain: {e}")
            self.chain = None

    def save_chain_to_disk(self):

        if Chain.instance is None:
            return

        try:
            chain = Chain.instance.to_block_dict_list()
            save_chain(chain, CONSENSUS)
        except Exception as e:
            print(f"Could not save chain: {e}")

    # ========================================================
    # Peer persistence
    # ========================================================

    def save_known_peers_to_disk(self):

        content = {}

        for key, value in self.known_peers.items():

            try:
                content[json.dumps(key)] = [
                    value[0],
                    public_key_to_pem(value[1]),
                    value[2]
                ]
            except Exception:
                continue

        save_peers(content, CONSENSUS)

    def load_known_peers_from_disk(self):

        content = load_peers(CONSENSUS)

        if not content:
            self.known_peers = {}
            return

        self.known_peers = {}

        for key, value in content.items():

            try:
                endpoint = tuple(ast.literal_eval(key))

                if len(value) != 3:
                    continue

                name = value[0]
                public_key = public_key_to_pem(value[1])
                node_id = value[2]

                self.known_peers[endpoint] = (
                    name,
                    public_key,
                    node_id
                )

            except Exception as e:
                print(f"Skipping malformed saved peer: {e}")

        self.rebuild_peer_maps()

    # ========================================================
    # Peer information
    # ========================================================

    def get_peer_info_message(self):

        pkt = {
            "type": "peer_info",
            "id": str(uuid.uuid4()),
            "data": {
                "host": self.host,
                "port": self.port,
                "name": self.name,
                "public_key": self.wallet_public_key(),
                "node_id": self.node_id
            }
        }

        self.seen_message_ids.add(pkt["id"])

        return pkt

    def get_known_peers_message(self):

        peers = []

        for (host, port), (name, public_key, node_id) in self.known_peers.items():

            peers.append({
                "host": host,
                "port": port,
                "name": name,
                "public_key": public_key_to_pem(public_key),
                "node_id": node_id
            })

        peers.append({
            "host": self.host,
            "port": self.port,
            "name": self.name,
            "public_key": self.wallet_public_key(),
            "node_id": self.node_id
        })

        pkt = {
            "type": "known_peers",
            "id": str(uuid.uuid4()),
            "peers": peers
        }

        self.seen_message_ids.add(pkt["id"])

        return pkt

    def get_public_key_by_node_id(self, target_node_id):

        if target_node_id == self.node_id:
            return self.wallet_public_key()

        for _, (name, public_key, node_id) in self.known_peers.items():

            if node_id == target_node_id:
                return public_key_to_pem(public_key)

        return None

    def get_unique_name(self, base_name):

        existing_names = {
            value[0].lower()
            for value in self.known_peers.values()
            if value
        }

        existing_names.add(self.name.lower())

        base_name = base_name.lower()

        if base_name not in existing_names:
            return base_name

        counter = 1

        while True:

            new_name = f"{base_name}{counter}"

            if new_name not in existing_names:
                return new_name

            counter += 1

    # ========================================================
    # Miners
    # ========================================================

    def get_current_miners_list(self):

        if not self.chain_available():
            return []

        current_height = len(Chain.instance.chain)

        selected = None
        selected_activation = -1

        for miners_list, activation_block in self.miners:

            try:
                activation_block = int(activation_block)
            except Exception:
                continue

            if activation_block <= current_height:
                if activation_block >= selected_activation:
                    selected = miners_list
                    selected_activation = activation_block

        if selected is not None:
            return list(selected)

        latest = Chain.instance.chain[-1].miners_list

        return list(latest or [])

    def cleanup_old_miner_updates(self):

        if not self.chain_available():
            return

        height = len(Chain.instance.chain)

        while self.miners and self.miners[0][1] < height:
            self.miners.pop(0)

    async def broadcast_miners_list(
        self,
        miners_list,
        activation_block
    ):

        pkt = {
            "type": "miners_list_update",
            "id": str(uuid.uuid4()),
            "miners_list": miners_list,
            "activation_block": activation_block
        }

        message = json.dumps(pkt, sort_keys=True).encode()

        signature = self.wallet.private_key.sign(message)

        pkt["signature"] = signature.hex()

        self.seen_message_ids.add(pkt["id"])

        await self.broadcast_message(pkt)

    # ========================================================
    # Block conversion
    # ========================================================

    def block_dict_to_block(self, block_dict):

        if not isinstance(block_dict, dict):
            raise ValueError("Block is not a dictionary")

        required = [
            "id",
            "prevHash",
            "ts",
            "miner_node_id",
            "miner_public_key",
            "miners_list",
            "transactions"
        ]

        for key in required:

            if key not in block_dict:
                raise KeyError(
                    f"Missing block field: {key}"
                )

        new_block_id = block_dict["id"]
        new_block_prevHash = block_dict["prevHash"]
        new_block_ts = block_dict["ts"]

        new_block_miner_node_id = block_dict["miner_node_id"]

        new_block_miner_public_key = public_key_to_pem(
            block_dict["miner_public_key"]
        )

        new_block_miners_list = block_dict["miners_list"]

        new_block_signature = block_dict.get("signature")

        transactions = []

        for transaction_dict in block_dict["transactions"]:

            if not isinstance(transaction_dict, dict):
                raise ValueError("Invalid transaction dictionary")

            timestamp = get_transaction_timestamp(
                transaction_dict
            )

            if timestamp is None:
                raise KeyError(
                    "Transaction has neither 'ts' nor 'timestamp'"
                )

            transaction = Transaction(
                transaction_dict["payload"],
                transaction_dict["sender"],
                transaction_dict["receiver"],
                transaction_dict["id"],
                timestamp
            )

            if transaction.sender != "Genesis":

                sign_bytes = get_transaction_signature(
                    transaction_dict
                )

                if sign_bytes is None:
                    raise ValueError(
                        f"Missing/invalid signature for transaction "
                        f"{transaction.id}"
                    )

                transaction.sign = sign_bytes

            transactions.append(transaction)

        newBlock = Block(
            new_block_prevHash,
            transactions,
            new_block_ts,
            new_block_id
        )

        newBlock.miner_node_id = new_block_miner_node_id

        newBlock.miner_public_key = new_block_miner_public_key

        newBlock.miners_list = new_block_miners_list

        newBlock.files = block_dict.get("files", {})

        newBlock.signature = new_block_signature

        return newBlock

    # ========================================================
    # Network cleanup
    # ========================================================

    def discard_server_connection_details(self, websocket):

        self.server_connections.discard(websocket)

    def discard_client_connection_details(self, websocket):

        self.client_connections.discard(websocket)

        remote = getattr(websocket, "remote_address", None)

        if remote and len(remote) >= 2:

            try:
                normalized_endpoint = normalize_endpoint(
                    (remote[0], remote[1])
                )

                self.outbound_peers.discard(
                    normalized_endpoint
                )

            except Exception:
                pass

        self.got_pong.pop(websocket, None)
        self.have_sent_peer_info.pop(websocket, None)

    async def safe_close(self, websocket):

        try:
            await websocket.close()
        except Exception:
            pass

        try:
            await websocket.wait_closed()
        except Exception:
            pass

    # ========================================================
    # Miner role
    # ========================================================

    async def update_role(self, is_miner_now):

        current_task = asyncio.current_task()

        if is_miner_now:

            if not self.miner:

                self.miner = True

                if (
                    self.miner_task is None
                    or self.miner_task.done()
                ):
                    self.miner_task = asyncio.create_task(
                        self.mine_blocks()
                    )

        else:

            if self.miner:

                self.miner = False

                task = self.miner_task
                self.miner_task = None

                # Do not cancel the task if it is cancelling itself.
                if task and task is not current_task:

                    task.cancel()

                    try:
                        await task
                    except asyncio.CancelledError:
                        pass

    # ========================================================
    # Round calculation
    # ========================================================

    async def round_calculator(self):

        self.round = 0

        try:

            while True:

                await asyncio.sleep(10)

                if self.mem_pool:

                    await asyncio.sleep(80)

                    if self.mem_pool:

                        print("Shifting miner...")

                        self.round += 1

                        print("Miner shifted")

        except asyncio.CancelledError:
            print("Round calculator task stopped cleanly")

    async def restart_round_task(self):

        old_task = self.round_task

        if old_task and not old_task.done():

            old_task.cancel()

            try:
                await old_task
            except asyncio.CancelledError:
                pass

        self.round_task = asyncio.create_task(
            self.round_calculator()
        )

    # ========================================================
    # Smart contracts
    # ========================================================

    def valid_deploy_transaction(self, payload):

        try:

            if not isinstance(payload, list):
                return False

            if len(payload) < 2:
                return False

            contract_code = payload[0]
            amount = payload[-1]

            if not isinstance(contract_code, str):
                return False

            if not isinstance(amount, (int, float)) or isinstance(
                amount, bool
            ):
                return False

            if not math.isfinite(float(amount)):
                return False

            gas_used = (
                len(contract_code) // 10
                + BASE_DEPLOY_COST
            )

            expected_amount = gas_used * GAS_PRICE

            return math.isclose(
                float(amount),
                float(expected_amount),
                rel_tol=0,
                abs_tol=1e-12
            )

        except Exception:
            return False

    def valid_invoke_transaction(self, payload):

        try:

            if not isinstance(payload, list):
                return False

            if len(payload) < 5:
                return False

            contract_id = payload[0]
            func_name = payload[1]
            args = payload[2]
            expected_state = payload[3]
            amount = payload[-1]

            response = self.run_contract([
                contract_id,
                func_name,
                args
            ])

            if response.get("error") is not None:
                return False

            state = response["state"]
            gas_used = response["gas_used"]

            expected_amount = gas_used * GAS_PRICE

            if state != expected_state:
                return False

            return math.isclose(
                float(amount),
                float(expected_amount),
                rel_tol=0,
                abs_tol=1e-12
            )

        except Exception as e:

            print(
                f"Invoke validation failed: {e}"
            )

            return False

    def calculate_contract_id(self, sender, timestamp):

        data = f"{sender}:{timestamp}"

        return hashlib.sha256(
            data.encode("utf-8")
        ).hexdigest()

    def deploy_contract(self, transaction):

        try:

            sender = transaction.sender

            timestamp = getattr(
                transaction,
                "ts",
                getattr(transaction, "timestamp", None)
            )

            code = transaction.payload[0]

            contract_id = self.calculate_contract_id(
                sender,
                timestamp
            )

            self.contractsDB.store_contract(
                contract_id,
                code
            )

            print(
                "Contract deployed with id:",
                contract_id
            )

        except Exception as e:

            print(
                f"Could not deploy contract: {e}"
            )

    def rebuild_contract_database(self):

        if not self.chain_available():
            return

        try:

            self.contractsDB = SmartContractDatabase()

            for block in Chain.instance.chain:

                for transaction in block.transactions:

                    if transaction.receiver == "deploy":
                        self.deploy_contract(transaction)

        except Exception as e:

            print(
                f"Could not rebuild contract database: {e}"
            )

    def get_contract_state(self, contract_id):

        if not self.chain_available():
            return {}

        for block in reversed(Chain.instance.chain):

            for transaction in reversed(
                block.transactions
            ):

                if (
                    transaction.receiver == "invoke"
                    and transaction.payload[0] == contract_id
                ):
                    return transaction.payload[3]

        return {}

    def run_contract(self, payload):

        contract_id = payload[0]
        func_name = payload[1]
        args = payload[2]

        code = self.contractsDB.get_contract(
            contract_id
        )

        if code is None:
            raise Exception(
                f"Contract '{contract_id}' not found."
            )

        state = self.get_contract_state(
            contract_id
        )

        executor = SecureContractExecutor(code)

        return executor.run(
            func_name,
            args,
            state
        )

    # ========================================================
    # Message handler
    # ========================================================

    async def handle_messages(self, websocket, msg):

        if not isinstance(msg, dict):
            return

        message_type = msg.get("type")
        message_id = msg.get("id")

        if not message_type or not message_id:
            return

        if message_id in self.seen_message_ids:
            return

        self.seen_message_ids.add(message_id)

        # ----------------------------------------------------
        # Miner update
        # ----------------------------------------------------

        if message_type == "miners_list_update":

            try:

                admin_key = self.get_public_key_by_node_id(
                    self.admin_id
                )

                if not admin_key:
                    return

                public_key = VerifyingKey.from_pem(
                    admin_key.encode()
                )

                message = json.dumps({
                    "type": "miners_list_update",
                    "id": msg["id"],
                    "miners_list": msg["miners_list"],
                    "activation_block": msg["activation_block"]
                }, sort_keys=True).encode()

                signature = binascii.unhexlify(
                    msg["signature"]
                )

                public_key.verify(
                    signature,
                    message
                )

                if not isinstance(
                    msg["miners_list"],
                    list
                ):
                    return

                if len(msg["miners_list"]) == 0:
                    print(
                        "Rejected miner update: "
                        "miner list cannot be empty."
                    )
                    return

                self.miners.append([
                    msg["miners_list"],
                    msg["activation_block"]
                ])

                self.miners.sort(
                    key=lambda x: x[1]
                )

                await self.broadcast_message(msg)

            except Exception as e:

                print(
                    f"Invalid miners list update: {e}"
                )

        # ----------------------------------------------------
        # Ping
        # ----------------------------------------------------

        elif message_type == "ping":

            pkt = {
                "type": "pong",
                "id": str(uuid.uuid4())
            }

            self.seen_message_ids.add(pkt["id"])

            await self.send_message(
                websocket,
                pkt,
                False
            )

        # ----------------------------------------------------
        # Pong
        # ----------------------------------------------------

        elif message_type == "pong":

            self.got_pong[websocket] = True

            if not self.have_sent_peer_info.get(
                websocket,
                True
            ):

                message = self.get_peer_info_message()

                await self.send_message(
                    websocket,
                    message,
                    True
                )

                self.have_sent_peer_info[websocket] = True

        # ----------------------------------------------------
        # Peer info
        # ----------------------------------------------------

        elif message_type == "peer_info":

            try:

                data = msg["data"]

                normalized_self = normalize_endpoint(
                    (self.host, self.port)
                )

                normalized_endpoint = normalize_endpoint(
                    (data["host"], data["port"])
                )

                if (
                    normalized_endpoint not in self.known_peers
                    and normalized_endpoint != normalized_self
                ):

                    self.known_peers[
                        normalized_endpoint
                    ] = (
                        data["name"],
                        public_key_to_pem(
                            data["public_key"]
                        ),
                        data["node_id"]
                    )

                    self.rebuild_peer_maps()

                    if self.activate_disk_save == "y":
                        self.save_known_peers_to_disk()

                    print(
                        f"Registered peer "
                        f"{data['name']} "
                        f"{data['host']}:{data['port']}"
                    )

                    message = self.get_known_peers_message()

                    await self.send_message(
                        websocket,
                        message,
                        False
                    )

            except Exception as e:

                print(
                    f"Invalid peer_info: {e}"
                )

        # ----------------------------------------------------
        # Add peer
        # ----------------------------------------------------

        elif message_type == "add_peer":

            try:

                data = msg["data"]

                normalized_self = normalize_endpoint(
                    (self.host, self.port)
                )

                normalized_endpoint = normalize_endpoint(
                    (data["host"], data["port"])
                )

                new_peer_msg_id = str(uuid.uuid4())

                if (
                    normalized_endpoint not in self.known_peers
                    and normalized_endpoint != normalized_self
                ):

                    proposed_name = self.get_unique_name(
                        data["name"]
                    )

                    if proposed_name != data["name"]:

                        pkt = {
                            "type": "change_name",
                            "id": str(uuid.uuid4()),
                            "new_peer_msg_id":
                                new_peer_msg_id,
                            "new_name": proposed_name
                        }

                        await self.send_message(
                            websocket,
                            pkt,
                            False
                        )

                        data["name"] = proposed_name

                    self.known_peers[
                        normalized_endpoint
                    ] = (
                        data["name"],
                        public_key_to_pem(
                            data["public_key"]
                        ),
                        data["node_id"]
                    )

                    self.rebuild_peer_maps()

                    if self.activate_disk_save == "y":
                        self.save_known_peers_to_disk()

                    print(
                        f"Registered peer "
                        f"{data['name']} "
                        f"{data['host']}:{data['port']}"
                    )

                    message = self.get_known_peers_message()

                    await self.send_message(
                        websocket,
                        message,
                        False
                    )

                    pkt = {
                        "type": "new_peer",
                        "id": new_peer_msg_id,
                        "data": {
                            "host": data["host"],
                            "port": data["port"],
                            "name": data["name"],
                            "public_key":
                                public_key_to_pem(
                                    data["public_key"]
                                ),
                            "node_id": data["node_id"]
                        }
                    }

                    self.seen_message_ids.add(
                        pkt["id"]
                    )

                    await self.broadcast_message(
                        pkt
                    )

            except Exception as e:

                print(
                    f"Invalid add_peer: {e}"
                )

        # ----------------------------------------------------
        # New peer
        # ----------------------------------------------------

        elif message_type == "new_peer":

            try:

                data = msg["data"]

                normalized_self = normalize_endpoint(
                    (self.host, self.port)
                )

                normalized_endpoint = normalize_endpoint(
                    (data["host"], data["port"])
                )

                if (
                    normalized_endpoint not in self.known_peers
                    and normalized_endpoint != normalized_self
                ):

                    self.known_peers[
                        normalized_endpoint
                    ] = (
                        data["name"],
                        public_key_to_pem(
                            data["public_key"]
                        ),
                        data["node_id"]
                    )

                    self.rebuild_peer_maps()

                    if self.activate_disk_save == "y":
                        self.save_known_peers_to_disk()

                    print(
                        f"Registered peer "
                        f"{data['name']} "
                        f"{data['host']}:{data['port']}"
                    )

                    await self.broadcast_message(
                        msg
                    )

            except Exception as e:

                print(
                    f"Invalid new_peer: {e}"
                )

        # ----------------------------------------------------
        # Change name
        # ----------------------------------------------------

        elif message_type == "change_name":

            old_name = self.name.lower()

            self.name_to_node_id_dict.pop(
                old_name,
                None
            )

            new_name = msg["new_name"]

            self.name = new_name

            self.name_to_node_id_dict[
                self.name.lower()
            ] = self.node_id

            self.node_id_to_name_dict[
                self.node_id
            ] = self.name.lower()

            self.seen_message_ids.add(
                msg.get("new_peer_msg_id", "")
            )

        # ----------------------------------------------------
        # Known peers
        # ----------------------------------------------------

        elif message_type == "known_peers":

            try:

                peers = msg["peers"]

                new_peer_found = False

                normalized_self = normalize_endpoint(
                    (self.host, self.port)
                )

                for peer in peers:

                    normalized_endpoint = normalize_endpoint(
                        (peer["host"], peer["port"])
                    )

                    if (
                        normalized_endpoint not in self.known_peers
                        and normalized_endpoint != normalized_self
                    ):

                        print(
                            f"Discovered peer "
                            f"{peer['name']} "
                            f"at {peer['host']}:{peer['port']}"
                        )

                        new_peer_found = True

                        self.known_peers[
                            normalized_endpoint
                        ] = (
                            peer["name"],
                            public_key_to_pem(
                                peer["public_key"]
                            ),
                            peer["node_id"]
                        )

                if new_peer_found:

                    self.rebuild_peer_maps()

                    if self.activate_disk_save == "y":
                        self.save_known_peers_to_disk()

                pkt = {
                    "type":
                        "network_details_request",
                    "id":
                        str(uuid.uuid4())
                }

                await self.send_message(
                    websocket,
                    pkt,
                    True
                )

            except Exception as e:

                print(
                    f"Invalid known_peers: {e}"
                )

        # ----------------------------------------------------
        # File
        # ----------------------------------------------------

        elif message_type == "file":

            try:

                cid = msg["cid"]
                desc = msg["desc"]

                async with self.file_hashes_lock:
                    self.file_hashes[cid] = desc

                await self.broadcast_message(msg)

            except Exception as e:

                print(
                    f"Invalid file message: {e}"
                )

        # ----------------------------------------------------
        # Network details request
        # ----------------------------------------------------

        elif message_type == "network_details_request":

            pkt = {
                "type": "network_details",
                "id": str(uuid.uuid4()),
                "admin": self.admin_id,
                "miners": self.miners
            }

            await self.send_message(
                websocket,
                pkt,
                False
            )

        # ----------------------------------------------------
        # Network details
        # ----------------------------------------------------

        elif message_type == "network_details":

            self.admin_id = msg.get("admin")

            self.miners = msg.get(
                "miners",
                []
            )

            pkt = {
                "type": "chain_request",
                "id": str(uuid.uuid4())
            }

            self.seen_message_ids.add(
                pkt["id"]
            )

            await self.send_message(
                websocket,
                pkt,
                True
            )

        # ----------------------------------------------------
        # New transaction
        # ----------------------------------------------------

        elif message_type == "new_tx":

            try:

                tx_str = msg["transaction"]

                tx = json.loads(tx_str)

                timestamp = get_transaction_timestamp(
                    tx
                )

                if timestamp is None:
                    print(
                        "Transaction missing timestamp/ts"
                    )
                    return

                transaction = Transaction(
                    tx["payload"],
                    tx["sender"],
                    tx["receiver"],
                    tx["id"],
                    timestamp
                )

                sign_bytes = base64.b64decode(
                    msg["sign"],
                    validate=True
                )

                # Verify signature BEFORE executing
                # smart-contract code.
                public_key = VerifyingKey.from_pem(
                    tx["sender"].encode()
                )

                public_key.verify(
                    sign_bytes,
                    tx_str.encode()
                )

                transaction.sign = sign_bytes

            except Exception as e:

                print(
                    f"Invalid transaction signature/data: {e}"
                )

                return

            # ------------------------------------------------
            # Contract validation
            # ------------------------------------------------

            try:

                if transaction.receiver == "deploy":

                    if not self.valid_deploy_transaction(
                        transaction.payload
                    ):
                        return

                elif transaction.receiver == "invoke":

                    if not self.valid_invoke_transaction(
                        transaction.payload
                    ):
                        return

            except Exception as e:

                print(
                    f"Transaction validation error: {e}"
                )

                return

            # ------------------------------------------------
            # Mempool
            # ------------------------------------------------

            async with self.mem_pool_condition:

                if not self.chain_available():
                    return

                if Chain.instance.transaction_exists_in_chain(
                    transaction
                ):
                    print(
                        "Transaction already exists in chain"
                    )
                    return

                for pending in self.mem_pool:

                    if (
                        pending.id
                        == transaction.id
                    ):
                        return

                if transaction.receiver in (
                    "deploy",
                    "invoke"
                ):

                    amount = transaction.payload[-1]

                else:

                    amount = transaction.payload

                try:

                    amount = float(amount)

                except Exception:

                    return

                if (
                    not math.isfinite(amount)
                    or amount <= 0
                ):
                    print(
                        "Invalid transaction amount"
                    )
                    return

                balance = Chain.instance.calc_balance(
                    publicKey=transaction.sender,
                    pending_transactions=self.mem_pool
                )

                if amount > balance:

                    print(
                        "\nAttempt to spend more "
                        "than available balance\n"
                    )

                    return

                self.mem_pool.append(
                    transaction
                )

            print("\nValid Transaction")

            print(
                f"\n{message_type}: "
                f"{msg['transaction']}\n"
            )

            await self.broadcast_message(msg)

        # ----------------------------------------------------
        # New block
        # ----------------------------------------------------

        elif message_type == "new_block":

            try:

                new_block_dict = msg["block"]

                newBlock = self.block_dict_to_block(
                    new_block_dict
                )

            except Exception as e:

                print(
                    f"Could not decode block: {e}"
                )

                return

            async with self.chain_lock:

                if not self.chain_available():
                    return

                miners_list = self.get_current_miners_list()

                if not miners_list:
                    print(
                        "No miners available."
                    )
                    return

                reqd_miner_node_id = miners_list[
                    (
                        len(Chain.instance.chain)
                        + self.round
                    ) % len(miners_list)
                ]

                reqd_miner_public_key = (
                    self.get_public_key_by_node_id(
                        reqd_miner_node_id
                    )
                )

                if not reqd_miner_public_key:
                    print(
                        "Could not find miner public key."
                    )
                    return

                # Ensure the block's miner list is the
                # expected list.
                if (
                    newBlock.miners_list
                    != miners_list
                ):

                    print(
                        "Invalid miner list in block."
                    )
                    return

                if not Chain.instance.isValidBlock(
                    newBlock,
                    reqd_miner_node_id,
                    reqd_miner_public_key
                ):

                    print("\nInvalid Block\n")
                    return

                for transaction in newBlock.transactions:

                    if transaction.receiver == "invoke":

                        if not self.valid_invoke_transaction(
                            transaction.payload
                        ):
                            print(
                                "Invalid invoke transaction."
                            )
                            return

                    elif transaction.receiver == "deploy":

                        if not self.valid_deploy_transaction(
                            transaction.payload
                        ):
                            print(
                                "Invalid deploy transaction."
                            )
                            return

                Chain.instance.chain.append(
                    newBlock
                )

                self.chain = Chain.instance

                print(
                    "\n\nBlock Appended\n"
                )

                for transaction in newBlock.transactions:

                    if transaction.receiver == "deploy":
                        self.deploy_contract(
                            transaction
                        )

                async with self.mem_pool_condition:

                    self.mem_pool = [
                        tx
                        for tx in self.mem_pool
                        if not newBlock.transaction_exists_in_block(
                            tx
                        )
                    ]

                async with self.file_hashes_lock:

                    for cid in list(
                        self.file_hashes.keys()
                    ):

                        if newBlock.cid_exists_in_block(cid):

                            self.file_hashes.pop(
                                cid,
                                None
                            )

            await self.broadcast_message(msg)

            await self.restart_round_task()

            self.cleanup_old_miner_updates()

            new_miners_list = (
                self.get_current_miners_list()
            )

            await self.update_role(
                self.node_id in new_miners_list
            )

            if self.activate_disk_save == "y":
                self.save_chain_to_disk()

        # ----------------------------------------------------
        # Chain request
        # ----------------------------------------------------

        elif message_type == "chain_request":

            if not self.chain_available():
                return

            pkt = {
                "type": "chain",
                "id": str(uuid.uuid4()),
                "chain":
                    Chain.instance.to_block_dict_list()
            }

            self.seen_message_ids.add(
                pkt["id"]
            )

            await self.send_message(
                websocket,
                pkt,
                False
            )

        # ----------------------------------------------------
        # Chain
        # ----------------------------------------------------

        elif message_type == "chain":

            print("Received a Chain")

            try:

                block_dict_list = msg["chain"]

                block_list = []

                for block_dict in block_dict_list:

                    block = self.block_dict_to_block(
                        block_dict
                    )

                    block_list.append(block)

                if not block_list:

                    return

                if not isvalidChain(
                    block_list
                ):

                    print(
                        "\nInvalid Chain\n"
                    )

                    return

            except Exception as e:

                print(
                    f"Could not validate received chain: {e}"
                )

                return

            async with self.chain_lock:

                # If we already have a chain, require the
                # same genesis block.
                if self.chain_available():

                    local_genesis = (
                        Chain.instance.chain[0].hash
                    )

                    received_genesis = (
                        block_list[0].hash
                    )

                    if (
                        local_genesis
                        != received_genesis
                    ):

                        print(
                            "Rejected chain: "
                            "different genesis block."
                        )

                        return

                if not self.chain_available():

                    try:

                        self.chain = Chain(
                            blockList=block_list
                        )

                    except Exception as e:

                        print(
                            f"Could not initialise chain: {e}"
                        )

                        return

                    self.chain = Chain.instance

                    print(
                        "\nInitial chain accepted.\n"
                    )

                elif (
                    len(Chain.instance.chain)
                    < len(block_list)
                ):

                    Chain.instance.rewrite(
                        block_list
                    )

                    self.chain = Chain.instance

                    print(
                        "\nCurrent chain replaced "
                        "by longer chain\n"
                    )

                else:

                    print(
                        "\nCurrent Chain is longer "
                        "or equal to received chain\n"
                    )

                    return

                self.rebuild_contract_database()

                async with self.mem_pool_condition:

                    self.mem_pool = [
                        tx
                        for tx in self.mem_pool
                        if not Chain.instance.transaction_exists_in_chain(
                            tx
                        )
                    ]

                async with self.file_hashes_lock:

                    for cid in list(
                        self.file_hashes.keys()
                    ):

                        if Chain.instance.cid_exists_in_chain(
                            cid
                        ):

                            self.file_hashes.pop(
                                cid,
                                None
                            )

            self.cleanup_old_miner_updates()

            if self.chain_available():

                current_miners = (
                    self.get_current_miners_list()
                )

                await self.update_role(
                    self.node_id in current_miners
                )

    # ========================================================
    # Connections
    # ========================================================

    async def handle_connections(self, websocket):

        remote = getattr(
            websocket,
            "remote_address",
            None
        )

        if remote:
            peer_addr = (
                remote[0],
                remote[1]
            )
        else:
            peer_addr = (
                "unknown",
                "unknown"
            )

        self.server_connections.add(
            websocket
        )

        print(
            f"Inbound Connection from "
            f"{peer_addr[0]}:{peer_addr[1]}"
        )

        try:

            async for raw in websocket:

                try:

                    msg = json.loads(raw)

                except json.JSONDecodeError:

                    print(
                        "Received invalid JSON."
                    )

                    continue

                try:

                    await self.handle_messages(
                        websocket,
                        msg
                    )

                except Exception as e:

                    print(
                        f"Error handling message: {e}"
                    )

        except websockets.exceptions.ConnectionClosed:

            print(
                f"Inbound Connection Closed: "
                f"{peer_addr}"
            )

        except Exception as e:

            print(
                f"Inbound connection error: {e}"
            )

        finally:

            self.discard_server_connection_details(
                websocket
            )

            await self.safe_close(
                websocket
            )

    async def send_message(
        self,
        websocket,
        message,
        client_connection
    ):

        try:

            await websocket.send(
                json.dumps(message)
            )

        except Exception as e:

            print(
                f"Unexpected error during "
                f"WebSocket send: {e}"
            )

            if client_connection:

                self.discard_client_connection_details(
                    websocket
                )

            else:

                self.discard_server_connection_details(
                    websocket
                )

            await self.safe_close(
                websocket
            )

    async def broadcast_message(self, pkt):

        targets = (
            self.server_connections
            | self.client_connections
        )

        for ws in list(targets):

            if ws in self.server_connections:

                await self.send_message(
                    ws,
                    pkt,
                    False
                )

            else:

                await self.send_message(
                    ws,
                    pkt,
                    True
                )

    # ========================================================
    # Transaction creation
    # ========================================================

    async def create_and_broadcast_tx(
        self,
        receiver_public_key,
        payload
    ):

        if not self.chain_available():

            print(
                "Blockchain is not initialized."
            )

            return

        transaction = Transaction(
            payload,
            self.wallet_public_key(),
            receiver_public_key
        )

        # Validate before adding to mempool.
        try:

            if receiver_public_key == "deploy":

                if not self.valid_deploy_transaction(
                    payload
                ):
                    print(
                        "Invalid deploy transaction."
                    )
                    return

            elif receiver_public_key == "invoke":

                if not self.valid_invoke_transaction(
                    payload
                ):
                    print(
                        "Invalid invoke transaction."
                    )
                    return

            if receiver_public_key in (
                "deploy",
                "invoke"
            ):

                amount = payload[-1]

            else:

                amount = payload

            amount = float(amount)

            if (
                not math.isfinite(amount)
                or amount <= 0
            ):

                print(
                    "Invalid transaction amount."
                )
                return

        except Exception as e:

            print(
                f"Transaction validation failed: {e}"
            )

            return

        transaction_str = str(transaction)

        signature = self.wallet.private_key.sign(
            transaction_str.encode()
        )

        transaction.sign = signature

        signature_b64 = base64.b64encode(
            signature
        ).decode()

        pkt = {
            "type": "new_tx",
            "id": str(uuid.uuid4()),
            "transaction": transaction_str,
            "sign": signature_b64,
            "sender_pem":
                self.wallet_public_key()
        }

        async with self.mem_pool_condition:

            if Chain.instance.transaction_exists_in_chain(
                transaction
            ):

                return

            if any(
                tx.id == transaction.id
                for tx in self.mem_pool
            ):

                return

            balance = Chain.instance.calc_balance(
                publicKey=self.wallet_public_key(),
                pending_transactions=self.mem_pool
            )

            if amount > balance:

                print(
                    "Insufficient balance."
                )

                return

            self.mem_pool.append(
                transaction
            )

        self.seen_message_ids.add(
            pkt["id"]
        )

        print(
            "Transaction Created",
            transaction
        )

        await self.broadcast_message(
            pkt
        )

    # ========================================================
    # User input
    # ========================================================

    async def user_input_handler(self):

        loop = asyncio.get_running_loop()

        while True:

            print(
                "\nBlock Chain Menu\n"
                "****************"
            )

            menu = (
                "1) Add Transaction\n"
                "2) View balance\n"
                "3) Print Chain\n"
                "4) Print Pending Transactions\n"
                "5) Send Files\n"
                "6) Download Files\n"
            )

            if self.node_id == self.admin_id:

                menu += (
                    "7) View Miners\n"
                    "8) Add Miner\n"
                    "9) Remove Miner\n"
                )

            menu += "0) Quit"

            print(menu)

            ch = await loop.run_in_executor(
                None,
                input,
                "Enter Your Choice: "
            )

            try:
                ch = int(ch)

            except ValueError:

                print(
                    "\nPlease enter a valid number!!!\n"
                )

                continue

            # ------------------------------------------------
            # Add transaction
            # ------------------------------------------------

            if ch == 1:

                if not self.chain_available():

                    print(
                        "Blockchain is not initialized yet."
                    )

                    continue

                rec = await loop.run_in_executor(
                    None,
                    input,
                    "\nEnter Receiver's Name or Public Key: "
                )

                rec_clean = rec.strip()

                if rec_clean.lower() == "deploy":

                    contract_code = await asyncio.to_thread(
                        get_contract_code_from_notepad
                    )

                    if not contract_code:

                        print(
                            "Contract code field is empty"
                        )

                        continue

                    gas_used = (
                        len(contract_code) // 10
                        + BASE_DEPLOY_COST
                    )

                    amount = (
                        gas_used * GAS_PRICE
                    )

                    payload = [
                        contract_code,
                        amount
                    ]

                    await self.create_and_broadcast_tx(
                        "deploy",
                        payload
                    )

                elif rec_clean.lower() == "invoke":

                    contract_id = await loop.run_in_executor(
                        None,
                        input,
                        "\nEnter Contract Id: "
                    )

                    if contract_id not in (
                        self.contractsDB.contracts
                    ):

                        print(
                            "No such contract found..."
                        )

                        continue

                    func_name = await loop.run_in_executor(
                        None,
                        input,
                        "\nEnter Function Name: "
                    )

                    args = []

                    arg_number = 1

                    while True:

                        arg = await loop.run_in_executor(
                            None,
                            input,
                            f"Enter argument "
                            f"{arg_number} "
                            f"(or \\q to finish): "
                        )

                        if arg.strip() == "\\q":
                            break

                        try:

                            parsed_arg = ast.literal_eval(
                                arg
                            )

                        except Exception:

                            parsed_arg = arg

                        args.append(
                            parsed_arg
                        )

                        arg_number += 1

                    try:

                        response = self.run_contract([
                            contract_id,
                            func_name,
                            args
                        ])

                    except Exception as e:

                        print(
                            f"Contract error: {e}"
                        )

                        continue

                    if response.get("error") is not None:

                        print(
                            "Error:",
                            response["error"]
                        )

                        continue

                    state = response["state"]
                    gas_used = response["gas_used"]

                    amount = gas_used * GAS_PRICE

                    payload = [
                        contract_id,
                        func_name,
                        args,
                        state,
                        amount
                    ]

                    await self.create_and_broadcast_tx(
                        "invoke",
                        payload
                    )

                else:

                    amt = await loop.run_in_executor(
                        None,
                        input,
                        "\nEnter Amount to send: "
                    )

                    receiver_public_key = (
                        self.name_to_public_key_dict.get(
                            rec_clean.lower()
                        )
                    )

                    if receiver_public_key is None:

                        rec_refined = rec.replace(
                            "\\n",
                            "\n"
                        )

                        for pk in (
                            self.name_to_public_key_dict.values()
                        ):

                            if pk == rec_refined:

                                receiver_public_key = pk
                                break

                    if receiver_public_key is None:

                        print(
                            "No person available in "
                            "directory with provided "
                            "name or public key..."
                        )

                        continue

                    try:

                        amt = float(amt)

                    except ValueError:

                        print(
                            "Amount must be a number"
                        )

                        continue

                    if (
                        not math.isfinite(amt)
                        or amt <= 0
                    ):

                        print(
                            "\nAmount must be positive\n"
                        )

                        continue

                    await self.create_and_broadcast_tx(
                        receiver_public_key,
                        amt
                    )

            # ------------------------------------------------
            # Balance
            # ------------------------------------------------

            elif ch == 2:

                if not self.chain_available():

                    print(
                        "Blockchain is not initialized."
                    )

                    continue

                print(
                    "Account Balance =",
                    Chain.instance.calc_balance(
                        self.wallet_public_key(),
                        self.mem_pool
                    )
                )

            # ------------------------------------------------
            # Chain
            # ------------------------------------------------

            elif ch == 3:

                if not self.chain_available():
                    print("Blockchain is not initialized.")
                    continue

                for i, block in enumerate(
                    Chain.instance.chain
                ):

                    print(
                        f"block{i}: {block}\n"
                    )

            # ------------------------------------------------
            # Mempool
            # ------------------------------------------------

            elif ch == 4:

                for i, transaction in enumerate(
                    self.mem_pool
                ):

                    print(
                        f"transaction{i}: "
                        f"{transaction}\n"
                    )

            # ------------------------------------------------
            # Upload
            # ------------------------------------------------

            elif ch == 5:

                desc = await loop.run_in_executor(
                    None,
                    input,
                    "\nEnter description of file: "
                )

                path = await loop.run_in_executor(
                    None,
                    input,
                    "\nEnter path of file: "
                )

                pkt = await self.uploadFile(
                    desc,
                    path
                )

                if pkt:

                    await self.broadcast_message(
                        pkt
                    )

            # ------------------------------------------------
            # Download
            # ------------------------------------------------

            elif ch == 6:

                cid = await loop.run_in_executor(
                    None,
                    input,
                    "\nEnter cid of file: "
                )

                path = await loop.run_in_executor(
                    None,
                    input,
                    "\nEnter path to download the file: "
                )

                await asyncio.to_thread(
                    download_ipfs_file_subprocess,
                    cid,
                    path
                )

            # ------------------------------------------------
            # View miners
            # ------------------------------------------------

            elif ch == 7:

                if self.node_id != self.admin_id:
                    continue

                current = self.get_current_miners_list()

                miner_names = [
                    self.node_id_to_name_dict.get(
                        miner,
                        miner
                    )
                    for miner in current
                ]

                print(
                    "Current miners:"
                )

                print(
                    miner_names
                )

                for miner_item in self.miners:

                    miner_names = [
                        self.node_id_to_name_dict.get(
                            miner,
                            miner
                        )
                        for miner in miner_item[0]
                    ]

                    print(
                        f"Miners to be activated "
                        f"from block "
                        f"{miner_item[1]}"
                    )

                    print(
                        miner_names
                    )

            # ------------------------------------------------
            # Add miner
            # ------------------------------------------------

            elif ch == 8:

                if self.node_id != self.admin_id:
                    continue

                miner_name = await loop.run_in_executor(
                    None,
                    input,
                    "\nEnter Miner's Name: "
                )

                miner_node_id = (
                    self.name_to_node_id_dict.get(
                        miner_name.lower()
                    )
                )

                if miner_node_id is None:

                    print(
                        "Miner not found."
                    )

                    continue

                if self.miners:

                    miners_list = copy.deepcopy(
                        self.miners[-1][0]
                    )

                else:

                    miners_list = copy.deepcopy(
                        Chain.instance.chain[-1].miners_list
                    )

                if miner_node_id not in miners_list:

                    miners_list.append(
                        miner_node_id
                    )

                    activation = (
                        len(Chain.instance.chain)
                        + 3
                    )

                    self.miners.append([
                        miners_list,
                        activation
                    ])

                    await self.broadcast_miners_list(
                        miners_list,
                        activation
                    )

                else:

                    print(
                        f"{miner_name} is already "
                        f"in miners list"
                    )

            # ------------------------------------------------
            # Remove miner
            # ------------------------------------------------

            elif ch == 9:

                if self.node_id != self.admin_id:
                    continue

                miner_name = await loop.run_in_executor(
                    None,
                    input,
                    "\nEnter Miner's Name: "
                )

                miner_node_id = (
                    self.name_to_node_id_dict.get(
                        miner_name.lower()
                    )
                )

                if miner_node_id is None:

                    print(
                        "Miner not found."
                    )

                    continue

                if self.miners:

                    miners_list = copy.deepcopy(
                        self.miners[-1][0]
                    )

                else:

                    miners_list = copy.deepcopy(
                        Chain.instance.chain[-1].miners_list
                    )

                if miner_node_id in miners_list:

                    # Never allow zero miners.
                    if len(miners_list) <= 1:

                        print(
                            "Cannot remove the last miner."
                        )

                        continue

                    miners_list.remove(
                        miner_node_id
                    )

                    activation = (
                        len(Chain.instance.chain)
                        + 3
                    )

                    self.miners.append([
                        miners_list,
                        activation
                    ])

                    await self.broadcast_miners_list(
                        miners_list,
                        activation
                    )

                else:

                    print(
                        f"{miner_name} is already "
                        f"not in miners list"
                    )

            # ------------------------------------------------
            # Quit
            # ------------------------------------------------

            elif ch == 0:

                print(
                    "Quitting..."
                )

                break

    # ========================================================
    # Connections
    # ========================================================

    async def connect_to_peer(
        self,
        host,
        port
    ):

        try:

            endpoint = normalize_endpoint(
                (host, port)
            )

        except Exception as e:

            print(
                f"Invalid peer endpoint: {e}"
            )

            return

        normalized_self = normalize_endpoint(
            (self.host, self.port)
        )

        if endpoint == normalized_self:
            return

        if endpoint in self.outbound_peers:
            return

        if endpoint in self.connecting_peers:
            return

        self.connecting_peers.add(endpoint)

        websocket = None

        try:

            normalized_host, normalized_port = endpoint

            uri = (
                f"ws://{normalized_host}:"
                f"{normalized_port}"
            )

            websocket = await websockets.connect(
                uri
            )

            self.client_connections.add(
                websocket
            )

            self.outbound_peers.add(
                endpoint
            )

            self.have_sent_peer_info[
                websocket
            ] = False

            print(
                f"Outbound connection formed to "
                f"{normalized_host}:{normalized_port}"
            )

            if Chain.instance is None:

                pkt = {
                    "type": "add_peer",
                    "id": str(uuid.uuid4()),
                    "data": {
                        "host": self.host,
                        "port": self.port,
                        "name": self.name,
                        "public_key":
                            self.wallet_public_key(),
                        "node_id": self.node_id
                    }
                }

            else:

                pkt = {
                    "type": "ping",
                    "id": str(uuid.uuid4())
                }

            self.seen_message_ids.add(
                pkt["id"]
            )

            await self.send_message(
                websocket,
                pkt,
                True
            )

            async for raw in websocket:

                try:
                    msg = json.loads(raw)

                except json.JSONDecodeError:
                    continue

                await self.handle_messages(
                    websocket,
                    msg
                )

        except Exception as e:

            print(
                f"Failed to connect to "
                f"{host}:{port} ::: {e}"
            )

        finally:

            self.connecting_peers.discard(
                endpoint
            )

            if websocket:

                self.discard_client_connection_details(
                    websocket
                )

                await self.safe_close(
                    websocket
                )

    async def discover_peers(self):

        while True:

            try:

                normalized_self = normalize_endpoint(
                    (self.host, self.port)
                )

                if (
                    len(self.outbound_peers)
                    < MAX_CONNECTIONS
                ):

                    potential_peers = {
                        endpoint
                        for endpoint in self.known_peers
                        if (
                            endpoint
                            not in self.outbound_peers
                            and endpoint
                            not in self.connecting_peers
                            and endpoint
                            != normalized_self
                        )
                    }

                    while (
                        len(self.outbound_peers)
                        + len(self.connecting_peers)
                        < MAX_CONNECTIONS
                        and potential_peers
                    ):

                        new_peer = get_random_element(
                            potential_peers
                        )

                        potential_peers.discard(
                            new_peer
                        )

                        if new_peer:

                            asyncio.create_task(
                                self.connect_to_peer(
                                    *new_peer
                                )
                            )

                            await asyncio.sleep(1)

                await asyncio.sleep(30)

            except asyncio.CancelledError:
                raise

            except Exception as e:

                print(
                    f"Peer discovery error: {e}"
                )

                await asyncio.sleep(5)

    async def gossip_peer_sampler(self):

        while True:

            try:

                await asyncio.sleep(60)

                if (
                    len(self.known_peers)
                    <= len(self.outbound_peers)
                    or len(self.outbound_peers)
                    < MAX_CONNECTIONS
                ):
                    continue

                to_drop = get_random_element(
                    self.client_connections
                )

                if to_drop:

                    remote = getattr(
                        to_drop,
                        "remote_address",
                        None
                    )

                    print(
                        "Gossip Sampling: "
                        f"Disconnecting {remote}"
                    )

                    await self.safe_close(
                        to_drop
                    )

                    self.discard_client_connection_details(
                        to_drop
                    )

                normalized_self = normalize_endpoint(
                    (self.host, self.port)
                )

                potential_peers = {
                    endpoint
                    for endpoint in self.known_peers
                    if (
                        endpoint
                        not in self.outbound_peers
                        and endpoint
                        not in self.connecting_peers
                        and endpoint
                        != normalized_self
                    )
                }

                if potential_peers:

                    new_peer = get_random_element(
                        potential_peers
                    )

                    if new_peer:

                        print(
                            "Gossip Sampling: "
                            f"Connecting to new peer "
                            f"{new_peer}"
                        )

                        asyncio.create_task(
                            self.connect_to_peer(
                                *new_peer
                            )
                        )

            except asyncio.CancelledError:
                raise

            except Exception as e:

                print(
                    f"Gossip sampler error: {e}"
                )

    # ========================================================
    # Files / IPFS
    # ========================================================

    async def uploadFile(
        self,
        desc: str,
        path: str
    ):

        file_path = Path(path)

        if not file_path.is_file():

            print(
                "\nFile doesn't exist\n"
            )

            return None

        if not self.daemon_process:

            self.start_daemon()

        cid, name = await asyncio.to_thread(
            addToIpfs,
            path
        )

        if not cid or not name:
            return None

        print(
            f"\nNew File Created : {cid}\n"
        )

        pkt = {
            "type": "file",
            "id": str(uuid.uuid4()),
            "desc": desc,
            "cid": cid
        }

        self.seen_message_ids.add(
            pkt["id"]
        )

        async with self.file_hashes_lock:

            self.file_hashes[cid] = desc

        return pkt

    def init_repo(self):

        if not self.repo_path.exists():

            subprocess.run(
                ["ipfs", "init"],
                env=self.env,
                check=True
            )

            print(
                "\nIPFS repo created\n"
            )

    def configure_ports(self):

        subprocess.run(
            [
                "ipfs",
                "config",
                "Addresses.API",
                f"/ip4/127.0.0.1/tcp/{self.ipfs_port}"
            ],
            env=self.env,
            check=True
        )

        subprocess.run(
            [
                "ipfs",
                "config",
                "Addresses.Gateway",
                f"/ip4/127.0.0.1/tcp/{self.gateway_port}"
            ],
            env=self.env,
            check=True
        )

        subprocess.run(
            [
                "ipfs",
                "config",
                "Addresses.Swarm",
                "--json",
                (
                    f'["/ip4/127.0.0.1/tcp/'
                    f'{self.swarm_tcp}", '
                    f'"/ip4/127.0.0.1/udp/'
                    f'{self.swarm_udp}/quic"]'
                )
            ],
            env=self.env,
            check=True
        )

        print(
            "\nConfigured Ports\n"
        )

    def start_daemon(self):

        try:

            self.daemon_process = subprocess.Popen(
                ["ipfs", "daemon"],
                env=self.env
            )

            print(
                "\nIPFS Daemon Started\n"
            )

        except Exception as e:

            print(
                f"Could not start IPFS daemon: {e}"
            )

    def stop_daemon(self):

        if self.daemon_process:

            try:

                self.daemon_process.terminate()
                self.daemon_process.wait(
                    timeout=5
                )

            except Exception:

                try:
                    self.daemon_process.kill()
                except Exception:
                    pass

            self.daemon_process = None

    # ========================================================
    # Block signing
    # ========================================================

    def sign_block(self, block: Block):

        # VERY IMPORTANT:
        # Always store a PEM string in the block.
        block.miner_public_key = (
            self.wallet_public_key()
        )

        message = block.get_message_to_sign()

        signature = self.wallet.private_key.sign(
            message
        )

        block.signature = signature.hex()

    # ========================================================
    # Mining
    # ========================================================

    async def mine_blocks(self):

        try:

            while self.miner:

                await asyncio.sleep(30)

                if not self.miner:
                    break

                if not self.chain_available():
                    continue

                miners_list = (
                    self.get_current_miners_list()
                )

                if not miners_list:
                    print(
                        "No miners available."
                    )
                    continue

                reqd_miner_node_id = miners_list[
                    (
                        len(Chain.instance.chain)
                        + self.round
                    ) % len(miners_list)
                ]

                if self.node_id != reqd_miner_node_id:
                    continue

                if self.round != 0:

                    await asyncio.sleep(15)

                    if not self.miner:
                        break

                # ------------------------------------------------
                # Snapshot mempool
                # ------------------------------------------------

                async with self.mem_pool_condition:

                    if not self.mem_pool:
                        continue

                    transaction_list = [
                        tx
                        for tx in self.mem_pool
                        if not Chain.instance.transaction_exists_in_chain(
                            tx
                        )
                    ]

                    self.mem_pool = transaction_list.copy()

                if not transaction_list:
                    continue

                # ------------------------------------------------
                # Choose two external recipients.
                #
                # This preserves the malicious-node behavior
                # of creating two conflicting blocks.
                # ------------------------------------------------

                external_keys = []

                for node_id in miners_list:

                    if node_id == self.node_id:
                        continue

                    pk = self.get_public_key_by_node_id(
                        node_id
                    )

                    if pk and pk not in external_keys:
                        external_keys.append(pk)

                # If not enough known recipients, use all known
                # public keys.
                if len(external_keys) < 2:

                    for pk in (
                        self.name_to_public_key_dict.values()
                    ):

                        pk = public_key_to_pem(pk)

                        if (
                            pk
                            and pk != self.wallet_public_key()
                            and pk not in external_keys
                        ):
                            external_keys.append(pk)

                        if len(external_keys) >= 2:
                            break

                if len(external_keys) < 2:

                    print(
                        "Not enough peers to create "
                        "malicious fork."
                    )

                    continue

                # ------------------------------------------------
                # Calculate miner balance
                # ------------------------------------------------

                miner_balance = (
                    Chain.instance.calc_balance(
                        self.wallet_public_key(),
                        transaction_list
                    )
                )

                if (
                    not math.isfinite(
                        float(miner_balance)
                    )
                    or miner_balance <= 0
                ):
                    continue

                amount = miner_balance * 0.75

                if amount <= 0:
                    continue

                # ------------------------------------------------
                # Create two conflicting transactions
                # ------------------------------------------------

                tx1 = Transaction(
                    amount,
                    self.wallet_public_key(),
                    external_keys[0]
                )

                tx2 = Transaction(
                    amount,
                    self.wallet_public_key(),
                    external_keys[1]
                )

                tx1.sign = self.wallet.private_key.sign(
                    str(tx1).encode()
                )

                tx2.sign = self.wallet.private_key.sign(
                    str(tx2).encode()
                )

                # ------------------------------------------------
                # Snapshot current previous hash
                # ------------------------------------------------

                async with self.chain_lock:

                    if not self.chain_available():
                        continue

                    previous_hash = (
                        Chain.instance.lastBlock.hash
                    )

                    current_miners = (
                        self.get_current_miners_list()
                    )

                    if not current_miners:
                        continue

                    # ------------------------------------------------
                    # Block 1
                    # ------------------------------------------------

                    block1_transactions = (
                        transaction_list
                        + [tx1]
                    )

                    newBlock1 = Block(
                        previous_hash,
                        block1_transactions
                    )

                    newBlock1.miner_node_id = (
                        self.node_id
                    )

                    newBlock1.miner_public_key = (
                        self.wallet_public_key()
                    )

                    newBlock1.miners_list = (
                        current_miners
                    )

                    async with self.file_hashes_lock:

                        newBlock1.files = (
                            self.file_hashes.copy()
                        )

                    self.sign_block(
                        newBlock1
                    )

                    if not Chain.instance.isValidBlock(
                        newBlock1,
                        self.node_id,
                        self.wallet_public_key()
                    ):

                        print(
                            "Locally created block "
                            "failed validation."
                        )

                        continue

                    # ------------------------------------------------
                    # Block 2
                    #
                    # Same prevHash, different transaction.
                    # This is intentional malicious behavior.
                    # ------------------------------------------------

                    block2_transactions = (
                        transaction_list
                        + [tx2]
                    )

                    newBlock2 = Block(
                        previous_hash,
                        block2_transactions
                    )

                    newBlock2.miner_node_id = (
                        self.node_id
                    )

                    newBlock2.miner_public_key = (
                        self.wallet_public_key()
                    )

                    newBlock2.miners_list = (
                        current_miners
                    )

                    async with self.file_hashes_lock:

                        newBlock2.files = (
                            self.file_hashes.copy()
                        )

                    self.sign_block(
                        newBlock2
                    )

                    # ------------------------------------------------
                    # Append only block 1 locally.
                    # Block 2 is sent to other peers.
                    # ------------------------------------------------

                    Chain.instance.chain.append(
                        newBlock1
                    )

                    self.chain = Chain.instance

                    print(
                        "\nMalicious Block 1 Appended\n"
                    )

                    for transaction in (
                        newBlock1.transactions
                    ):

                        if transaction.receiver == "deploy":

                            self.deploy_contract(
                                transaction
                            )

                    async with self.mem_pool_condition:

                        self.mem_pool = [
                            tx
                            for tx in self.mem_pool
                            if not newBlock1.transaction_exists_in_block(
                                tx
                            )
                        ]

                    async with self.file_hashes_lock:

                        for cid in list(
                            self.file_hashes.keys()
                        ):

                            if newBlock1.cid_exists_in_block(
                                cid
                            ):

                                self.file_hashes.pop(
                                    cid,
                                    None
                                )

                # ------------------------------------------------
                # Broadcast conflicting blocks
                # ------------------------------------------------

                pkt1 = {
                    "type": "new_block",
                    "id": str(uuid.uuid4()),
                    "block": newBlock1.to_dict()
                }

                pkt2 = {
                    "type": "new_block",
                    "id": str(uuid.uuid4()),
                    "block": newBlock2.to_dict()
                }

                self.seen_message_ids.add(
                    pkt1["id"]
                )

                self.seen_message_ids.add(
                    pkt2["id"]
                )

                targets = list(
                    self.server_connections
                    | self.client_connections
                )

                midpoint = len(targets) // 2

                first_half = targets[:midpoint]
                second_half = targets[midpoint:]

                # Block 1 to first group
                for ws in first_half:

                    await self.send_message(
                        ws,
                        pkt1,
                        ws in self.client_connections
                    )

                # Block 2 to second group
                for ws in second_half:

                    await self.send_message(
                        ws,
                        pkt2,
                        ws in self.client_connections
                    )

                await self.restart_round_task()

                self.cleanup_old_miner_updates()

                new_miners_list = (
                    self.get_current_miners_list()
                )

                await self.update_role(
                    self.node_id in new_miners_list
                )

                if self.activate_disk_save == "y":
                    self.save_chain_to_disk()

        except asyncio.CancelledError:

            print(
                "Miner task stopped cleanly"
            )

            raise

        except Exception as e:

            print(
                f"Mining error: {e}"
            )

    # ========================================================
    # Chain synchronization
    # ========================================================

    async def find_longest_chain(self):

        while True:

            try:

                pkt = {
                    "type": "chain_request",
                    "id": str(uuid.uuid4())
                }

                self.seen_message_ids.add(
                    pkt["id"]
                )

                await self.broadcast_message(
                    pkt
                )

                print(
                    "\nSent out chain requests..."
                )

                await asyncio.sleep(60)

            except asyncio.CancelledError:
                raise

            except Exception as e:

                print(
                    f"Chain synchronization error: {e}"
                )

                await asyncio.sleep(5)

    # ========================================================
    # Start
    # ========================================================

    async def start(
        self,
        bootstrap_host=None,
        bootstrap_port=None
    ):

        server = None

        try:

            # IPFS setup before accepting file operations.
            try:

                self.init_repo()
                self.configure_ports()

            except Exception as e:

                print(
                    f"IPFS setup warning: {e}"
                )

            server = await websockets.serve(
                self.handle_connections,
                self.host,
                self.port
            )

            print(
                f"WebSocket server started on "
                f"{self.host}:{self.port}"
            )

            # ------------------------------------------------
            # Bootstrap / Genesis
            # ------------------------------------------------

            if bootstrap_host and bootstrap_port:

                normalized_bootstrap_host, normalized_bootstrap_port = (
                    normalize_endpoint(
                        (
                            bootstrap_host,
                            bootstrap_port
                        )
                    )
                )

                asyncio.create_task(
                    self.connect_to_peer(
                        normalized_bootstrap_host,
                        normalized_bootstrap_port
                    )
                )

            else:

                if not self.chain_available():

                    self.chain = Chain(
                        publicKey=self.wallet_public_key()
                    )

                    genesis = (
                        Chain.instance.chain[0]
                    )

                    genesis.miner_node_id = (
                        self.node_id
                    )

                    genesis.miner_public_key = (
                        self.wallet_public_key()
                    )

                    genesis.miners_list = [
                        self.node_id
                    ]

                    self.sign_block(
                        genesis
                    )

                    self.admin_id = (
                        self.node_id
                    )

                    print(
                        "Genesis block created."
                    )

                else:

                    self.chain = Chain.instance

                    genesis = (
                        Chain.instance.chain[0]
                    )

                    if genesis.miner_node_id:
                        self.admin_id = (
                            genesis.miner_node_id
                        )

                    current_miners = (
                        self.get_current_miners_list()
                    )

                    await self.update_role(
                        self.node_id in current_miners
                    )

            # ------------------------------------------------
            # Background tasks
            # ------------------------------------------------

            inp_task = asyncio.create_task(
                self.user_input_handler()
            )

            consensus_task = asyncio.create_task(
                self.find_longest_chain()
            )

            disc_task = asyncio.create_task(
                self.discover_peers()
            )

            sampler_task = asyncio.create_task(
                self.gossip_peer_sampler()
            )

            self.round_task = asyncio.create_task(
                self.round_calculator()
            )

            await inp_task

        except KeyboardInterrupt:

            print(
                "Keyboard interrupt received."
            )

        except Exception as e:

            print(
                f"Node stopped because of error: {e}"
            )

        finally:

            # Cancel background tasks safely.
            current = asyncio.current_task()

            for task_name in (
                "consensus_task",
                "disc_task",
                "sampler_task"
            ):

                task = locals().get(
                    task_name
                )

                if task and not task.done():

                    task.cancel()

                    try:
                        await task
                    except asyncio.CancelledError:
                        pass

            if (
                self.round_task
                and not self.round_task.done()
            ):

                self.round_task.cancel()

                try:
                    await self.round_task
                except asyncio.CancelledError:
                    pass

            await self.update_role(
                False
            )

            # Close connections.
            for ws in list(
                self.client_connections
                | self.server_connections
            ):

                await self.safe_close(
                    ws
                )

            if server:

                try:

                    server.close()

                    await server.wait_closed()

                except Exception:
                    pass

            self.stop_daemon()