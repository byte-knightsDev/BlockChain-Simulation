import asyncio
import websockets
import json
import uuid
import base64
import threading
import socket
import os
import subprocess
from typing import Set, Dict, List, Tuple
from consensus.pow.blockchain_structures import (
    Transaction,
    Block,
    Wallet,
    Chain,
    isvalidChain,
)
from ipfs.ipfs import addToIpfs, download_ipfs_file_subprocess
from smart_contract.contracts_db import SmartContractDatabase
from smart_contract.secure_executor import SecureContractExecutor
from storage.storage_manager import (
    save_key,
    load_key,
    save_chain,
    load_chain,
    save_peers,
    load_peers,
)
from ecdsa import VerifyingKey
from pathlib import Path
import tempfile
import ast
import hashlib
import random


MAX_CONNECTIONS = 8
GAS_PRICE = 0.001
BASE_DEPLOY_COST = 5
CONSENSUS = "pow"


def get_random_element(s):
    """
    Return a random element from a set.
    """
    return random.choice(list(s)) if s else None


def normalize_endpoint(ep):
    """
    Resolve host into IPv4 address and convert port to int.
    """
    host, port = ep
    return (socket.gethostbyname(host), int(port))


def get_contract_code_from_notepad():
    """
    Create a temporary Python file and open it in Windows Notepad.
    """

    with tempfile.NamedTemporaryFile(
        suffix=".py",
        delete=False,
        mode="w+",
        encoding="utf-8",
    ) as tmp_file:

        temp_filename = tmp_file.name

        tmp_file.write("# Write your smart contract function here.\n")
        tmp_file.write(
            "def contract_logic(parameter1, parameter2, parameter3, state):\n"
        )
        tmp_file.write("    # your code here\n")
        tmp_file.write("    return state, 'some message'\n")

    # Windows uses Notepad instead of gedit
    subprocess.call(["notepad.exe", temp_filename])

    with open(temp_filename, "r", encoding="utf-8") as f:
        contract_code = f.read()

    try:
        os.remove(temp_filename)
    except OSError:
        pass

    return contract_code


class Peer:

    def __init__(
        self,
        host,
        port,
        name,
        miner: bool,
        activate_disk_load,
        activate_disk_save,
    ):

        self.host = host
        self.name = name
        self.miner = miner

        self.activate_disk_save = activate_disk_save

        self.port = int(port)

        self.ipfs_port = self.port + 50
        self.gateway_port = self.port + 81
        self.swarm_tcp = self.port + 2
        self.swarm_udp = self.port + 3

        self.repo_path = Path.home() / f".ipfs_{self.port}"

        self.env = os.environ.copy()
        self.env["IPFS_PATH"] = str(self.repo_path)

        # Incoming websocket connections
        self.server_connections = set()

        # Outgoing websocket connections
        self.client_connections = set()

        # Peers to which we currently maintain outbound connections
        self.outbound_peers: Set[tuple] = set()

        # Message IDs already processed
        self.seen_message_ids: Set[str] = set()

        # Load known peers
        if activate_disk_load == "y":
            self.load_known_peers_from_disk()
        else:
            self.known_peers = None

        if not self.known_peers:
            self.known_peers = {}

        """
        known_peers format:

        {
            (host, port): (name, public_key)
        }
        """

        # Pong tracking
        self.got_pong = {}

        # Peer-info handshake tracking
        self.have_sent_peer_info = {}

        # Transaction memory pool
        self.mem_pool: List[Transaction] = []

        # IPFS file hashes
        self.file_hashes: Dict[str, str] = {}
        self.file_hashes_lock = asyncio.Lock()

        self.daemon_process = None

        # Name -> public key
        self.name_to_public_key_dict: Dict[str, str] = {}

        # Load wallet
        if activate_disk_load == "y":
            self.load_key_from_disk()
        else:
            self.wallet = None

        if not self.wallet:
            self.wallet = Wallet()

            if self.activate_disk_save == "y":
                self.save_key_to_disk()

        # Load blockchain
        if activate_disk_load == "y":
            self.load_chain_from_disk()
        else:
            self.chain = None

        self.contractsDB = SmartContractDatabase()

        self.mem_pool_condition = asyncio.Condition()

        self.mine_task = None

    # ------------------------------------------------------------------
    # STORAGE
    # ------------------------------------------------------------------

    def save_key_to_disk(self):
        key = self.wallet.private_key_pem
        save_key(key, CONSENSUS)

    def load_key_from_disk(self):

        key = load_key(CONSENSUS)

        if not key:
            self.wallet = None
            return

        self.wallet = Wallet(key)

    def load_chain_from_disk(self):

        block_dict_list = load_chain(CONSENSUS)

        if not block_dict_list:
            self.chain = None
            return

        block_list: List[Block] = []

        for block_dict in block_dict_list:
            block = self.block_dict_to_block(block_dict)
            block_list.append(block)

        self.chain = Chain(blockList=block_list)

    def save_chain_to_disk(self):

        if Chain.instance is None:
            return

        chain = Chain.instance.to_block_dict_list()
        save_chain(chain, CONSENSUS)

    def save_known_peers_to_disk(self):

        content = {}

        for key, value in self.known_peers.items():
            content[json.dumps(key)] = list(value)

        save_peers(content, CONSENSUS)

    def load_known_peers_from_disk(self):

        content = load_peers(CONSENSUS)

        if not content:
            self.known_peers = None
            return

        self.known_peers = {}

        for key, value in content.items():

            endpoint = tuple(ast.literal_eval(key))
            self.known_peers[endpoint] = tuple(value)

            if len(value) >= 2:
                self.name_to_public_key_dict[value[0].lower()] = value[1]

    # ------------------------------------------------------------------
    # PEER INFORMATION
    # ------------------------------------------------------------------

    async def send_peer_info(self, websocket):

        pkt = {
            "type": "peer_info",
            "id": str(uuid.uuid4()),
            "data": {
                "host": self.host,
                "port": self.port,
                "name": self.name,
                "public_key": public_key_to_string(self.wallet.public_key),
            },
        }

        self.seen_message_ids.add(pkt["id"])

        await websocket.send(json.dumps(pkt))

    async def send_known_peers(self, websocket):

        peers = [
            {
                "host": h,
                "port": p,
                "name": n,
                "public_key": s,
            }
            for (h, p), (n, s) in self.known_peers.items()
        ]

        peers.append(
            {
                "host": self.host,
                "port": self.port,
                "name": self.name,
                "public_key": public_key_to_string(self.wallet.public_key),
            }
        )

        pkt = {
            "type": "known_peers",
            "id": str(uuid.uuid4()),
            "peers": peers,
        }

        self.seen_message_ids.add(pkt["id"])

        await websocket.send(json.dumps(pkt))

    # ------------------------------------------------------------------
    # BLOCK CONVERSION
    # ------------------------------------------------------------------

    def block_dict_to_block(self, block_dict):

        new_block_id = block_dict["id"]
        new_block_prevHash = block_dict["prevHash"]
        new_block_ts = block_dict["ts"]
        new_block_nonce = block_dict["nonce"]

        transactions = []

        for transaction_dict in block_dict["transactions"]:

            transaction = Transaction(
                transaction_dict["payload"],
                transaction_dict["sender"],
                transaction_dict["receiver"],
                transaction_dict["id"],
                transaction_dict["ts"],
            )

            if transaction.sender != "Genesis":

                signature = transaction_dict.get("sign")

                if signature:
                    transaction.sign = base64.b64decode(signature)

            transactions.append(transaction)

        newBlock = Block(
            new_block_prevHash,
            transactions,
            new_block_ts,
            new_block_nonce,
            new_block_id,
        )

        newBlock.files = block_dict.get("files", {})

        return newBlock

    # ------------------------------------------------------------------
    # SMART CONTRACT VALIDATION
    # ------------------------------------------------------------------

    def valid_deploy_transaction(self, payload):

        if not payload or len(payload) < 2:
            return False

        contract_code = payload[0]

        gas_used = len(contract_code) // 10 + BASE_DEPLOY_COST
        amount = gas_used * GAS_PRICE

        return amount == payload[-1]

    def valid_invoke_transaction(self, payload):

        if not payload or len(payload) < 5:
            return False

        try:

            contract_id = payload[0]
            func_name = payload[1]
            args = payload[2]

            response = self.run_contract(
                [contract_id, func_name, args]
            )

            if response.get("error") is not None:
                return False

            state = response["state"]
            gas_used = response["gas_used"]

            amount = gas_used * GAS_PRICE

            if state != payload[3]:
                return False

            if amount != payload[-1]:
                return False

            return True

        except Exception as e:

            print(f"Contract validation error: {e}")
            return False

    # ------------------------------------------------------------------
    # PEER NAME
    # ------------------------------------------------------------------

    def get_unique_name(self, base_name):

        existing_names = []

        for key, value in self.known_peers.items():
            existing_names.append(value[0].lower())

        existing_names.append(self.name.lower())

        base_name = base_name.lower()

        if base_name not in existing_names:
            return base_name

        counter = 1

        while True:

            new_name = f"{base_name}{counter}"

            if new_name not in existing_names:
                return new_name

            counter += 1

    # ------------------------------------------------------------------
    # MESSAGE HANDLING
    # ------------------------------------------------------------------

    async def handle_messages(self, websocket, msg):

        t = msg.get("type")
        msg_id = msg.get("id")

        if not t or not msg_id:
            return

        if msg_id in self.seen_message_ids:
            return

        self.seen_message_ids.add(msg_id)

        # --------------------------------------------------------------
        # PING
        # --------------------------------------------------------------

        if t == "ping":

            pkt = {
                "type": "pong",
                "id": str(uuid.uuid4()),
            }

            self.seen_message_ids.add(pkt["id"])

            await websocket.send(json.dumps(pkt))

        # --------------------------------------------------------------
        # PONG
        # --------------------------------------------------------------

        elif t == "pong":

            self.got_pong[websocket] = True

            if not self.have_sent_peer_info.get(websocket, True):

                await self.send_peer_info(websocket)

                self.have_sent_peer_info[websocket] = True

        # --------------------------------------------------------------
        # PEER INFO
        # --------------------------------------------------------------

        elif t == "peer_info":

            data = msg["data"]

            normalized_self = normalize_endpoint(
                (self.host, self.port)
            )

            normalized_endpoint = normalize_endpoint(
                (data["host"], data["port"])
            )

            # FIXED:
            # Previously this incorrectly compared normalize_endpoint
            # (the function itself) instead of normalized_endpoint.
            if (
                normalized_endpoint not in self.known_peers
                and normalized_endpoint != normalized_self
            ):

                self.known_peers[normalized_endpoint] = (
                    data["name"],
                    data["public_key"],
                )

                if self.activate_disk_save == "y":
                    self.save_known_peers_to_disk()

                self.name_to_public_key_dict[
                    data["name"].lower()
                ] = data["public_key"]

                print(
                    f"Registered peer {data['name']} "
                    f"{data['host']}:{data['port']}"
                )

                await self.send_known_peers(websocket)

        # --------------------------------------------------------------
        # ADD PEER
        # --------------------------------------------------------------

        elif t == "add_peer":

            data = msg["data"]

            normalized_self = normalize_endpoint(
                (self.host, self.port)
            )

            normalized_endpoint = normalize_endpoint(
                (data["host"], data["port"])
            )

            new_peer_msg_id = str(uuid.uuid4())

            if (
                normalized_endpoint not in self.known_peers
                and normalized_endpoint != normalized_self
            ):

                proposed_name = self.get_unique_name(
                    data["name"]
                )

                if proposed_name != data["name"]:

                    pkt = {
                        "type": "change_name",
                        "id": str(uuid.uuid4()),
                        "new_peer_msg_id": new_peer_msg_id,
                        "new_name": proposed_name,
                    }

                    await websocket.send(json.dumps(pkt))

                    data["name"] = proposed_name

                self.known_peers[normalized_endpoint] = (
                    data["name"],
                    data["public_key"],
                )

                if self.activate_disk_save == "y":
                    self.save_known_peers_to_disk()

                self.name_to_public_key_dict[
                    data["name"].lower()
                ] = data["public_key"]

                print(
                    f"Registered peer {data['name']} "
                    f"{data['host']}:{data['port']}"
                )

                await self.send_known_peers(websocket)

                pkt = {
                    "type": "new_peer",
                    "id": new_peer_msg_id,
                    "data": {
                        "host": data["host"],
                        "port": data["port"],
                        "name": data["name"],
                        "public_key": data["public_key"],
                    },
                }

                self.seen_message_ids.add(pkt["id"])

                await self.broadcast_message(pkt)

        # --------------------------------------------------------------
        # NEW PEER
        # --------------------------------------------------------------

        elif t == "new_peer":

            data = msg["data"]

            normalized_self = normalize_endpoint(
                (self.host, self.port)
            )

            normalized_endpoint = normalize_endpoint(
                (data["host"], data["port"])
            )

            if (
                normalized_endpoint not in self.known_peers
                and normalized_endpoint != normalized_self
            ):

                self.known_peers[normalized_endpoint] = (
                    data["name"],
                    data["public_key"],
                )

                if self.activate_disk_save == "y":
                    self.save_known_peers_to_disk()

                self.name_to_public_key_dict[
                    data["name"].lower()
                ] = data["public_key"]

                print(
                    f"Registered peer {data['name']} "
                    f"{data['host']}:{data['port']}"
                )

                await self.broadcast_message(msg)

        # --------------------------------------------------------------
        # CHANGE NAME
        # --------------------------------------------------------------

        elif t == "change_name":

            new_name = msg["new_name"]

            self.name = new_name

            if "new_peer_msg_id" in msg:
                self.seen_message_ids.add(
                    msg["new_peer_msg_id"]
                )

        # --------------------------------------------------------------
        # KNOWN PEERS
        # --------------------------------------------------------------

        elif t == "known_peers":

            peers = msg["peers"]

            new_peer_found = False

            for peer in peers:

                normalized_self = normalize_endpoint(
                    (self.host, self.port)
                )

                normalized_endpoint = normalize_endpoint(
                    (peer["host"], peer["port"])
                )

                if (
                    normalized_endpoint not in self.known_peers
                    and normalized_endpoint != normalized_self
                ):

                    print(
                        f"Discovered peer {peer['name']} "
                        f"at {peer['host']}:{peer['port']}"
                    )

                    new_peer_found = True

                    self.known_peers[normalized_endpoint] = (
                        peer["name"],
                        peer["public_key"],
                    )

                    self.name_to_public_key_dict[
                        peer["name"].lower()
                    ] = peer["public_key"]

            if new_peer_found:

                if self.activate_disk_save == "y":
                    self.save_known_peers_to_disk()

            pkt = {
                "type": "chain_request",
                "id": str(uuid.uuid4()),
            }

            self.seen_message_ids.add(pkt["id"])

            await websocket.send(json.dumps(pkt))

        # --------------------------------------------------------------
        # FILE
        # --------------------------------------------------------------

        elif t == "file":

            cid = msg["cid"]
            desc = msg["desc"]

            async with self.file_hashes_lock:
                self.file_hashes[cid] = desc

            await self.broadcast_message(msg)

        # --------------------------------------------------------------
        # NEW TRANSACTION
        # --------------------------------------------------------------

        elif t == "new_tx":

            try:

                tx_str = msg["transaction"]

                tx = json.loads(tx_str)

                transaction = Transaction(
                    tx["payload"],
                    tx["sender"],
                    tx["receiver"],
                    tx["id"],
                    tx["ts"],
                )

                if Chain.instance is None:
                    return

                if Chain.instance.transaction_exists_in_chain(
                    transaction
                ):
                    print(
                        f"{self.name} Transaction already exists in chain"
                    )
                    return

                sign_bytes = base64.b64decode(
                    msg["sign"]
                )

                if transaction.receiver == "deploy":

                    if not self.valid_deploy_transaction(
                        transaction.payload
                    ):
                        print("Invalid deploy transaction")
                        return

                if transaction.receiver == "invoke":

                    if not self.valid_invoke_transaction(
                        transaction.payload
                    ):
                        print("Invalid invoke transaction")
                        return

                if (
                    transaction.receiver == "deploy"
                    or transaction.receiver == "invoke"
                ):
                    amount = transaction.payload[-1]
                else:
                    amount = transaction.payload

                if amount <= 0:
                    print(
                        "\nInvalid Transaction, amount <= 0\n"
                    )
                    return

                if amount > Chain.instance.calc_balance(
                    transaction.sender,
                    self.mem_pool,
                ):
                    print(
                        "\nAttempt to spend more than one has. "
                        "Invalid transaction.\n"
                    )
                    return

                try:

                    public_key = VerifyingKey.from_pem(
                        tx["sender"].encode()
                    )

                    public_key.verify(
                        sign_bytes,
                        tx_str.encode(),
                    )

                except Exception:

                    print("Invalid Signature")
                    return

                transaction.sign = sign_bytes

                print("\nValid Transaction")
                print(
                    f"\n{msg['type']}: {msg['transaction']}"
                )
                print()

                async with self.mem_pool_condition:

                    if not Chain.instance.transaction_exists_in_chain(
                        transaction
                    ):
                        self.mem_pool.append(transaction)

                await self.broadcast_message(msg)

            except Exception as e:

                print(
                    f"Error handling transaction: {e}"
                )

        # --------------------------------------------------------------
        # NEW BLOCK
        # --------------------------------------------------------------

        elif t == "new_block":

            try:

                new_block_dict = msg["block"]

                newBlock = self.block_dict_to_block(
                    new_block_dict
                )

                if Chain.instance is None:
                    return

                if not Chain.instance.isValidBlock(newBlock):

                    print("\nInvalid Block\n")
                    return

                for transaction in newBlock.transactions:

                    if transaction.receiver == "invoke":

                        if not self.valid_invoke_transaction(
                            transaction.payload
                        ):
                            print(
                                "Invalid invoke transaction in block"
                            )
                            return

                    if transaction.receiver == "deploy":

                        if not self.valid_deploy_transaction(
                            transaction.payload
                        ):
                            print(
                                "Invalid deploy transaction in block"
                            )
                            return

                newBlock.miner = msg.get(
                    "miner",
                    self.wallet.public_key,
                )

                Chain.instance.chain.append(newBlock)

                print("\n\nBlock Appended\n")

                for transaction in newBlock.transactions:

                    if transaction.receiver == "deploy":
                        self.deploy_contract(transaction)

                # Remove transactions already included in block
                async with self.mem_pool_condition:

                    self.mem_pool = [
                        transaction
                        for transaction in self.mem_pool
                        if not newBlock.transaction_exists_in_block(
                            transaction
                        )
                    ]

                # Remove included files
                async with self.file_hashes_lock:

                    for file_hash in list(
                        self.file_hashes.keys()
                    ):

                        if newBlock.cid_exists_in_block(
                            file_hash
                        ):
                            self.file_hashes.pop(
                                file_hash,
                                None,
                            )

                # Cancel current mining task
                if (
                    self.miner
                    and self.mine_task
                    and not self.mine_task.done()
                ):

                    self.mine_task.cancel()

                    print(
                        "New Block received. "
                        "Cancelled Mining..."
                    )

                # Start mining again
                if self.miner:

                    self.mine_task = asyncio.create_task(
                        self.mine_blocks()
                    )

                await self.broadcast_message(msg)

                if self.activate_disk_save == "y":
                    self.save_chain_to_disk()

            except Exception as e:

                print(
                    f"Error handling new block: {e}"
                )

        # --------------------------------------------------------------
        # CHAIN REQUEST
        # --------------------------------------------------------------

        elif t == "chain_request":

            if Chain.instance is None:
                return

            pkt = {
                "type": "chain",
                "id": str(uuid.uuid4()),
                "chain": Chain.instance.to_block_dict_list(),
            }

            self.seen_message_ids.add(pkt["id"])

            await websocket.send(json.dumps(pkt))

        # --------------------------------------------------------------
        # CHAIN
        # --------------------------------------------------------------

        elif t == "chain":

            try:

                print("Received a Chain")

                block_dict_list = msg["chain"]

                block_list: List[Block] = []

                for block_dict in block_dict_list:

                    block = self.block_dict_to_block(
                        block_dict
                    )

                    block_list.append(block)

                # FIX:
                # Invalid chain must not continue into replacement.
                if not isvalidChain(block_list):

                    print("\nInvalid Chain\n")
                    return

                if Chain.instance is None:

                    self.chain = Chain(
                        blockList=block_list
                    )

                    if self.activate_disk_save == "y":
                        self.save_chain_to_disk()

                    return

                elif len(Chain.instance.chain) < len(
                    block_list
                ):

                    Chain.instance.rewrite(
                        block_list
                    )

                    print(
                        "\nCurrent chain replaced by "
                        "longer chain"
                    )

                    if self.activate_disk_save == "y":
                        self.save_chain_to_disk()

                else:

                    print(
                        "\nCurrent Chain Longer than "
                        "received chain"
                    )

                async with self.mem_pool_condition:

                    self.mem_pool = [
                        transaction
                        for transaction in self.mem_pool
                        if not Chain.instance.transaction_exists_in_chain(
                            transaction
                        )
                    ]

                async with self.file_hashes_lock:

                    for file_hash in list(
                        self.file_hashes.keys()
                    ):

                        if Chain.instance.cid_exists_in_chain(
                            file_hash
                        ):
                            self.file_hashes.pop(
                                file_hash,
                                None,
                            )

            except Exception as e:

                print(
                    f"Error handling chain: {e}"
                )

    # ------------------------------------------------------------------
    # CONNECTION HANDLING
    # ------------------------------------------------------------------

    async def handle_connections(self, websocket):

        remote = websocket.remote_address

        if remote:
            peer_addr = (
                remote[0],
                remote[1],
            )
        else:
            peer_addr = ("unknown", 0)

        self.server_connections.add(websocket)

        print(
            f"Inbound Connection from "
            f"{peer_addr[0]}:{peer_addr[1]}"
        )

        try:

            async for raw in websocket:

                try:
                    msg = json.loads(raw)

                    await self.handle_messages(
                        websocket,
                        msg,
                    )

                except json.JSONDecodeError:

                    print(
                        "Received invalid JSON"
                    )

                except Exception as e:

                    print(
                        f"Message handling error: {e}"
                    )

        except websockets.exceptions.ConnectionClosed:

            print(
                f"Inbound Connection Closed: "
                f"{peer_addr}"
            )

        finally:

            self.server_connections.discard(
                websocket
            )

            try:
                await websocket.close()
            except Exception:
                pass

    # ------------------------------------------------------------------
    # BROADCAST
    # ------------------------------------------------------------------

    async def broadcast_message(self, pkt):

        targets = (
            self.server_connections
            | self.client_connections
        )

        for ws in list(targets):

            try:

                await ws.send(
                    json.dumps(pkt)
                )

            except Exception as e:

                print(
                    f"Error broadcasting: {e}"
                )

                if ws in self.server_connections:

                    self.server_connections.discard(
                        ws
                    )

                else:

                    try:

                        remote = ws.remote_address

                        if remote:

                            normalized_endpoint = (
                                normalize_endpoint(
                                    (
                                        remote[0],
                                        remote[1],
                                    )
                                )
                            )

                            self.outbound_peers.discard(
                                normalized_endpoint
                            )

                    except Exception:
                        pass

                    self.client_connections.discard(
                        ws
                    )

                    self.got_pong.pop(
                        ws,
                        None,
                    )

                    self.have_sent_peer_info.pop(
                        ws,
                        None,
                    )

                try:
                    await ws.close()
                except Exception:
                    pass

    # ------------------------------------------------------------------
    # TRANSACTION CREATION
    # ------------------------------------------------------------------

    async def create_and_broadcast_tx(
        self,
        receiver_public_key,
        payload,
    ):

        transaction = Transaction(
            payload,
            self.wallet.public_key,
            receiver_public_key,
        )

        transaction_str = str(transaction)

        signature = self.wallet.private_key.sign(
            transaction_str.encode()
        )

        signature_b64 = base64.b64encode(
            signature
        ).decode()

        pkt = {
            "type": "new_tx",
            "id": str(uuid.uuid4()),
            "transaction": transaction_str,
            "sign": signature_b64,
            "sender_pem": self.wallet.public_key,
        }

        self.seen_message_ids.add(
            pkt["id"]
        )

        if Chain.instance is None:
            return

        if Chain.instance.transaction_exists_in_chain(
            transaction
        ):
            return

        async with self.mem_pool_condition:

            self.mem_pool.append(
                transaction
            )

        transaction.sign = signature

        print(
            "Transaction Created",
            transaction,
        )

        print()

        await self.broadcast_message(pkt)

    # ------------------------------------------------------------------
    # SMART CONTRACT STATE
    # ------------------------------------------------------------------

    def get_contract_state(self, contract_id):

        if Chain.instance is None:
            return {}

        for block in reversed(
            Chain.instance.chain
        ):

            for transaction in reversed(
                block.transactions
            ):

                if (
                    transaction.receiver == "invoke"
                    and transaction.payload[0]
                    == contract_id
                ):

                    return transaction.payload[3]

        return {}

    # ------------------------------------------------------------------
    # USER INPUT
    # ------------------------------------------------------------------

    async def user_input_handler(self):

        while True:

            print(
                "\nBlock Chain Menu\n"
                "****************\n"
                "1) Add Transaction\n"
                "2) View balance\n"
                "3) Print Chain\n"
                "4) Print Pending Transactions\n"
                "5) Send Files\n"
                "6) Download Files\n"
                "7) Quit\n"
            )

            loop = asyncio.get_running_loop()

            ch = await loop.run_in_executor(
                None,
                input,
                "Enter Your Choice: ",
            )

            try:
                ch = int(ch)
            except ValueError:

                print(
                    "\nPlease enter a valid number!!!\n"
                )

                continue

            if ch == 1:

                rec = await loop.run_in_executor(
                    None,
                    input,
                    "\nEnter Receiver's Name or Public Key: ",
                )

                # ------------------------------------------------------
                # DEPLOY
                # ------------------------------------------------------

                if rec.strip().lower() == "deploy":

                    contract_code = (
                        get_contract_code_from_notepad()
                    )

                    if not contract_code.strip():

                        print(
                            "Contract code field is empty"
                        )

                        continue

                    gas_used = (
                        len(contract_code) // 10
                        + BASE_DEPLOY_COST
                    )

                    amount = gas_used * GAS_PRICE

                    payload = [
                        contract_code,
                        amount,
                    ]

                    if (
                        Chain.instance
                        and amount
                        <= Chain.instance.calc_balance(
                            self.wallet.public_key,
                            self.mem_pool,
                        )
                    ):

                        await self.create_and_broadcast_tx(
                            "deploy",
                            payload,
                        )

                    else:

                        print(
                            "Insufficient Account Balance"
                        )

                # ------------------------------------------------------
                # INVOKE
                # ------------------------------------------------------

                elif rec.strip().lower() == "invoke":

                    contract_id = await loop.run_in_executor(
                        None,
                        input,
                        "\nEnter Contract Id: ",
                    )

                    if (
                        contract_id
                        not in self.contractsDB.contracts
                    ):

                        print(
                            "No such contract found..."
                        )

                        continue

                    func_name = await loop.run_in_executor(
                        None,
                        input,
                        "\nEnter Function Name: ",
                    )

                    args = []

                    arg_number = 1

                    while True:

                        arg = await loop.run_in_executor(
                            None,
                            input,
                            f"Enter argument {arg_number} "
                            "(or \\q to finish): ",
                        )

                        if arg.strip() == "\\q":
                            break

                        try:
                            parsed_arg = ast.literal_eval(
                                arg
                            )
                        except Exception:
                            parsed_arg = arg

                        args.append(parsed_arg)

                        arg_number += 1

                    try:

                        response = self.run_contract(
                            [
                                contract_id,
                                func_name,
                                args,
                            ]
                        )

                    except Exception as e:

                        print(
                            "Error:",
                            e,
                        )

                        continue

                    if response.get("error") is not None:

                        print(
                            "Error:",
                            response["error"],
                        )

                        continue

                    state = response["state"]
                    gas_used = response["gas_used"]

                    amount = gas_used * GAS_PRICE

                    payload = [
                        contract_id,
                        func_name,
                        args,
                        state,
                        amount,
                    ]

                    if (
                        Chain.instance
                        and amount
                        <= Chain.instance.calc_balance(
                            self.wallet.public_key,
                            self.mem_pool,
                        )
                    ):

                        await self.create_and_broadcast_tx(
                            "invoke",
                            payload,
                        )

                    else:

                        print(
                            "Insufficient Account Balance"
                        )

                # ------------------------------------------------------
                # NORMAL TRANSACTION
                # ------------------------------------------------------

                else:

                    amt = await loop.run_in_executor(
                        None,
                        input,
                        "\nEnter Amount to send: ",
                    )

                    receiver_public_key = (
                        self.name_to_public_key_dict.get(
                            rec.lower().strip()
                        )
                    )

                    if receiver_public_key is None:

                        rec_split = rec.split("\\n")

                        rec_refined = "\n".join(
                            rec_split
                        )

                        for (
                            nme,
                            pk,
                        ) in self.name_to_public_key_dict.items():

                            if pk == rec_refined:

                                receiver_public_key = pk

                                break

                    if receiver_public_key is None:

                        print(
                            "No person available in directory "
                            "with provided name or public key..."
                        )

                        continue

                    try:

                        amt = float(amt)

                    except ValueError:

                        print(
                            "Amount must be a number"
                        )

                        continue

                    if amt <= 0:

                        print(
                            "\nAmount must be positive\n"
                        )

                        continue

                    await self.create_and_broadcast_tx(
                        receiver_public_key,
                        amt,
                    )

            # ----------------------------------------------------------
            # BALANCE
            # ----------------------------------------------------------

            elif ch == 2:

                if Chain.instance is None:

                    print(
                        "Blockchain has not been initialized."
                    )

                    continue

                print(
                    "Account Balance =",
                    Chain.instance.calc_balance(
                        self.wallet.public_key,
                        self.mem_pool,
                    ),
                )

            # ----------------------------------------------------------
            # PRINT CHAIN
            # ----------------------------------------------------------

            elif ch == 3:

                if Chain.instance is None:

                    print(
                        "Blockchain has not been initialized."
                    )

                    continue

                for i, block in enumerate(
                    Chain.instance.chain
                ):

                    print(
                        f"block{i}: {block}\n"
                    )

            # ----------------------------------------------------------
            # PRINT MEMPOOL
            # ----------------------------------------------------------

            elif ch == 4:

                for i, transaction in enumerate(
                    self.mem_pool
                ):

                    print(
                        f"transaction{i}: "
                        f"{transaction}\n\n"
                    )

            # ----------------------------------------------------------
            # UPLOAD FILE
            # ----------------------------------------------------------

            elif ch == 5:

                desc = await loop.run_in_executor(
                    None,
                    input,
                    "\nEnter description of file: ",
                )

                path = await loop.run_in_executor(
                    None,
                    input,
                    "\nEnter path of file: ",
                )

                pkt = await self.uploadFile(
                    desc,
                    path,
                )

                if pkt:

                    await self.broadcast_message(
                        pkt
                    )

            # ----------------------------------------------------------
            # DOWNLOAD FILE
            # ----------------------------------------------------------

            elif ch == 6:

                cid = await loop.run_in_executor(
                    None,
                    input,
                    "\nEnter cid of file: ",
                )

                path = await loop.run_in_executor(
                    None,
                    input,
                    "\nEnter path to download the file: ",
                )

                try:

                    download_ipfs_file_subprocess(
                        cid,
                        path,
                    )

                except Exception as e:

                    print(
                        f"Download failed: {e}"
                    )

            # ----------------------------------------------------------
            # QUIT
            # ----------------------------------------------------------

            elif ch == 7:

                print(
                    "Quitting..."
                )

                break

            else:

                print(
                    "\nPlease enter a number from 1 to 7.\n"
                )

    # ------------------------------------------------------------------
    # IPFS
    # ------------------------------------------------------------------

    async def uploadFile(
        self,
        desc: str,
        path: str,
    ):

        file_path = Path(path)

        if not file_path.is_file():

            print(
                "\nFile doesn't exist\n"
            )

            return None

        if not self.daemon_process:

            self.start_daemon()

        try:

            cid, name = await asyncio.to_thread(
                addToIpfs,
                path,
            )

        except Exception as e:

            print(
                f"IPFS upload failed: {e}"
            )

            return None

        if not cid or not name:
            return None

        print(
            f"\nNew File Created : {cid}\n"
        )

        pkt = {
            "type": "file",
            "id": str(uuid.uuid4()),
            "desc": desc,
            "cid": cid,
        }

        self.seen_message_ids.add(
            pkt["id"]
        )

        async with self.file_hashes_lock:

            self.file_hashes[cid] = desc

        return pkt

    def init_repo(self):

        """
        Create IPFS repository if it does not exist.
        """

        if not self.repo_path.exists():

            subprocess.run(
                ["ipfs", "init"],
                env=self.env,
                check=True,
            )

            print(
                "\nIPFS repo created\n"
            )

    def configure_ports(self):

        subprocess.run(
            [
                "ipfs",
                "config",
                "Addresses.API",
                f"/ip4/127.0.0.1/tcp/{self.ipfs_port}",
            ],
            env=self.env,
            check=True,
        )

        subprocess.run(
            [
                "ipfs",
                "config",
                "Addresses.Gateway",
                f"/ip4/127.0.0.1/tcp/{self.gateway_port}",
            ],
            env=self.env,
            check=True,
        )

        subprocess.run(
            [
                "ipfs",
                "config",
                "Addresses.Swarm",
                "--json",
                (
                    f'["/ip4/127.0.0.1/tcp/{self.swarm_tcp}", '
                    f'"/ip4/127.0.0.1/udp/{self.swarm_udp}/quic"]'
                ),
            ],
            env=self.env,
            check=True,
        )

        print(
            "\nConfigured Ports\n"
        )

    def start_daemon(self):

        self.daemon_process = subprocess.Popen(
            ["ipfs", "daemon"],
            env=self.env,
        )

        print(
            "\nIPFS Daemon Started\n"
        )

    def stop_daemon(self):

        if self.daemon_process:

            self.daemon_process.terminate()

            try:
                self.daemon_process.wait(
                    timeout=5
                )
            except subprocess.TimeoutExpired:

                self.daemon_process.kill()

            self.daemon_process = None

    # ------------------------------------------------------------------
    # CONNECT TO PEER
    # ------------------------------------------------------------------

    async def connect_to_peer(
        self,
        host,
        port,
    ):

        endpoint = (
            host,
            int(port),
        )

        if (
            endpoint in self.outbound_peers
            or endpoint == (self.host, self.port)
        ):
            return

        uri = f"ws://{host}:{port}"

        websocket = None

        try:

            websocket = await websockets.connect(
                uri
            )

            self.client_connections.add(
                websocket
            )

            self.outbound_peers.add(
                endpoint
            )

            self.have_sent_peer_info[
                websocket
            ] = False

            print(
                f"Outbound connection formed to "
                f"{host}:{port}"
            )

            if Chain.instance is None:

                pkt = {
                    "type": "add_peer",
                    "id": str(uuid.uuid4()),
                    "data": {
                        "host": self.host,
                        "port": self.port,
                        "name": self.name,
                        "public_key": self.wallet.public_key,
                    },
                }

            else:

                pkt = {
                    "type": "ping",
                    "id": str(uuid.uuid4()),
                }

            self.seen_message_ids.add(
                pkt["id"]
            )

            await websocket.send(
                json.dumps(pkt)
            )

            async for raw in websocket:

                try:

                    msg = json.loads(raw)

                    await self.handle_messages(
                        websocket,
                        msg,
                    )

                except json.JSONDecodeError:

                    print(
                        "Received invalid JSON"
                    )

        except Exception as e:

            print(
                f"Failed to connect to "
                f"{host}:{port} ::: {e}"
            )

        finally:

            if websocket:

                self.client_connections.discard(
                    websocket
                )

                self.outbound_peers.discard(
                    endpoint
                )

                self.got_pong.pop(
                    websocket,
                    None,
                )

                self.have_sent_peer_info.pop(
                    websocket,
                    None,
                )

                try:
                    await websocket.close()
                except Exception:
                    pass

    # ------------------------------------------------------------------
    # PEER DISCOVERY
    # ------------------------------------------------------------------

    async def discover_peers(self):

        """
        Maintain up to MAX_CONNECTIONS outbound peers.
        """

        while True:

            if len(self.outbound_peers) < MAX_CONNECTIONS:

                potential_peers = {
                    endpoint
                    for endpoint in self.known_peers
                    if (
                        endpoint
                        not in self.outbound_peers
                        and endpoint
                        != (self.host, self.port)
                    )
                }

                while (
                    len(self.outbound_peers)
                    < MAX_CONNECTIONS
                    and potential_peers
                ):

                    new_peer = get_random_element(
                        potential_peers
                    )

                    potential_peers.discard(
                        new_peer
                    )

                    if new_peer:

                        asyncio.create_task(
                            self.connect_to_peer(
                                *new_peer
                            )
                        )

                        await asyncio.sleep(1)

            await asyncio.sleep(30)

    # ------------------------------------------------------------------
    # GOSSIP PEER SAMPLER
    # ------------------------------------------------------------------

    async def gossip_peer_sampler(self):

        """
        Every 60 seconds, drop one existing peer
        and connect to another known peer.
        """

        while True:

            await asyncio.sleep(60)

            if (
                len(self.known_peers)
                <= len(self.outbound_peers)
                or len(self.outbound_peers)
                < MAX_CONNECTIONS
            ):
                continue

            to_drop = get_random_element(
                self.client_connections
            )

            if to_drop:

                print(
                    "Gossip Sampling: "
                    f"Disconnecting "
                    f"{to_drop.remote_address}"
                )

                self.client_connections.discard(
                    to_drop
                )

                try:

                    remote = to_drop.remote_address

                    normalized_endpoint = (
                        normalize_endpoint(
                            (
                                remote[0],
                                remote[1],
                            )
                        )
                    )

                    self.outbound_peers.discard(
                        normalized_endpoint
                    )

                except Exception:
                    pass

                self.got_pong.pop(
                    to_drop,
                    None,
                )

                self.have_sent_peer_info.pop(
                    to_drop,
                    None,
                )

                try:
                    await to_drop.close()
                except Exception:
                    pass

            potential_peers = {
                endpoint
                for endpoint in self.known_peers
                if (
                    endpoint
                    not in self.outbound_peers
                    and endpoint
                    != (self.host, self.port)
                )
            }

            if potential_peers:

                new_peer = get_random_element(
                    potential_peers
                )

                if new_peer:

                    print(
                        "Gossip Sampling: "
                        f"Connecting to new peer "
                        f"{new_peer}"
                    )

                    asyncio.create_task(
                        self.connect_to_peer(
                            *new_peer
                        )
                    )

    # ------------------------------------------------------------------
    # MINING
    # ------------------------------------------------------------------

    async def mine_blocks(self):

        """
        Mine blocks whenever there are transactions
        available in the mempool.

        This retains your original two-block test behaviour.
        """

        while True:

            await asyncio.sleep(30)

            if Chain.instance is None:
                continue

            async with self.mem_pool_condition:

                transaction_list = []

                # FIX:
                # Don't remove items from mem_pool while iterating
                # over the same list.
                cleaned_mem_pool = []

                for transaction in self.mem_pool:

                    if Chain.instance.transaction_exists_in_chain(
                        transaction
                    ):
                        continue

                    transaction_list.append(
                        transaction
                    )

                    cleaned_mem_pool.append(
                        transaction
                    )

                self.mem_pool = cleaned_mem_pool

                if (
                    len(transaction_list) <= 0
                    or len(self.name_to_public_key_dict) <= 1
                ):
                    continue

                values_iter = iter(
                    self.name_to_public_key_dict.values()
                )

                pk1 = next(
                    values_iter,
                    None,
                )

                pk2 = next(
                    values_iter,
                    None,
                )

                if pk1 is None or pk2 is None:
                    continue

                acc_bal = Chain.instance.calc_balance(
                    self.wallet.public_key,
                    self.mem_pool,
                )

                payload = acc_bal * 0.75

                # ------------------------------------------------------
                # BLOCK 1
                # ------------------------------------------------------

                transaction1 = Transaction(
                    payload,
                    self.wallet.public_key,
                    pk1,
                )

                transaction1_str = str(
                    transaction1
                )

                signature1 = (
                    self.wallet.private_key.sign(
                        transaction1_str.encode()
                    )
                )

                transaction1.sign = signature1

                transaction_list.append(
                    transaction1
                )

                newBlock1 = Block(
                    Chain.instance.lastBlock.hash,
                    transaction_list.copy(),
                )

                # ------------------------------------------------------
                # BLOCK 2
                # ------------------------------------------------------

                transaction_list.remove(
                    transaction1
                )

                transaction2 = Transaction(
                    payload,
                    self.wallet.public_key,
                    pk2,
                )

                transaction2_str = str(
                    transaction2
                )

                signature2 = (
                    self.wallet.private_key.sign(
                        transaction2_str.encode()
                    )
                )

                transaction2.sign = signature2

                transaction_list.append(
                    transaction2
                )

                newBlock2 = Block(
                    Chain.instance.lastBlock.hash,
                    transaction_list.copy(),
                )

                # ------------------------------------------------------
                # FILES
                # ------------------------------------------------------

                newBlock1.files = (
                    self.file_hashes.copy()
                )

                newBlock2.files = (
                    self.file_hashes.copy()
                )

                # ------------------------------------------------------
                # MINE
                # ------------------------------------------------------

                await asyncio.to_thread(
                    Chain.instance.mine,
                    newBlock1,
                )

                await asyncio.to_thread(
                    Chain.instance.mine,
                    newBlock2,
                )

                newBlock1.miner = (
                    self.wallet.public_key
                )

                newBlock2.miner = (
                    self.wallet.public_key
                )

                # ------------------------------------------------------
                # APPEND BLOCK 1
                # ------------------------------------------------------

                Chain.instance.chain.append(
                    newBlock1
                )

                print(
                    "\nBlock Appended\n"
                )

                for transaction in newBlock1.transactions:

                    if transaction.receiver == "deploy":

                        self.deploy_contract(
                            transaction
                        )

                async with self.file_hashes_lock:

                    for file_hash in list(
                        self.file_hashes.keys()
                    ):

                        if newBlock1.cid_exists_in_block(
                            file_hash
                        ):

                            self.file_hashes.pop(
                                file_hash,
                                None,
                            )

                self.mem_pool = [
                    transaction
                    for transaction in self.mem_pool
                    if not newBlock1.transaction_exists_in_block(
                        transaction
                    )
                ]

                # ------------------------------------------------------
                # CREATE NETWORK PACKETS
                # ------------------------------------------------------

                pkt1 = {
                    "type": "new_block",
                    "id": str(uuid.uuid4()),
                    "block": newBlock1.to_dict(),
                    "miner": self.wallet.public_key,
                }

                # FIXED:
                # Your original code had:
                #
                # "block": newBlock1.to_dict()
                #
                # for pkt2 as well.
                #
                # It should send newBlock2.
                pkt2 = {
                    "type": "new_block",
                    "id": str(uuid.uuid4()),
                    "block": newBlock2.to_dict(),
                    "miner": self.wallet.public_key,
                }

                self.seen_message_ids.add(
                    pkt1["id"]
                )

                self.seen_message_ids.add(
                    pkt2["id"]
                )

                if self.activate_disk_save == "y":

                    self.save_chain_to_disk()

                # ------------------------------------------------------
                # SEND HALF TO EACH GROUP
                # ------------------------------------------------------

                targets = (
                    self.server_connections
                    | self.client_connections
                )

                targets_list = list(targets)

                midpoint = len(targets_list) // 2

                for ws in targets_list[:midpoint]:

                    try:

                        await ws.send(
                            json.dumps(pkt1)
                        )

                    except Exception as e:

                        print(
                            f"Error broadcasting: {e}"
                        )

                for ws in targets_list[midpoint:]:

                    try:

                        await ws.send(
                            json.dumps(pkt2)
                        )

                    except Exception as e:

                        print(
                            f"Error broadcasting: {e}"
                        )

    # ------------------------------------------------------------------
    # SMART CONTRACTS
    # ------------------------------------------------------------------

    def calculate_contract_id(
        self,
        sender,
        timestamp,
    ):

        data = f"{sender}:{timestamp}"

        hash_object = hashlib.sha256(
            data.encode("utf-8")
        )

        return hash_object.hexdigest()

    def deploy_contract(
        self,
        transaction: Transaction,
    ):

        sender = transaction.sender
        timestamp = transaction.ts
        code = transaction.payload[0]

        contract_id = self.calculate_contract_id(
            sender,
            timestamp,
        )

        self.contractsDB.store_contract(
            contract_id,
            code,
        )

        print(
            "Contract deployed with id: ",
            contract_id,
        )

    def run_contract(self, payload):

        contract_id = payload[0]
        func_name = payload[1]
        args = payload[2]

        code = self.contractsDB.get_contract(
            contract_id
        )

        if code is None:

            raise Exception(
                f"Contract '{contract_id}' not found."
            )

        state = self.get_contract_state(
            contract_id
        )

        executor = SecureContractExecutor(
            code
        )

        response = executor.run(
            func_name,
            args,
            state,
        )

        return response

    # ------------------------------------------------------------------
    # LONGEST CHAIN
    # ------------------------------------------------------------------

    async def find_longest_chain(self):

        """
        Every 60 seconds request chains from peers.
        """

        while True:

            pkt = {
                "type": "chain_request",
                "id": str(uuid.uuid4()),
            }

            self.seen_message_ids.add(
                pkt["id"]
            )

            await self.broadcast_message(
                pkt
            )

            print(
                "\nSent out chain requests..."
            )

            await asyncio.sleep(60)

    # ------------------------------------------------------------------
    # START PEER
    # ------------------------------------------------------------------

    async def start(
        self,
        bootstrap_host=None,
        bootstrap_port=None,
    ):

        # --------------------------------------------------------------
        # START WEBSOCKET SERVER
        # --------------------------------------------------------------

        server = await websockets.serve(
            self.handle_connections,
            self.host,
            self.port,
        )

        print(
            f"\nWebSocket server started on "
            f"{self.host}:{self.port}\n"
        )

        # --------------------------------------------------------------
        # BOOTSTRAP OR CREATE GENESIS CHAIN
        # --------------------------------------------------------------

        if bootstrap_host and bootstrap_port:

            (
                normalized_bootstrap_host,
                normalized_bootstrap_port,
            ) = normalize_endpoint(
                (
                    bootstrap_host,
                    bootstrap_port,
                )
            )

            asyncio.create_task(
                self.connect_to_peer(
                    normalized_bootstrap_host,
                    normalized_bootstrap_port,
                )
            )

        else:

            self.chain = Chain(
                publicKey=self.wallet.public_key
            )

            print(
                "\nNew blockchain created.\n"
            )

        # --------------------------------------------------------------
        # BACKGROUND TASKS
        # --------------------------------------------------------------

        inp_task = asyncio.create_task(
            self.user_input_handler()
        )

        consensus_task = asyncio.create_task(
            self.find_longest_chain()
        )

        disc_task = asyncio.create_task(
            self.discover_peers()
        )

        sampler_task = asyncio.create_task(
            self.gossip_peer_sampler()
        )

        if self.miner:

            self.mine_task = asyncio.create_task(
                self.mine_blocks()
            )

        # --------------------------------------------------------------
        # IPFS
        # --------------------------------------------------------------

        try:

            self.init_repo()
            self.configure_ports()

        except Exception as e:

            print(
                f"\nIPFS initialization failed: {e}\n"
            )

        # --------------------------------------------------------------
        # WAIT FOR USER TO QUIT
        # --------------------------------------------------------------

        try:

            await inp_task

        finally:

            disc_task.cancel()
            consensus_task.cancel()
            sampler_task.cancel()

            if self.mine_task:

                self.mine_task.cancel()

            if self.daemon_process:

                self.stop_daemon()

            server.close()

            await server.wait_closed()