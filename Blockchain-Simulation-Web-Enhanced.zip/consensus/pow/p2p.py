import asyncio
import websockets
import json
import uuid
import base64
import socket
import os
import subprocess
from typing import Set, Dict, List, Tuple
from consensus.pow.blockchain_structures import (
    Transaction,
    Block,
    Wallet,
    Chain,
    isvalidChain
)
from ipfs.ipfs import addToIpfs, download_ipfs_file_subprocess
from smart_contract.contracts_db import SmartContractDatabase
from smart_contract.secure_executor import SecureContractExecutor
from storage.storage_manager import (
    save_key,
    load_key,
    save_chain,
    load_chain,
    save_peers,
    load_peers
)
from ecdsa import VerifyingKey
from pathlib import Path
import tempfile
import ast
import hashlib


MAX_CONNECTIONS = 8
GAS_PRICE = 0.001
BASE_DEPLOY_COST = 5
CONSENSUS = "pow"


def get_random_element(s):
    """
    Return a random element from a set.
    """
    import random

    if not s:
        return None

    return random.choice(list(s))


def normalize_endpoint(ep):
    """
    Resolve host into IPv4 address and convert port to int.
    """
    host, port = ep
    return (socket.gethostbyname(host), int(port))


def get_contract_code_from_notepad():
    """
    Create a temporary Python file and open it in Notepad.
    """

    with tempfile.NamedTemporaryFile(
        suffix=".py",
        delete=False,
        mode="w+",
        encoding="utf-8"
    ) as tmp_file:

        temp_filename = tmp_file.name

        tmp_file.write(
            "# Write your smart contract function here.\n"
        )

        tmp_file.write(
            "def contract_logic(parameter1, parameter2, parameter3, state):\n"
        )

        tmp_file.write(
            "    # your code here\n"
        )

        tmp_file.write(
            "    return state, 'some message'\n"
        )

    # Windows
    if os.name == "nt":
        subprocess.call(["notepad.exe", temp_filename])

    # Linux
    elif os.name == "posix":
        try:
            subprocess.call(["gedit", temp_filename])
        except FileNotFoundError:
            subprocess.call(["xdg-open", temp_filename])

    else:
        print("Please edit the following file manually:")
        print(temp_filename)
        input("Press Enter after editing...")

    try:
        with open(temp_filename, "r", encoding="utf-8") as f:
            contract_code = f.read()
    finally:
        try:
            os.remove(temp_filename)
        except OSError:
            pass

    return contract_code


class Peer:

    def __init__(
        self,
        host,
        port,
        name,
        miner: bool,
        activate_disk_load,
        activate_disk_save
    ):

        self.host = host
        self.name = name
        self.miner = miner

        self.activate_disk_save = activate_disk_save

        self.port = int(port)

        self.ipfs_port = self.port + 50
        self.gateway_port = self.port + 81
        self.swarm_tcp = self.port + 2
        self.swarm_udp = self.port + 3

        self.repo_path = Path.home() / f".ipfs_{self.port}"

        self.env = os.environ.copy()
        self.env["IPFS_PATH"] = str(self.repo_path)

        # Inbound WebSocket connections
        self.server_connections: Set = set()

        # Outbound WebSocket connections
        self.client_connections: Set = set()

        # Endpoints to which we currently have outbound connections
        self.outbound_peers: Set[tuple] = set()

        # Prevent duplicate messages
        self.seen_message_ids: Set[str] = set()

        # Known peers:
        # (host, port) -> (name, public_key)
        self.known_peers: Dict[
            Tuple[str, int],
            Tuple[str, str]
        ] = {}

        if activate_disk_load == "y":
            self.load_known_peers_from_disk()

        self.got_pong: Dict = {}

        self.have_sent_peer_info: Dict = {}

        self.mem_pool: List[Transaction] = []

        self.file_hashes: Dict[str, str] = {}

        self.file_hashes_lock = asyncio.Lock()

        self.daemon_process = None

        self.name_to_public_key_dict: Dict[str, str] = {}

        # Wallet
        if activate_disk_load == "y":
            self.load_key_from_disk()
        else:
            self.wallet = None

        if not self.wallet:
            self.wallet = Wallet()

            if self.activate_disk_save == "y":
                self.save_key_to_disk()

        # Blockchain
        if activate_disk_load == "y":
            self.load_chain_from_disk()
        else:
            self.chain = None

        self.contractsDB = SmartContractDatabase()

        self.mem_pool_condition = asyncio.Condition()

        self.mine_task = None

    # ---------------------------------------------------------
    # STORAGE
    # ---------------------------------------------------------

    def save_key_to_disk(self):
        key = self.wallet.private_key_pem
        save_key(key, CONSENSUS)

    def load_key_from_disk(self):
        key = load_key(CONSENSUS)

        if not key:
            self.wallet = None
            return

        self.wallet = Wallet(key)

    def load_chain_from_disk(self):

        block_dict_list = load_chain(CONSENSUS)

        if not block_dict_list:
            self.chain = None
            return

        block_list: List[Block] = []

        for block_dict in block_dict_list:
            block = self.block_dict_to_block(block_dict)
            block_list.append(block)

        self.chain = Chain(blockList=block_list)

    def save_chain_to_disk(self):

        if Chain.instance is None:
            return

        chain = Chain.instance.to_block_dict_list()

        save_chain(chain, CONSENSUS)

    def save_known_peers_to_disk(self):

        content = {}

        for key, value in self.known_peers.items():
            content[json.dumps(key)] = list(value)

        save_peers(content, CONSENSUS)

    def load_known_peers_from_disk(self):

        content = load_peers(CONSENSUS)

        if not content:
            self.known_peers = {}
            return

        self.known_peers = {}

        for key, value in content.items():

            try:
                endpoint = tuple(ast.literal_eval(key))
                self.known_peers[endpoint] = tuple(value)

            except Exception as e:
                print(
                    f"Could not load peer {key}: {e}"
                )
                continue

        # FIX:
        # Original code incorrectly did:
        #
        # for key, value in self.known_peers:
        #
        # which tries to unpack dictionary keys.
        #
        # Correct version:

        for endpoint, value in self.known_peers.items():

            if len(value) >= 2:

                peer_name = value[0]
                public_key = value[1]

                self.name_to_public_key_dict[
                    peer_name.lower()
                ] = public_key

    # ---------------------------------------------------------
    # PEER INFORMATION
    # ---------------------------------------------------------

    async def send_peer_info(self, websocket):

        pkt = {
            "type": "peer_info",
            "id": str(uuid.uuid4()),
            "data": {
                "host": self.host,
                "port": self.port,
                "name": self.name,
                "public_key": self.wallet.public_key_pem
            }
        }

        self.seen_message_ids.add(pkt["id"])

        await websocket.send(json.dumps(pkt))

    async def send_known_peers(self, websocket):

        peers = [
            {
                "host": h,
                "port": p,
                "name": n,
                "public_key": s
            }
            for (h, p), (n, s) in self.known_peers.items()
        ]

        # Add ourselves
        peers.append(
            {
                "host": self.host,
                "port": self.port,
                "name": self.name,
                "public_key": self.wallet.public_key_pem
            }
        )

        pkt = {
            "type": "known_peers",
            "id": str(uuid.uuid4()),
            "peers": peers
        }

        self.seen_message_ids.add(pkt["id"])

        await websocket.send(json.dumps(pkt))

    # ---------------------------------------------------------
    # BLOCK CONVERSION
    # ---------------------------------------------------------

    def block_dict_to_block(self, block_dict):

        new_block_id = block_dict["id"]
        new_block_prevHash = block_dict["prevHash"]
        new_block_ts = block_dict["ts"]
        new_block_nonce = block_dict["nonce"]

        transactions = []

        for transaction_dict in block_dict["transactions"]:

            transaction = Transaction(
                transaction_dict["payload"],
                transaction_dict["sender"],
                transaction_dict["receiver"],
                transaction_dict["id"],
                transaction_dict["ts"]
            )

            if transaction.sender != "Genesis":

                transaction.sign = base64.b64decode(
                    transaction_dict["sign"]
                )

            transactions.append(transaction)

        newBlock = Block(
            new_block_prevHash,
            transactions,
            new_block_ts,
            new_block_nonce,
            new_block_id
        )

        newBlock.files = block_dict.get("files", {})

        return newBlock

    # ---------------------------------------------------------
    # SMART CONTRACT VALIDATION
    # ---------------------------------------------------------

    def valid_deploy_transaction(self, payload):

        contract_code = payload[0]

        gas_used = (
            len(contract_code) // 10
            + BASE_DEPLOY_COST
        )

        amount = gas_used * GAS_PRICE

        return amount == payload[-1]

    def valid_invoke_transaction(self, payload):

        contract_id = payload[0]
        func_name = payload[1]
        args = payload[2]

        try:
            response = self.run_contract(
                [contract_id, func_name, args]
            )

        except Exception:
            return False

        if response["error"] is not None:
            return False

        state = response["state"]

        gas_used = response["gas_used"]

        amount = gas_used * GAS_PRICE

        if state != payload[3]:
            return False

        if amount != payload[-1]:
            return False

        return True

    # ---------------------------------------------------------
    # PEER NAME
    # ---------------------------------------------------------

    def get_unique_name(self, base_name):

        existing_names = []

        for key, value in self.known_peers.items():

            if value:
                existing_names.append(
                    value[0].lower()
                )

        existing_names.append(
            self.name.lower()
        )

        base_name = base_name.lower()

        if base_name not in existing_names:
            return base_name

        counter = 1

        while True:

            new_name = f"{base_name}{counter}"

            if new_name not in existing_names:
                return new_name

            counter += 1

    # ---------------------------------------------------------
    # MESSAGE HANDLER
    # ---------------------------------------------------------

    async def handle_messages(self, websocket, msg):

        if not isinstance(msg, dict):
            return

        message_type = msg.get("type")
        message_id = msg.get("id")

        if not message_type or not message_id:
            return

        if message_id in self.seen_message_ids:
            return

        self.seen_message_ids.add(message_id)

        # -----------------------------------------------------
        # PING
        # -----------------------------------------------------

        if message_type == "ping":

            pkt = {
                "type": "pong",
                "id": str(uuid.uuid4())
            }

            self.seen_message_ids.add(pkt["id"])

            await websocket.send(
                json.dumps(pkt)
            )

        # -----------------------------------------------------
        # PONG
        # -----------------------------------------------------

        elif message_type == "pong":

            self.got_pong[websocket] = True

            if not self.have_sent_peer_info.get(
                websocket,
                True
            ):

                await self.send_peer_info(websocket)

                self.have_sent_peer_info[websocket] = True

        # -----------------------------------------------------
        # PEER INFO
        # -----------------------------------------------------

        elif message_type == "peer_info":

            data = msg.get("data", {})

            try:
                normalized_self = normalize_endpoint(
                    (self.host, self.port)
                )

                normalized_endpoint = normalize_endpoint(
                    (
                        data["host"],
                        data["port"]
                    )
                )

            except Exception:
                return

            # FIX:
            # Original code had:
            #
            # normalize_endpoint != normalized_self
            #
            # It must compare normalized_endpoint.

            if (
                normalized_endpoint not in self.known_peers
                and normalized_endpoint != normalized_self
            ):

                peer_name = data["name"]
                public_key = data["public_key"]

                self.known_peers[
                    normalized_endpoint
                ] = (
                    peer_name,
                    public_key
                )

                self.name_to_public_key_dict[
                    peer_name.lower()
                ] = public_key

                if self.activate_disk_save == "y":
                    self.save_known_peers_to_disk()

                print(
                    f"Registered peer "
                    f"{peer_name} "
                    f"{data['host']}:{data['port']}"
                )

                await self.send_known_peers(websocket)

        # -----------------------------------------------------
        # ADD PEER
        # -----------------------------------------------------

        elif message_type == "add_peer":

            data = msg.get("data", {})

            try:
                normalized_self = normalize_endpoint(
                    (self.host, self.port)
                )

                normalized_endpoint = normalize_endpoint(
                    (
                        data["host"],
                        data["port"]
                    )
                )

            except Exception:
                return

            new_peer_msg_id = str(uuid.uuid4())

            if (
                normalized_endpoint not in self.known_peers
                and normalized_endpoint != normalized_self
            ):

                proposed_name = self.get_unique_name(
                    data["name"]
                )

                if proposed_name != data["name"]:

                    pkt = {
                        "type": "change_name",
                        "id": str(uuid.uuid4()),
                        "new_peer_msg_id": new_peer_msg_id,
                        "new_name": proposed_name
                    }

                    await websocket.send(
                        json.dumps(pkt)
                    )

                    data["name"] = proposed_name

                self.known_peers[
                    normalized_endpoint
                ] = (
                    data["name"],
                    data["public_key"]
                )

                self.name_to_public_key_dict[
                    data["name"].lower()
                ] = data["public_key"]

                if self.activate_disk_save == "y":
                    self.save_known_peers_to_disk()

                print(
                    f"Registered peer "
                    f"{data['name']} "
                    f"{data['host']}:{data['port']}"
                )

                await self.send_known_peers(websocket)

                pkt = {
                    "type": "new_peer",
                    "id": new_peer_msg_id,
                    "data": {
                        "host": data["host"],
                        "port": data["port"],
                        "name": data["name"],
                        "public_key": data["public_key"]
                    }
                }

                self.seen_message_ids.add(
                    pkt["id"]
                )

                await self.broadcast_message(pkt)

        # -----------------------------------------------------
        # NEW PEER
        # -----------------------------------------------------

        elif message_type == "new_peer":

            data = msg.get("data", {})

            try:
                normalized_self = normalize_endpoint(
                    (self.host, self.port)
                )

                normalized_endpoint = normalize_endpoint(
                    (
                        data["host"],
                        data["port"]
                    )
                )

            except Exception:
                return

            if (
                normalized_endpoint not in self.known_peers
                and normalized_endpoint != normalized_self
            ):

                self.known_peers[
                    normalized_endpoint
                ] = (
                    data["name"],
                    data["public_key"]
                )

                self.name_to_public_key_dict[
                    data["name"].lower()
                ] = data["public_key"]

                if self.activate_disk_save == "y":
                    self.save_known_peers_to_disk()

                print(
                    f"Registered peer "
                    f"{data['name']} "
                    f"{data['host']}:{data['port']}"
                )

                await self.broadcast_message(msg)

        # -----------------------------------------------------
        # CHANGE NAME
        # -----------------------------------------------------

        elif message_type == "change_name":

            new_name = msg.get("new_name")

            if new_name:
                self.name = new_name

            new_peer_msg_id = msg.get(
                "new_peer_msg_id"
            )

            if new_peer_msg_id:
                self.seen_message_ids.add(
                    new_peer_msg_id
                )

        # -----------------------------------------------------
        # KNOWN PEERS
        # -----------------------------------------------------

        elif message_type == "known_peers":

            peers = msg.get("peers", [])

            new_peer_found = False

            normalized_self = normalize_endpoint(
                (self.host, self.port)
            )

            for peer in peers:

                try:
                    normalized_endpoint = normalize_endpoint(
                        (
                            peer["host"],
                            peer["port"]
                        )
                    )

                except Exception:
                    continue

                if (
                    normalized_endpoint not in self.known_peers
                    and normalized_endpoint != normalized_self
                ):

                    print(
                        f"Discovered peer "
                        f"{peer['name']} "
                        f"at "
                        f"{peer['host']}:{peer['port']}"
                    )

                    new_peer_found = True

                    self.known_peers[
                        normalized_endpoint
                    ] = (
                        peer["name"],
                        peer["public_key"]
                    )

                    self.name_to_public_key_dict[
                        peer["name"].lower()
                    ] = peer["public_key"]

            if (
                new_peer_found
                and self.activate_disk_save == "y"
            ):
                self.save_known_peers_to_disk()

            pkt = {
                "type": "chain_request",
                "id": str(uuid.uuid4())
            }

            self.seen_message_ids.add(
                pkt["id"]
            )

            await websocket.send(
                json.dumps(pkt)
            )

        # -----------------------------------------------------
        # FILE
        # -----------------------------------------------------

        elif message_type == "file":

            cid = msg.get("cid")
            desc = msg.get("desc", "")

            if not cid:
                return

            async with self.file_hashes_lock:

                self.file_hashes[cid] = desc

            await self.broadcast_message(msg)

        # -----------------------------------------------------
        # NEW TRANSACTION
        # -----------------------------------------------------

        elif message_type == "new_tx":

            if Chain.instance is None:
                return

            tx_str = msg.get("transaction")

            if not tx_str:
                return

            try:
                tx = json.loads(tx_str)
            except json.JSONDecodeError:
                print("Invalid transaction JSON")
                return

            try:

                transaction = Transaction(
                    tx["payload"],
                    tx["sender"],
                    tx["receiver"],
                    tx["id"],
                    tx["ts"]
                )

            except Exception as e:

                print(
                    f"Could not construct transaction: {e}"
                )

                return

            if Chain.instance.transaction_exists_in_chain(
                transaction
            ):

                print(
                    f"{self.name} Transaction already exists in chain"
                )

                return

            try:
                sign_bytes = base64.b64decode(
                    msg["sign"]
                )
            except Exception:

                print("Invalid signature encoding")
                return

            # Smart contract transaction validation

            if transaction.receiver == "deploy":

                if not self.valid_deploy_transaction(
                    transaction.payload
                ):
                    return

            elif transaction.receiver == "invoke":

                if not self.valid_invoke_transaction(
                    transaction.payload
                ):
                    return

            # Calculate amount

            if (
                transaction.receiver == "deploy"
                or transaction.receiver == "invoke"
            ):

                amount = transaction.payload[-1]

            else:

                amount = transaction.payload

            try:
                balance = Chain.instance.calc_balance(
                    transaction.sender,
                    self.mem_pool
                )
            except Exception:
                return

            if amount > balance:

                print(
                    "\nAttempt to spend more than one has, "
                    "Invalid transaction\n"
                )

                return

            if amount <= 0:

                print(
                    "\nInvalid Transaction, amount <= 0\n"
                )

                return

            # Verify signature

            try:

                public_key = VerifyingKey.from_pem(
                    tx["sender"].encode()
                )

                public_key.verify(
                    sign_bytes,
                    tx_str.encode()
                )

            except Exception:

                print("Invalid Signature")
                return

            transaction.sign = sign_bytes

            print("\nValid Transaction")

            print(
                f"\n{message_type}: {tx_str}"
            )

            print()

            async with self.mem_pool_condition:

                # Avoid duplicate mempool entries
                if not any(
                    t.id == transaction.id
                    for t in self.mem_pool
                ):
                    self.mem_pool.append(transaction)

            await self.broadcast_message(msg)

        # -----------------------------------------------------
        # NEW BLOCK
        # -----------------------------------------------------

        elif message_type == "new_block":

            if Chain.instance is None:
                return

            new_block_dict = msg.get("block")

            if not new_block_dict:
                return

            try:
                newBlock = self.block_dict_to_block(
                    new_block_dict
                )
            except Exception as e:

                print(
                    f"Invalid block format: {e}"
                )

                return

            if not Chain.instance.isValidBlock(newBlock):

                print("\nInvalid Block\n")
                return

            # Validate smart contract transactions

            for transaction in newBlock.transactions:

                if transaction.receiver == "invoke":

                    if not self.valid_invoke_transaction(
                        transaction.payload
                    ):
                        print(
                            "Invalid invoke transaction in block"
                        )
                        return

                elif transaction.receiver == "deploy":

                    if not self.valid_deploy_transaction(
                        transaction.payload
                    ):
                        print(
                            "Invalid deploy transaction in block"
                        )
                        return

            newBlock.miner = msg.get("miner")

            Chain.instance.chain.append(newBlock)

            print("\n\nBlock Appended\n")

            # Deploy contracts

            for transaction in newBlock.transactions:

                if transaction.receiver == "deploy":

                    self.deploy_contract(transaction)

            # Cancel current mining task

            if (
                self.miner
                and self.mine_task
                and not self.mine_task.done()
            ):

                self.mine_task.cancel()

                print(
                    "New Block received. "
                    "Cancelled Mining..."
                )

            # Remove confirmed transactions safely

            async with self.mem_pool_condition:

                self.mem_pool = [
                    transaction
                    for transaction in self.mem_pool
                    if not newBlock.transaction_exists_in_block(
                        transaction
                    )
                ]

            # Remove included files

            async with self.file_hashes_lock:

                for file_hash in list(
                    self.file_hashes.keys()
                ):

                    if newBlock.cid_exists_in_block(
                        file_hash
                    ):

                        self.file_hashes.pop(
                            file_hash,
                            None
                        )

            if self.miner:

                self.mine_task = asyncio.create_task(
                    self.mine_blocks()
                )

            await self.broadcast_message(msg)

            if self.activate_disk_save == "y":
                self.save_chain_to_disk()

        # -----------------------------------------------------
        # CHAIN REQUEST
        # -----------------------------------------------------

        elif message_type == "chain_request":

            if Chain.instance is None:
                return

            pkt = {
                "type": "chain",
                "id": str(uuid.uuid4()),
                "chain": Chain.instance.to_block_dict_list()
            }

            self.seen_message_ids.add(
                pkt["id"]
            )

            await websocket.send(
                json.dumps(pkt)
            )

        # -----------------------------------------------------
        # CHAIN
        # -----------------------------------------------------

        elif message_type == "chain":

            print("Received a Chain")

            block_dict_list = msg.get(
                "chain",
                []
            )

            block_list: List[Block] = []

            try:

                for block_dict in block_dict_list:

                    block = self.block_dict_to_block(
                        block_dict
                    )

                    block_list.append(block)

            except Exception as e:

                print(
                    f"Could not reconstruct chain: {e}"
                )

                return

            if not isvalidChain(block_list):

                print("\nInvalid Chain\n")
                return

            # No local chain yet

            if Chain.instance is None:

                self.chain = Chain(
                    blockList=block_list
                )

                if self.activate_disk_save == "y":

                    self.save_chain_to_disk()

                print("\nInitialized Chain\n")

                return

            # Replace with longer chain

            elif (
                len(Chain.instance.chain)
                < len(block_list)
            ):

                Chain.instance.rewrite(
                    block_list
                )

                print(
                    "\nCurrent chain replaced "
                    "by longer chain\n"
                )

                if self.activate_disk_save == "y":
                    self.save_chain_to_disk()

            else:

                print(
                    "\nCurrent Chain Longer "
                    "than received chain"
                )

            # Clean mempool

            async with self.mem_pool_condition:

                self.mem_pool = [
                    transaction
                    for transaction in self.mem_pool
                    if not Chain.instance.transaction_exists_in_chain(
                        transaction
                    )
                ]

            # Clean file list

            async with self.file_hashes_lock:

                for file_hash in list(
                    self.file_hashes.keys()
                ):

                    if Chain.instance.cid_exists_in_chain(
                        file_hash
                    ):

                        self.file_hashes.pop(
                            file_hash,
                            None
                        )

    # ---------------------------------------------------------
    # INBOUND CONNECTIONS
    # ---------------------------------------------------------

    async def handle_connections(self, websocket):

        remote_address = websocket.remote_address

        if remote_address:
            peer_addr = (
                remote_address[0],
                remote_address[1]
            )
        else:
            peer_addr = ("unknown", "unknown")

        self.server_connections.add(websocket)

        print(
            f"Inbound Connection from "
            f"{peer_addr[0]}:{peer_addr[1]}"
        )

        try:

            async for raw in websocket:

                try:
                    msg = json.loads(raw)

                except json.JSONDecodeError:

                    print(
                        "Received invalid JSON"
                    )

                    continue

                await self.handle_messages(
                    websocket,
                    msg
                )

        except websockets.exceptions.ConnectionClosed:

            print(
                f"Inbound Connection Closed: "
                f"{peer_addr}"
            )

        except Exception as e:

            print(
                f"Inbound connection error: {e}"
            )

        finally:

            self.server_connections.discard(
                websocket
            )

            try:
                if not websocket.closed:
                    await websocket.close()
            except Exception:
                pass

    # ---------------------------------------------------------
    # BROADCAST
    # ---------------------------------------------------------

    async def broadcast_message(self, pkt):

        targets = (
            self.server_connections
            | self.client_connections
        )

        disconnected = []

        for ws in list(targets):

            try:

                await ws.send(
                    json.dumps(pkt)
                )

            except Exception as e:

                print(
                    f"Error broadcasting: {e}"
                )

                disconnected.append(ws)

        for ws in disconnected:

            self.server_connections.discard(ws)
            self.client_connections.discard(ws)

            try:

                remote = ws.remote_address

                if remote:

                    normalized_endpoint = normalize_endpoint(
                        (
                            remote[0],
                            remote[1]
                        )
                    )

                    self.outbound_peers.discard(
                        normalized_endpoint
                    )

            except Exception:
                pass

            self.got_pong.pop(ws, None)
            self.have_sent_peer_info.pop(ws, None)

            try:
                if not ws.closed:
                    await ws.close()
            except Exception:
                pass

    # ---------------------------------------------------------
    # TRANSACTIONS
    # ---------------------------------------------------------

    async def create_and_broadcast_tx(
        self,
        receiver_public_key,
        payload
    ):

        transaction = Transaction(
            payload,
            self.wallet.public_key_pem,
            receiver_public_key
        )

        transaction_str = str(transaction)

        signature = self.wallet.private_key.sign(
            transaction_str.encode()
        )

        signature_b64 = base64.b64encode(
            signature
        ).decode()

        pkt = {
            "type": "new_tx",
            "id": str(uuid.uuid4()),
            "transaction": transaction_str,
            "sign": signature_b64,
            "sender_pem": self.wallet.public_key_pem
        }

        self.seen_message_ids.add(
            pkt["id"]
        )

        if Chain.instance is not None:

            if Chain.instance.transaction_exists_in_chain(
                transaction
            ):
                return

        async with self.mem_pool_condition:

            if not any(
                t.id == transaction.id
                for t in self.mem_pool
            ):

                self.mem_pool.append(
                    transaction
                )

        transaction.sign = signature

        print(
            "Transaction Created",
            transaction
        )

        print()

        await self.broadcast_message(pkt)

    # ---------------------------------------------------------
    # SMART CONTRACT STATE
    # ---------------------------------------------------------

    def get_contract_state(self, contract_id):

        if Chain.instance is None:
            return {}

        for block in reversed(
            Chain.instance.chain
        ):

            for transaction in reversed(
                block.transactions
            ):

                if (
                    transaction.receiver == "invoke"
                    and transaction.payload[0]
                    == contract_id
                ):

                    return transaction.payload[3]

        return {}

    # ---------------------------------------------------------
    # USER INPUT
    # ---------------------------------------------------------

    async def user_input_handler(self):

        while True:

            print(
                "\nBlock Chain Menu\n"
                "***************"
            )

            print(
                "1) Add Transaction\n"
                "2) View balance\n"
                "3) Print Chain\n"
                "4) Print Pending Transactions\n"
                "5) Send Files\n"
                "6) Download Files\n"
                "7) Quit\n"
            )

            loop = asyncio.get_running_loop()

            ch = await loop.run_in_executor(
                None,
                input,
                "Enter Your Choice: "
            )

            try:
                ch = int(ch)

            except ValueError:

                print(
                    "\nPlease enter a valid number!!!\n"
                )

                continue

            # -------------------------------------------------
            # ADD TRANSACTION
            # -------------------------------------------------

            if ch == 1:

                if Chain.instance is None:

                    print(
                        "\nBlockchain is not initialized yet.\n"
                    )

                    continue

                rec = await loop.run_in_executor(
                    None,
                    input,
                    "\nEnter Receiver's Name or Public Key: "
                )

                rec = rec.strip()

                # -------------------------------------------------
                # DEPLOY CONTRACT
                # -------------------------------------------------

                if rec.lower() == "deploy":

                    contract_code = (
                        get_contract_code_from_notepad()
                    )

                    if not contract_code.strip():

                        print(
                            "Contract code field is empty"
                        )

                        continue

                    gas_used = (
                        len(contract_code) // 10
                        + BASE_DEPLOY_COST
                    )

                    amount = gas_used * GAS_PRICE

                    payload = [
                        contract_code,
                        amount
                    ]

                    balance = Chain.instance.calc_balance(
                        self.wallet.public_key_pem,
                        self.mem_pool
                    )

                    if amount <= balance:

                        await self.create_and_broadcast_tx(
                            "deploy",
                            payload
                        )

                    else:

                        print(
                            "Insufficient Account Balance"
                        )

                # -------------------------------------------------
                # INVOKE CONTRACT
                # -------------------------------------------------

                elif rec.lower() == "invoke":

                    contract_id = await loop.run_in_executor(
                        None,
                        input,
                        "\nEnter Contract Id: "
                    )

                    contract_id = contract_id.strip()

                    if (
                        contract_id
                        not in self.contractsDB.contracts
                    ):

                        print(
                            "No such contract found..."
                        )

                        continue

                    func_name = await loop.run_in_executor(
                        None,
                        input,
                        "\nEnter Function Name: "
                    )

                    func_name = func_name.strip()

                    args = []

                    arg_number = 1

                    while True:

                        arg = await loop.run_in_executor(
                            None,
                            input,
                            f"Enter argument "
                            f"{arg_number} "
                            f"(or \\q to finish): "
                        )

                        if arg.strip() == "\\q":
                            break

                        try:
                            parsed_arg = ast.literal_eval(
                                arg
                            )

                        except Exception:
                            parsed_arg = arg

                        args.append(parsed_arg)

                        arg_number += 1

                    try:

                        response = self.run_contract(
                            [
                                contract_id,
                                func_name,
                                args
                            ]
                        )

                    except Exception as e:

                        print(
                            "Error:",
                            e
                        )

                        continue

                    if response["error"] is not None:

                        print(
                            "Error:",
                            response["error"]
                        )

                        continue

                    state = response["state"]

                    gas_used = response["gas_used"]

                    amount = gas_used * GAS_PRICE

                    payload = [
                        contract_id,
                        func_name,
                        args,
                        state,
                        amount
                    ]

                    balance = Chain.instance.calc_balance(
                        self.wallet.public_key_pem,
                        self.mem_pool
                    )

                    if amount <= balance:

                        await self.create_and_broadcast_tx(
                            "invoke",
                            payload
                        )

                    else:

                        print(
                            "Insufficient Account Balance"
                        )

                # -------------------------------------------------
                # NORMAL TRANSACTION
                # -------------------------------------------------

                else:

                    amt = await loop.run_in_executor(
                        None,
                        input,
                        "\nEnter Amount to send: "
                    )

                    receiver_public_key = (
                        self.name_to_public_key_dict.get(
                            rec.lower().strip()
                        )
                    )

                    # If name wasn't found,
                    # check whether the entered value
                    # is already a public key.

                    if receiver_public_key is None:

                        rec_refined = rec.replace(
                            "\\n",
                            "\n"
                        )

                        for (
                            nme,
                            pk
                        ) in self.name_to_public_key_dict.items():

                            if pk == rec_refined:

                                receiver_public_key = pk
                                break

                    if receiver_public_key is None:

                        print(
                            "No person available in directory "
                            "with provided name or public key..."
                        )

                        continue

                    try:

                        amt = float(amt)

                    except ValueError:

                        print(
                            "Amount must be a number"
                        )

                        continue

                    if amt <= 0:

                        print(
                            "\nAmount must be positive\n"
                        )

                        continue

                    balance = Chain.instance.calc_balance(
                        self.wallet.public_key_pem,
                        self.mem_pool
                    )

                    if amt <= balance:

                        await self.create_and_broadcast_tx(
                            receiver_public_key,
                            amt
                        )

                    else:

                        print(
                            "Insufficient Account Balance"
                        )

            # -------------------------------------------------
            # BALANCE
            # -------------------------------------------------

            elif ch == 2:

                if Chain.instance is None:

                    print(
                        "Blockchain is not initialized."
                    )

                    continue

                balance = Chain.instance.calc_balance(
                    self.wallet.public_key_pem,
                    self.mem_pool
                )

                print(
                    "Account Balance =",
                    balance
                )

            # -------------------------------------------------
            # PRINT CHAIN
            # -------------------------------------------------

            elif ch == 3:

                if Chain.instance is None:

                    print(
                        "Blockchain is not initialized."
                    )

                    continue

                for i, block in enumerate(
                    Chain.instance.chain
                ):

                    print(
                        f"block{i}: {block}\n"
                    )

            # -------------------------------------------------
            # PRINT MEMPOOL
            # -------------------------------------------------

            elif ch == 4:

                for i, transaction in enumerate(
                    self.mem_pool
                ):

                    print(
                        f"transaction{i}: "
                        f"{transaction}\n\n"
                    )

            # -------------------------------------------------
            # UPLOAD FILE
            # -------------------------------------------------

            elif ch == 5:

                desc = await loop.run_in_executor(
                    None,
                    input,
                    "\nEnter description of file: "
                )

                path = await loop.run_in_executor(
                    None,
                    input,
                    "\nEnter path of file: "
                )

                pkt = await self.uploadFile(
                    desc,
                    path
                )

                if pkt:

                    await self.broadcast_message(
                        pkt
                    )

            # -------------------------------------------------
            # DOWNLOAD FILE
            # -------------------------------------------------

            elif ch == 6:

                cid = await loop.run_in_executor(
                    None,
                    input,
                    "\nEnter cid of file: "
                )

                path = await loop.run_in_executor(
                    None,
                    input,
                    "\nEnter path to download the file: "
                )

                try:

                    download_ipfs_file_subprocess(
                        cid,
                        path
                    )

                except Exception as e:

                    print(
                        f"Download failed: {e}"
                    )

            # -------------------------------------------------
            # QUIT
            # -------------------------------------------------

            elif ch == 7:

                print(
                    "Quitting..."
                )

                break

            else:

                print(
                    "\nPlease enter a valid option.\n"
                )

    # ---------------------------------------------------------
    # IPFS FILE UPLOAD
    # ---------------------------------------------------------

    async def uploadFile(
        self,
        desc: str,
        path: str
    ):

        file_path = Path(path)

        if not file_path.is_file():

            print(
                "\nFile doesn't exist\n"
            )

            return None

        if not self.daemon_process:

            try:
                self.start_daemon()

            except Exception as e:

                print(
                    f"Could not start IPFS daemon: {e}"
                )

                return None

        try:

            cid, name = await asyncio.to_thread(
                addToIpfs,
                path
            )

        except Exception as e:

            print(
                f"Could not add file to IPFS: {e}"
            )

            return None

        if not cid or not name:

            return None

        print(
            f"\nNew File Created : {cid}\n"
        )

        pkt = {
            "type": "file",
            "id": str(uuid.uuid4()),
            "desc": desc,
            "cid": cid
        }

        self.seen_message_ids.add(
            pkt["id"]
        )

        async with self.file_hashes_lock:

            self.file_hashes[cid] = desc

        return pkt

    # ---------------------------------------------------------
    # IPFS
    # ---------------------------------------------------------

    def init_repo(self):

        if not self.repo_path.exists():

            subprocess.run(
                ["ipfs", "init"],
                env=self.env,
                check=True
            )

            print(
                "\nIPFS repo created\n"
            )

    def configure_ports(self):

        subprocess.run(
            [
                "ipfs",
                "config",
                "Addresses.API",
                f"/ip4/127.0.0.1/tcp/{self.ipfs_port}"
            ],
            env=self.env,
            check=True
        )

        subprocess.run(
            [
                "ipfs",
                "config",
                "Addresses.Gateway",
                f"/ip4/127.0.0.1/tcp/{self.gateway_port}"
            ],
            env=self.env,
            check=True
        )

        subprocess.run(
            [
                "ipfs",
                "config",
                "Addresses.Swarm",
                "--json",
                (
                    f'["/ip4/127.0.0.1/tcp/{self.swarm_tcp}", '
                    f'"/ip4/127.0.0.1/udp/{self.swarm_udp}/quic"]'
                )
            ],
            env=self.env,
            check=True
        )

        print(
            "\nConfigured Ports\n"
        )

    def start_daemon(self):

        if self.daemon_process is not None:

            if self.daemon_process.poll() is None:
                return

        self.daemon_process = subprocess.Popen(
            ["ipfs", "daemon"],
            env=self.env
        )

        print(
            "\nIPFS Daemon Started\n"
        )

    def stop_daemon(self):

        if self.daemon_process:

            try:

                self.daemon_process.terminate()

                self.daemon_process.wait(
                    timeout=5
                )

            except subprocess.TimeoutExpired:

                self.daemon_process.kill()

            except Exception:
                pass

            finally:

                self.daemon_process = None

    # ---------------------------------------------------------
    # CONNECT TO PEER
    # ---------------------------------------------------------

    async def connect_to_peer(
        self,
        host,
        port
    ):

        endpoint = (
            host,
            int(port)
        )

        normalized_self = normalize_endpoint(
            (self.host, self.port)
        )

        try:
            normalized_endpoint = normalize_endpoint(
                endpoint
            )
        except Exception:
            normalized_endpoint = endpoint

        if (
            endpoint in self.outbound_peers
            or normalized_endpoint == normalized_self
        ):
            return

        uri = f"ws://{host}:{port}"

        websocket = None

        try:

            websocket = await websockets.connect(
                uri
            )

            self.client_connections.add(
                websocket
            )

            self.outbound_peers.add(
                endpoint
            )

            self.have_sent_peer_info[
                websocket
            ] = False

            print(
                f"Outbound connection formed to "
                f"{host}:{port}"
            )

            # If connecting to the network
            # without a local chain, announce ourselves.

            if Chain.instance is None:

                pkt = {
                    "type": "add_peer",
                    "id": str(uuid.uuid4()),
                    "data": {
                        "host": self.host,
                        "port": self.port,
                        "name": self.name,
                        "public_key":
                            self.wallet.public_key_pem
                    }
                }

            else:

                pkt = {
                    "type": "ping",
                    "id": str(uuid.uuid4())
                }

            self.seen_message_ids.add(
                pkt["id"]
            )

            await websocket.send(
                json.dumps(pkt)
            )

            async for raw in websocket:

                try:
                    msg = json.loads(raw)

                except json.JSONDecodeError:

                    print(
                        "Received invalid JSON"
                    )

                    continue

                await self.handle_messages(
                    websocket,
                    msg
                )

        except Exception as e:

            print(
                f"Failed to connect to "
                f"{host}:{port} ::: {e}"
            )

        finally:

            if websocket is not None:

                self.client_connections.discard(
                    websocket
                )

                self.outbound_peers.discard(
                    endpoint
                )

                self.got_pong.pop(
                    websocket,
                    None
                )

                self.have_sent_peer_info.pop(
                    websocket,
                    None
                )

                try:

                    if not websocket.closed:
                        await websocket.close()

                except Exception:
                    pass

    # ---------------------------------------------------------
    # PEER DISCOVERY
    # ---------------------------------------------------------

    async def discover_peers(self):

        while True:

            try:

                if len(self.outbound_peers) < MAX_CONNECTIONS:

                    potential_peers = {
                        endpoint
                        for endpoint in self.known_peers
                        if (
                            endpoint
                            not in self.outbound_peers
                            and endpoint
                            != (self.host, self.port)
                        )
                    }

                    while (
                        len(self.outbound_peers)
                        < MAX_CONNECTIONS
                        and potential_peers
                    ):

                        new_peer = get_random_element(
                            potential_peers
                        )

                        potential_peers.discard(
                            new_peer
                        )

                        if new_peer:

                            asyncio.create_task(
                                self.connect_to_peer(
                                    *new_peer
                                )
                            )

                            await asyncio.sleep(1)

                await asyncio.sleep(30)

            except asyncio.CancelledError:
                raise

            except Exception as e:

                print(
                    f"Peer discovery error: {e}"
                )

                await asyncio.sleep(30)

    # ---------------------------------------------------------
    # GOSSIP SAMPLER
    # ---------------------------------------------------------

    async def gossip_peer_sampler(self):

        while True:

            try:

                await asyncio.sleep(60)

                if (
                    len(self.known_peers)
                    <= len(self.outbound_peers)
                    or len(self.outbound_peers)
                    < MAX_CONNECTIONS
                ):

                    continue

                to_drop = get_random_element(
                    self.client_connections
                )

                if to_drop:

                    print(
                        f"Gossip Sampling: "
                        f"Disconnecting "
                        f"{to_drop.remote_address}"
                    )

                    self.client_connections.discard(
                        to_drop
                    )

                    try:

                        remote = to_drop.remote_address

                        if remote:

                            normalized_endpoint = normalize_endpoint(
                                (
                                    remote[0],
                                    remote[1]
                                )
                            )

                            self.outbound_peers.discard(
                                normalized_endpoint
                            )

                    except Exception:
                        pass

                    self.got_pong.pop(
                        to_drop,
                        None
                    )

                    self.have_sent_peer_info.pop(
                        to_drop,
                        None
                    )

                    try:
                        await to_drop.close()
                    except Exception:
                        pass

                potential_peers = {
                    endpoint
                    for endpoint in self.known_peers
                    if (
                        endpoint
                        not in self.outbound_peers
                        and endpoint
                        != (self.host, self.port)
                    )
                }

                if potential_peers:

                    new_peer = get_random_element(
                        potential_peers
                    )

                    if new_peer:

                        print(
                            f"Gossip Sampling: "
                            f"Connecting to new peer "
                            f"{new_peer}"
                        )

                        asyncio.create_task(
                            self.connect_to_peer(
                                *new_peer
                            )
                        )

            except asyncio.CancelledError:
                raise

            except Exception as e:

                print(
                    f"Gossip sampler error: {e}"
                )

    # ---------------------------------------------------------
    # MINING
    # ---------------------------------------------------------

    async def mine_blocks(self):

        while True:

            try:

                await asyncio.sleep(30)

                if Chain.instance is None:
                    continue

                async with self.mem_pool_condition:

                    if len(self.mem_pool) == 0:
                        continue

                    transaction_list = []

                    # Remove transactions already
                    # included in blockchain.

                    valid_mempool = []

                    for transaction in self.mem_pool:

                        if Chain.instance.transaction_exists_in_chain(
                            transaction
                        ):
                            continue

                        transaction_list.append(
                            transaction
                        )

                        valid_mempool.append(
                            transaction
                        )

                    self.mem_pool = valid_mempool

                    if len(transaction_list) == 0:
                        continue

                    newBlock = Block(
                        Chain.instance.lastBlock.hash,
                        transaction_list
                    )

                    async with self.file_hashes_lock:

                        newBlock.files = (
                            self.file_hashes.copy()
                        )

                    # Mining can be CPU-intensive.
                    await asyncio.to_thread(
                        Chain.instance.mine,
                        newBlock
                    )

                    newBlock.miner = (
                        self.wallet.public_key_pem
                    )

                    if Chain.instance.isValidBlock(
                        newBlock
                    ):

                        Chain.instance.chain.append(
                            newBlock
                        )

                        print(
                            "\nBlock Appended\n"
                        )

                        # Deploy contracts

                        for transaction in newBlock.transactions:

                            if (
                                transaction.receiver
                                == "deploy"
                            ):

                                self.deploy_contract(
                                    transaction
                                )

                        # Remove files included in block

                        async with self.file_hashes_lock:

                            for file_hash in list(
                                self.file_hashes.keys()
                            ):

                                if newBlock.cid_exists_in_block(
                                    file_hash
                                ):

                                    self.file_hashes.pop(
                                        file_hash,
                                        None
                                    )

                        # Remove confirmed transactions

                        self.mem_pool = [
                            transaction
                            for transaction in self.mem_pool
                            if not newBlock.transaction_exists_in_block(
                                transaction
                            )
                        ]

                        pkt = {
                            "type": "new_block",
                            "id": str(uuid.uuid4()),
                            "block": newBlock.to_dict(),
                            "miner":
                                self.wallet.public_key_pem
                        }

                        self.seen_message_ids.add(
                            pkt["id"]
                        )

                        await self.broadcast_message(
                            pkt
                        )

                        if self.activate_disk_save == "y":
                            self.save_chain_to_disk()

                    else:

                        print(
                            "\nInvalid Block\n"
                        )

            except asyncio.CancelledError:
                raise

            except Exception as e:

                print(
                    f"Mining error: {e}"
                )

    # ---------------------------------------------------------
    # SMART CONTRACT
    # ---------------------------------------------------------

    def calculate_contract_id(
        self,
        sender,
        timestamp
    ):

        data = f"{sender}:{timestamp}"

        hash_object = hashlib.sha256(
            data.encode("utf-8")
        )

        return hash_object.hexdigest()

    def deploy_contract(
        self,
        transaction: Transaction
    ):

        sender = transaction.sender
        timestamp = transaction.ts
        code = transaction.payload[0]

        contract_id = self.calculate_contract_id(
            sender,
            timestamp
        )

        self.contractsDB.store_contract(
            contract_id,
            code
        )

        print(
            "Contract deployed with id:",
            contract_id
        )

    def run_contract(self, payload):

        contract_id = payload[0]
        func_name = payload[1]
        args = payload[2]

        code = self.contractsDB.get_contract(
            contract_id
        )

        if code is None:

            raise Exception(
                f"Contract '{contract_id}' not found."
            )

        state = self.get_contract_state(
            contract_id
        )

        executor = SecureContractExecutor(
            code
        )

        response = executor.run(
            func_name,
            args,
            state
        )

        return response

    # ---------------------------------------------------------
    # CHAIN SYNCHRONIZATION
    # ---------------------------------------------------------

    async def find_longest_chain(self):

        while True:

            try:

                pkt = {
                    "type": "chain_request",
                    "id": str(uuid.uuid4())
                }

                self.seen_message_ids.add(
                    pkt["id"]
                )

                await self.broadcast_message(
                    pkt
                )

                print(
                    "\nSent out chain requests..."
                )

                await asyncio.sleep(60)

            except asyncio.CancelledError:
                raise

            except Exception as e:

                print(
                    f"Chain synchronization error: {e}"
                )

                await asyncio.sleep(60)

    # ---------------------------------------------------------
    # START PEER
    # ---------------------------------------------------------

    async def start(
        self,
        bootstrap_host=None,
        bootstrap_port=None,
        web_mode=False
    ):

        # Initialize IPFS repo first

        try:

            self.init_repo()
            self.configure_ports()

        except Exception as e:

            print(
                f"IPFS initialization/configuration failed: {e}"
            )

            print(
                "Blockchain networking will continue, "
                "but IPFS features may not work."
            )

        # Start WebSocket server

        server = await websockets.serve(
            self.handle_connections,
            self.host,
            self.port
        )

        print(
            f"\nPeer {self.name} listening on "
            f"{self.host}:{self.port}\n"
        )

        # Bootstrap node

        if bootstrap_host and bootstrap_port:

            try:

                normalized_bootstrap_host, normalized_bootstrap_port = (
                    normalize_endpoint(
                        (
                            bootstrap_host,
                            bootstrap_port
                        )
                    )
                )

                asyncio.create_task(
                    self.connect_to_peer(
                        normalized_bootstrap_host,
                        normalized_bootstrap_port
                    )
                )

            except Exception as e:

                print(
                    f"Could not connect to bootstrap node: {e}"
                )

        else:

            # First node creates the blockchain

            if Chain.instance is None:

                self.chain = Chain(
                    publicKey=self.wallet.public_key_pem
                )

                print(
                    "\nCreated new blockchain.\n"
                )

        # User input

        inp_task = None if web_mode else asyncio.create_task(
            self.user_input_handler()
        )

        # Chain synchronization

        consensus_task = asyncio.create_task(
            self.find_longest_chain()
        )

        # Peer discovery

        disc_task = asyncio.create_task(
            self.discover_peers()
        )

        # Gossip sampling

        sampler_task = asyncio.create_task(
            self.gossip_peer_sampler()
        )

        # Mining

        if self.miner:

            self.mine_task = asyncio.create_task(
                self.mine_blocks()
            )

        try:

            if inp_task is not None:
                await inp_task
            else:
                await asyncio.Event().wait()

        finally:

            # Cancel background tasks

            disc_task.cancel()
            consensus_task.cancel()
            sampler_task.cancel()

            if self.mine_task:

                self.mine_task.cancel()

            # Wait for cancellations

            tasks = [
                disc_task,
                consensus_task,
                sampler_task
            ]

            if self.mine_task:
                tasks.append(
                    self.mine_task
                )

            for task in tasks:

                try:
                    await task
                except asyncio.CancelledError:
                    pass
                except Exception:
                    pass

            # Stop IPFS

            if self.daemon_process:

                self.stop_daemon()

            # Close WebSocket server

            server.close()

            await server.wait_closed()

            # Close active connections

            all_connections = (
                self.server_connections
                | self.client_connections
            )

            for ws in list(all_connections):

                try:
                    await ws.close()
                except Exception:
                    pass