from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Any

from fastapi import WebSocket

from consensus.poa.p2p import Peer as PoAPeer
from consensus.pos.p2p import Peer as PoSPeer
from consensus.pow.p2p import Peer as PoWPeer
from consensus.poa.mal_node import Peer as PoaMalPeer
from consensus.pos.mal_node import Peer as PosMalPeer
from consensus.pow.mal_node import Peer as PowMalPeer


@dataclass
class WebState:
    peer: Any | None = None
    consensus: str = "pow"
    task: asyncio.Task | None = None
    started_at: float | None = None
    clients: set[WebSocket] = field(default_factory=set)
    events: list[dict] = field(default_factory=list)

    async def publish(self, event: str, data: dict):
        item = {"event": event, "timestamp": time.time(), "data": data}
        self.events.append(item)
        self.events = self.events[-250:]
        dead = []
        for ws in self.clients:
            try:
                await ws.send_json(item)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.clients.discard(ws)


state = WebState()


def make_peer(consensus: str, host: str, port: int, name: str,
              role: bool, load: bool, save: bool, malicious: bool = False):
    consensus = consensus.lower()
    args = (host, port, name)
    flags = ("y" if load else "n", "y" if save else "n")
    if consensus == "pow":
        cls = PowMalPeer if malicious else PoWPeer
        return cls(*args, role, *flags)
    if consensus == "pos":
        cls = PosMalPeer if malicious else PoSPeer
        return cls(*args, role, *flags)
    if consensus == "poa":
        cls = PoaMalPeer if malicious else PoAPeer
        return cls(*args, *flags)
    raise ValueError("consensus must be pow, pos, or poa")
