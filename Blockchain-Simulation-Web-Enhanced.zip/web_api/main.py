import asyncio
import contextlib
import time

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .routes import router
from .state import state

app = FastAPI(title="Blockchain Simulation API", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.include_router(router)

async def telemetry_loop():
    last = None
    while True:
        try:
            p = state.peer
            if p:
                chain = getattr(getattr(p, "chain", None), "chain", []) or []
                snapshot = {
                    "height": len(chain),
                    "last_hash": getattr(chain[-1], "hash", None) if chain else None,
                    "mempool": len(getattr(p, "mem_pool", []) or []),
                    "peers": len(getattr(p, "known_peers", {}) or {}),
                }
                if last is None:
                    last = snapshot
                else:
                    if snapshot["height"] != last["height"]:
                        await state.publish("blockchain_updated", snapshot)
                    if snapshot["mempool"] != last["mempool"]:
                        await state.publish("mempool_updated", snapshot)
                    if snapshot["peers"] != last["peers"]:
                        await state.publish("network_updated", snapshot)
                    last = snapshot
        except Exception as exc:
            await state.publish("telemetry_error", {"message": str(exc)})
        await asyncio.sleep(1)

@app.on_event("startup")
async def startup():
    app.state.telemetry_task = asyncio.create_task(telemetry_loop())

@app.on_event("shutdown")
async def shutdown():
    task = getattr(app.state, "telemetry_task", None)
    if task:
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task

@app.get("/")
async def root():
    return {"name": "Blockchain Simulation API", "docs": "/docs", "timestamp": time.time()}
