from __future__ import annotations

import base64
import json
from typing import Any


def safe(value: Any):
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, bytes):
        return base64.b64encode(value).decode()
    if isinstance(value, dict):
        return {str(k): safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [safe(v) for v in value]
    if hasattr(value, "to_dict"):
        try:
            return safe(value.to_dict())
        except Exception:
            pass
    if hasattr(value, "__dict__"):
        return {k: safe(v) for k, v in value.__dict__.items() if not k.startswith("_")}
    return str(value)


def tx(tx):
    data = safe(tx)
    if isinstance(data, dict) and getattr(tx, "sign", None) is not None:
        data["signed"] = True
    return data


def block(block):
    data = safe(block)
    if isinstance(data, dict):
        data.setdefault("hash", getattr(block, "hash", None))
        data.setdefault("id", getattr(block, "id", None))
        data.setdefault("prevHash", getattr(block, "prevHash", None))
        data["transactions"] = [tx(t) for t in getattr(block, "transactions", [])]
    return data
