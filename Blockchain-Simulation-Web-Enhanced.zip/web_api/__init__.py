"""FastAPI gateway for the Blockchain Simulation."""
