from __future__ import annotations

import asyncio
import time
from typing import Any

from fastapi import APIRouter, HTTPException, UploadFile, File, WebSocket, WebSocketDisconnect
from pydantic import BaseModel, Field

from .serializers import block, safe, tx
from .state import state, make_peer

router = APIRouter(prefix="/api")


class StartNode(BaseModel):
    consensus: str = "pow"
    host: str = "127.0.0.1"
    port: int = Field(5000, ge=1024, le=65535)
    name: str = "web-node"
    bootstrap_host: str | None = None
    bootstrap_port: int | None = None
    role: bool = True
    load_saved_data: bool = True
    save_to_disk: bool = True
    malicious: bool = False


class SendTransaction(BaseModel):
    receiver: str
    amount: float = Field(gt=0)


@router.get("/health")
async def health():
    return {"status": "ok", "service": "blockchain-web-api", "timestamp": time.time()}


@router.get("/status")
async def status():
    p = state.peer
    chain = getattr(p, "chain", None) if p else None
    chain_list = getattr(chain, "chain", []) if chain else []
    return {
        "running": p is not None,
        "consensus": state.consensus,
        "name": getattr(p, "name", None),
        "host": getattr(p, "host", None),
        "port": getattr(p, "port", None),
        "block_height": len(chain_list),
        "mempool": len(getattr(p, "mem_pool", []) or []),
        "known_peers": len(getattr(p, "known_peers", {}) or {}),
        "connected_peers": len(getattr(p, "outbound_peers", set()) or set()),
        "uptime": time.time() - state.started_at if state.started_at else 0,
    }


@router.post("/node/start")
async def start_node(req: StartNode):
    if state.task and not state.task.done():
        raise HTTPException(409, "A node is already running")
    p = make_peer(req.consensus, req.host, req.port, req.name, req.role,
                  req.load_saved_data, req.save_to_disk, req.malicious)
    state.peer = p
    state.consensus = req.consensus.lower()
    state.started_at = time.time()
    state.events.clear()
    state.task = asyncio.create_task(p.start(req.bootstrap_host, req.bootstrap_port, web_mode=True))
    await state.publish("node_started", {"name": req.name, "consensus": state.consensus, "port": req.port})
    return {"status": "starting", "consensus": state.consensus, "name": req.name, "port": req.port}


@router.post("/node/stop")
async def stop_node():
    if not state.task:
        return {"status": "stopped"}
    state.task.cancel()
    try:
        await state.task
    except asyncio.CancelledError:
        pass
    state.task = None
    state.peer = None
    await state.publish("node_stopped", {})
    return {"status": "stopped"}


@router.get("/wallet")
async def wallet():
    p = state.peer
    if not p:
        raise HTTPException(404, "Node is not running")
    w = p.wallet
    return {"public_key": getattr(w, "public_key_pem", None), "address": getattr(w, "public_key_pem", None)}


@router.get("/blocks")
async def blocks(limit: int = 50):
    p = state.peer
    if not p or not p.chain:
        return []
    chain = getattr(p.chain, "chain", [])
    return [block(b) for b in chain[-max(1, min(limit, 500)):]][::-1]


@router.get("/blocks/{index}")
async def get_block(index: int):
    p = state.peer
    if not p or not p.chain:
        raise HTTPException(404, "Chain not initialized")
    chain = getattr(p.chain, "chain", [])
    if index < 0 or index >= len(chain):
        raise HTTPException(404, "Block not found")
    return block(chain[index])


@router.get("/transactions")
async def transactions(limit: int = 100):
    p = state.peer
    if not p:
        return []
    result = []
    for t in list(getattr(p, "mem_pool", []) or []):
        result.append({"status": "pending", **tx(t)})
    chain = getattr(getattr(p, "chain", None), "chain", []) or []
    for b in reversed(chain):
        for t in reversed(getattr(b, "transactions", []) or []):
            result.append({"status": "confirmed", "block_id": getattr(b, "id", None), **tx(t)})
            if len(result) >= limit:
                return result[:limit]
    return result[:limit]


@router.post("/transactions/send")
async def send_transaction(req: SendTransaction):
    p = state.peer
    if not p:
        raise HTTPException(404, "Node is not running")
    await p.create_and_broadcast_tx(req.receiver, req.amount)
    await state.publish("transaction_created", {"receiver": req.receiver, "amount": req.amount})
    return {"status": "submitted"}


@router.get("/network")
async def network():
    p = state.peer
    if not p:
        return {"nodes": [], "connections": []}
    nodes = []
    known = getattr(p, "known_peers", {}) or {}
    for endpoint, info in known.items():
        name = info[0] if isinstance(info, (list, tuple)) and info else str(endpoint)
        host, port = endpoint if isinstance(endpoint, tuple) else (str(endpoint), None)
        nodes.append({"id": f"{host}:{port}", "name": name, "host": host, "port": port, "status": "online"})
    me = {"id": f"{p.host}:{p.port}", "name": p.name, "host": p.host, "port": p.port, "status": "online"}
    nodes.insert(0, me)
    connections = []
    for endpoint in getattr(p, "outbound_peers", set()) or set():
        target = f"{endpoint[0]}:{endpoint[1]}"
        connections.append({"source": me["id"], "target": target})
    return {"nodes": nodes, "connections": connections}


@router.get("/consensus")
async def consensus():
    p = state.peer
    if not p:
        return {"mechanism": state.consensus}
    data = {"mechanism": state.consensus}
    if state.consensus == "pow":
        data.update({"miner": getattr(p, "miner", False), "difficulty": 5, "mining": getattr(p, "mine_task", None) is not None})
    elif state.consensus == "pos":
        data.update({"staker": getattr(p, "staker", False), "staked_amount": getattr(p, "staked_amt", 0),
                     "stakers": safe(getattr(p, "current_stakers", {})), "epoch_end": safe(getattr(p, "last_epoch_end_ts", None))})
    elif state.consensus == "poa":
        data.update({"miner": getattr(p, "miner", False), "admin_id": getattr(p, "admin_id", None),
                     "node_id": getattr(p, "node_id", None), "miners": safe(getattr(p, "miners", []))})
    return data


@router.get("/security")
async def security():
    events = [e for e in state.events if e["event"] in {"security_event", "transaction_rejected", "block_rejected"}]
    return {"events": events[-100:], "malicious_mode": bool(getattr(state.peer, "malicious", False)) if state.peer else False}


@router.get("/events")
async def events():
    return state.events[-100:]


@router.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    await ws.accept()
    state.clients.add(ws)
    try:
        await ws.send_json({"event": "snapshot", "timestamp": time.time(), "data": await status()})
        for item in state.events[-20:]:
            await ws.send_json(item)
        while True:
            await ws.receive_text()
    except WebSocketDisconnect:
        pass
    finally:
        state.clients.discard(ws)

@router.get("/metrics")
async def metrics():
    p = state.peer
    chain = getattr(getattr(p, "chain", None), "chain", []) if p else []
    tx_count = sum(len(getattr(b, "transactions", []) or []) for b in chain)
    peers = getattr(p, "known_peers", {}) if p else {}
    return {
        "blocks": len(chain),
        "transactions": tx_count,
        "pending_transactions": len(getattr(p, "mem_pool", []) or []) if p else 0,
        "known_peers": len(peers or {}),
        "connected_peers": len(getattr(p, "outbound_peers", set()) or set()) if p else 0,
        "uptime_seconds": time.time() - state.started_at if state.started_at else 0,
        "events": len(state.events),
    }


@router.get("/fault-tolerance")
async def fault_tolerance():
    p = state.peer
    return {
        "node_running": bool(p),
        "chain_available": bool(getattr(p, "chain", None)) if p else False,
        "peer_discovery_active": bool(getattr(p, "known_peers", None)) if p else False,
        "persistence_enabled": getattr(p, "activate_disk_save", None) == "y" if p else False,
        "recovery_ready": bool(p and getattr(p, "chain", None)),
    }
