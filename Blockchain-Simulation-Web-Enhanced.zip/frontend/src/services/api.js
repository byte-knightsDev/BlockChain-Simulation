const API = import.meta.env.VITE_API_URL || 'http://127.0.0.1:8000/api';
export const api = async (path, options={}) => {
  const res = await fetch(`${API}${path}`, {headers:{'Content-Type':'application/json', ...(options.headers||{})}, ...options});
  if(!res.ok) throw new Error((await res.json().catch(()=>({detail:res.statusText}))).detail || res.statusText);
  return res.json();
};
export const wsUrl = () => (import.meta.env.VITE_WS_URL || 'ws://127.0.0.1:8000/api/ws');
